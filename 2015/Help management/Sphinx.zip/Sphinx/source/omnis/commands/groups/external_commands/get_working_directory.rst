﻿Get working directory
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Get working directory** (*path*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.
Example
*******

.. code-block:: omnis
	:linenos:	;  return the current working directoryGet working directory (lDirectory) 
