﻿IMAPCreateMailbox
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**IMAPCreateMailbox** (*socket*,*mailboxname*[,*stsproc*,*responselist*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**IMAPCreateMailbox** creates a new mailbox on the IMAP server.

*Socket* is an Omnis Long Integer field containing a socket opened to an IMAP serverusing *`IMAPConnect <imapconnect.html>`_
*.

*Mailboxname* is the name of the mailbox to be created.

IMAP mailbox names are left-to-right hierarchical using a single character to separate levels of hierarchy.  If you execute *`IMAPListMailboxes <imaplistmailboxes.html>`_
* with empty RefName and MailboxName parameters,the returned list has a single line from which you can access the hierarchy separator.

All the Omnis IMAP commands automatically enclose mailbox names in double quotes when sending them to the server.

*Stsproc* is an optional parameter containing the name of an Omnis method that this commandcalls with status messages. This command calls the method with no parameters,and the status information in the variable #S1. The status information logs protocolmessages exchanged on the connection to the server.

*Responselist* is an optional parameter into which this command places response lines received from the IMAP server.  Before callingthis command, define the *responselist* to have a single Character column.  When the command returns successfully, the response listcontains the untagged and tagged responses received from the IMAP server as a result of executing this command.  These sometimes include unsolicited information, for example, anupdate on the current number of messages in the selected mailbox. Each line in the response list is a response line received from the server.See RFC 3501 for more details, if you need to handle this sort of information.

This command returns an integer, which is less than zero if an error occurred.  Possible error codes arelisted in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Create a new folder Test in the INBOX.;  &quot;.&quot; is the hierarchy separatorCalculate iMailbox as &quot;INBOX.Test&quot;IMAPCreateMailbox (iIMAPSocket,iMailbox) Returns lStatusIf lStatus&lt;0    ;  The CREATE command failedEnd If
