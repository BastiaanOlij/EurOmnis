﻿Load connected records
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Load connected records** {*file-name*}
Description
***********
This command loads the connected records for the specified file. The **Loadconnected records** command ensures that the identity of the current connectedrecords for the current record is correct. As Omnis automatically loads connected recordsof the main file into the current record buffer, this command is not usually required.However, in multi-user systems, this command ensures that, if any other workstation makeschanges to the way in which records are connected, these changes will be reflected at thecurrent workstation.

The flag is cleared if there is no current record for the specified file class, and inthe event that no file class is specified, Omnis uses the main file. This command does notclear the *Prepare for update* mode but does cause multi-user semaphores to be setand should be avoided when in *Prepare for...* mode.

If a parent record requires locking, another user is editing it, and the *`Wait for semaphores <../../../commands/groups/changing_data/wait_for_semaphores.html>`_
*command is on, the lock cursor will be displayed. If the user cancels the lock, the flagis cleared and the parent record is not loaded. The *`Do not waitfor semaphores <../../../commands/groups/changing_data/do_not_wait_for_semaphores.html>`_
* command prevents the user from having to wait for the record andreturns a flag false if the parent record is not available.

If placed in a reversible block, the parent record reverts to its former value when themethod terminates. If you need to read in grandparent records, you can add this command tothe usual `Next <next.html>`_
 command:
Example
*******

.. code-block:: omnis
	:linenos:	;  Use load connected records to load the grandparent record,;  as only the parent record of the main file is loaded after a findSet main file {fChild}Find first Load connected records {fParent}Do $cinst.$redraw()
