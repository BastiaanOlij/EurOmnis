﻿Build list from select table
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |NO |NO |NO |All |

Syntax
******
**Build list ***list-name*** from select table ****for cursor ***cursor-name********* ([*Add CRB fields*][,*Clear list*])

Options
*******|Add CRB fields |If specified,the command adds values from the current record buffer to the list,for columns with no available SQL data |
|Clear list |If specified,the command empties the list (maintaining its column definitions) before executing |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.