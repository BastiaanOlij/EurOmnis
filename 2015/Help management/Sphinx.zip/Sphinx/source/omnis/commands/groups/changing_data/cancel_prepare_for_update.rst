﻿Cancel prepare for update
#########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |NO |NO |NO |All |

Syntax
******
**Cancel prepare for update**
Description
***********
This command cancels the Prepare for update mode and releases any semaphores which mayhave been set. You use the *`Prepare for edit/ <../../../commands/groups/changing_data/prepare_for_edit.html>`_
*insertcommand to prepare Omnis for editing or insertion of records. It is usually followed by *`Update files <../../../commands/groups/changing_data/update_files.html>`_
* whichis the usual way of terminating the Prepare for..*.* state but you can also terminatethis state with **Cancel prepare for update**. It must be followed bycommands which prevent an *`Update files <../../../commands/groups/changing_data/update_files.html>`_
*command from being encountered.

When you execute a *Prepare for...* command in multi-user mode, semaphores areused to implement record locking. **Cancel prepare for update** neutralizesthe effect of a *Prepare for...* command and releases all semaphores.

You can use this command within a timer method to implement a timed record release.
Example
*******

.. code-block:: omnis
	:linenos:	Set timer method 600 sec TimerMethodPrepare for editEnter data Update files if flag setClear timer method;  TimerMethodYes/No message  {Time's up, cancel edit?}If flag true    Cancel prepare for update    Queue cancelEnd If
