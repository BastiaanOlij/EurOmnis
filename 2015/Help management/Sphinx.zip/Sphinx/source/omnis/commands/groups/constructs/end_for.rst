﻿End For
#######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**End For**
Description
***********
This command ends a For loop. The two For loops *`Forfield value <for_field_value.html>`_
* and *`For each line in list <for_each_line_list.html>`_
*perform looping type operations. The **End For** command terminates boththese commands.
Example
*******

.. code-block:: omnis
	:linenos:	Do iMyList.$define(iMyCol1)Do iMyList.$add('A')Do iMyList.$add('B')For iMyList.$line from 1 to iMyList.$linecount step 1    Do iMyList.$loadcols()    OK message  {Line [iMyList.$line] = [iMyCol1]}End ForSet current list iMyListFor each line in list from 1 to #LN step 1    Load from list    OK message  {Line [iMyList.$line] = [iMyCol1]}End For
