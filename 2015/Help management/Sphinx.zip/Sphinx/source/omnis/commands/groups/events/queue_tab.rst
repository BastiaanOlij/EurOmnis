﻿Queue tab
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue tab** ([*Shift*])

Options
*******|Shift |If specified,the queued event behaves as if the shift key has been pressed |

Description
***********
This command queues a &quot;tab&quot; or &quot;shift-tab&quot; event. It simulates auser-generated tab event. With the **Shift** option, it simulates a shift-tabkeypress.
Example
*******

.. code-block:: omnis
	:linenos:	;  Field method for a window field to simulate auto tab.  When the 4th character is entered;  a tab occurs.  The field must have $keyevents turned on.On evBefore    Calculate iCount as 0    On evKey    Calculate iCount as iCount+1    If iCount&gt;3        Queue tab    End If
