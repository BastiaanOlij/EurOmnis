﻿Copy file
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Copy file** (*from*-*path* [,*to*-*path*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command makes a copy of the file specified in *from-path*. The *to-path*is the path to destination folder into which the file will be copied;the file to be copied must not already exist in the destination folder. If you omit *to-path*, a copy of the file named in *from-path* is createdin the current directory using the same name with the extension &quot;.BAK&quot;.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lPathname as con(sys(115),'html',sys(9),'serverusagetask.htm')Calculate lNewPath as con(sys(115),'html',sys(9),'serverusagetask2.htm')Copy file (lPathname,lNewPath) Returns lErrCode     ;; copies the file in lPathName to the filename contained in lNewPath
