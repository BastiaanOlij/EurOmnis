﻿Importing and Exporting
#######################
`Command Index <../command_index.html>`_


`Commands
******** <importing_and_exporting#commands>`_
|`Build export format list <importing_and_exporting/build_export_format_list.html>`_  |`Close import file <importing_and_exporting/close_import_file.html>`_  |`Enclose exported text in quotes <importing_and_exporting/enclose_exported_text_in_quotes.html>`_  |`End export <importing_and_exporting/end_export.html>`_  |
|`End import <importing_and_exporting/end_import.html>`_  |`Export data <importing_and_exporting/export_data.html>`_  |`Export fields <importing_and_exporting/export_fields.html>`_  |`Import data <importing_and_exporting/import_data.html>`_  |
|`Import field from file <importing_and_exporting/import_field_from_file.html>`_  |`Import field from port <importing_and_exporting/import_field_from_port.html>`_  |`Import fields <importing_and_exporting/import_fields.html>`_  |`Prepare for export to file <importing_and_exporting/prepare_for_export_to_file.html>`_  |
|`Prepare for export to port <importing_and_exporting/prepare_for_export_to_port.html>`_  |`Prepare for import from client <importing_and_exporting/prepare_for_import_from_client.html>`_  |`Prepare for import from file <importing_and_exporting/prepare_for_import_from_file.html>`_  |`Prepare for import from port <importing_and_exporting/prepare_for_import_from_port.html>`_  |
|`Prompt for import file <importing_and_exporting/prompt_for_import_file.html>`_  |`Set import file name <importing_and_exporting/set_import_file_name.html>`_  |`Translate input/output <importing_and_exporting/translate_input_output.html>`_  |

