﻿OK message
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**OK message** *title* ([*Icon*][,*Sound bell*][,*Cancel button*]) {*message*}

Options
*******|Icon |If specified,the message displays an operating system specific icon |
|Sound bell |If specified,the system bell sounds when the command displays the message |
|Cancel button |If specified,the message has a cancel button |

Description
***********
This command displays the specified message and waits for the user to click the **OK**or **Cancel** button before continuing. Method execution is halted temporarily whilethe message box is displayed. The number of message lines displayed depends on youroperating system, fonts and screen size. In the message text you can force a break betweenlines (a carriage return) by using the notation &quot;//&quot; or the `kCr <../../../notation/root/constants/special_characters.html>`_
constant enclosed in square brackets, e.g. 'First line[`kCr <../../../notation/root/constants/special_characters.html>`_
]Second line'. Also you can add a short *title*for the message box.

For greater emphasis, you can select an **Icon** for the message box (the default&quot;info&quot; icon for the current operating system), and you can force the system bellto sound by checking the **Sound bell** check box.

The message box displayed by this command has an **OK** button by default, but youcan add a **Cancel** button by checking the **Cancel button** option. Afterexecuting an OK message, the flag is unchanged, but you can use the *`msgcancelled() <../../../functions/groups/general/msgcancelled.html>`_
* functionto detect if the user pressed the Cancel button.

You can use square bracket notation in the message text to display the current value offields and variables.

Note - for JavaScript client-executed methods this command uses a standard alert() or confirm() dialog.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open a Ok messsage dialog, if cancel is pressed;  abort printingCalculate lUserName as 'My Name'OK message My Editor (Icon,Cancel button) {Ready to print, press Ok to continue}If msgcancelled()    OK message My Editor {Printing aborted by user [lUserName]}    Quit method End If
