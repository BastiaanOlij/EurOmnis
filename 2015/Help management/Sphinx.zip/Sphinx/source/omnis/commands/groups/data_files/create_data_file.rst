﻿Create data file
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |YES |NO |NO |All |

Syntax
******
**Create data file** ([*Do not close other data*]) {*file-name*,*internal-name*}

Options
*******|Do not close other data |If specified,the command does not close all open data files before opening the specified data file |

Description
***********
This command creates and opens a new and empty, single segment data file, which becomesthe &quot;current&quot; data file. You can specify the path name of the file to be createdand the internal name for the open data file.

The **Do not close other data** option lets you have multiple open data files. Ifyou uncheck this option ,all open data files are closed even if the command fails.

If the disk file with the specified path name cannot be created (and opened), the flagis cleared. Otherwise, the flag is set if the data file is successfully created andopened.
**
WARNING**: If the file and path name is the same as an existing data file, allsegments for that data file are deleted before the new file is created. If the data filewas open, it is closed and deleted; a new and empty data file is then reopened.
Example
*******

.. code-block:: omnis
	:linenos:	Yes/No message  {Do you wish to add a new company?}If flag true    ;  method to do some preparatory code for the new datafile and generate the company name    Do method Insert Company    ;  creates a datafile in the same folder as the omnis executable    ;  the name of the datafile is the value of the character variable iCompany    Create data file (Do not close other data) {(con(sys(115),iCompany,'.df1')/[iCompany]}End If;  or do it like thisDo $datas.$add(con(sys(115),iCompany,'.df1'),kTrue,[iCompany])
