﻿Advise on find/next/previous
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Advise on find/next/previous** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command determines when Omnis is permitted to sendrequested Advise messages to the client program. When Advise requests have been receivedfrom a client, the `Setserver mode <../../groups/exchanging_data/set_server_mode.html>`_
 command determines when Omnis is permitted to send field values thathave changed. In addition to the `Set server mode <../../groups/exchanging_data/set_server_mode.html>`_
options, the three commands **Advise on Find/next/previous***, `Advise on OK <advise_on_ok.html>`_
,* and `Adviseon Redraw <advise_on_redraw.html>`_
 let you toggle individual options on or off. **Advise onFind/next/previous** lets you control this particular option without affecting theother two.
Example
*******

.. code-block:: omnis
	:linenos:	Advise on find/next/previous (Accept)
