﻿Open file
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Open file** (*path*, *refnum* [,*'r'*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a file for openingDo FileOps.$putfilename(lPathname,'Select a file','') Returns lReturnFlagIf lReturnFlag    Open file (lPathname,lRefNum) End If
