﻿Do inherited
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |YES |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Do inherited** **Returns** *return-value*
Description
***********
This command runs the superclass method with the same name as the currently executingmethod in the current subclass. For example, you can use **Do inherited** inthe $construct() method of a subclass to execute the $construct() method of itssuperclass. Similarly you can run the $destruct() method in a superclass from a subclass.

The flag is set if a method with the name of the current method is found in one of thesuperclasses.
Example
*******

.. code-block:: omnis
	:linenos:	;  $construct methodDo inherited      ;; do superclass construct;  $destruct methodDo inherited      ;; do superclass destruct;  a method in a superclass can also be called using the $inherited methodDo $inherited.$mymethod
