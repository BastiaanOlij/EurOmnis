﻿Begin SQL script
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Begin SQL script** ([*Carriage return*][,*Linefeed*])

Options
*******|Carriage return |If specified,the command appends a carriage return, after it appends each line of the statement |
|Linefeed |If specified,the command appends a line feed, after it appends each line of the statement |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.