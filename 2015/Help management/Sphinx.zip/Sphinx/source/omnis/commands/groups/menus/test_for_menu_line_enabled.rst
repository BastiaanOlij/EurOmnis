﻿Test for menu line enabled
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for menu line enabled** *line* or *instance-name*/*line*
Description
***********
This command tests whether the specified line of a menu instance is enabled. Youspecify the *menu-instance-name* and the *method-number* of the menu line youwant to test. It sets the flag if the specified line of the menu instance is enabled. Theflag is cleared if the menu instance is not installed on the menu bar.

This command may still return false if the current user has no access to the menu lineor if the line is disabled because there is no current record, even after *`Enable menu line <enable_menu_line.html>`_
* has been executed.

You can disable or enable menus using *`Disable menuline <enable_menu_line.html>`_
* and *`Enable menu line <enable_menu_line.html>`_
*.
Example
*******

.. code-block:: omnis
	:linenos:	;  If the menu line 'Large' is enabled then disable itInstall menu mViewTest for menu line enabled mView/LargeIf flag true    Disable menu line mView/LargeElse    Enable menu line mView/LargeEnd If;  Alternatively, you can see if a menu line is enabled;  using notationIf $imenus.mView.$objs.Large.$enabled    OK message  {Enabled}End If
