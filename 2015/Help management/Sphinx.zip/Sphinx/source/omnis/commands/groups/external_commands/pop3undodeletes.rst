﻿POP3UndoDeletes
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3UndoDeletes** (*socket*[,*stsproc*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3UndoDeletes** removes the deletion mark from all messages on thePOP3 server marked for deletion.
*
Socket* is an Omnis Long Integer field containing a socket opened to a POP3 serverusing *`POP3Connect 
`_
*.
*
StsProc* is an optional parameter containing the name of an Omnis method that *POP3UndoDeletes*calls with status messages. *POP3UndoDeletes* calls the method with no parameters,and the status information in the variable #S1. The status information logs protocolmessages exchanged on the connection to the server.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Remove the deletion mark from all messages currently marked for;  deletion on the POP3 Server lServerCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocketPOP3UndoDeletes (iSocket) Returns lStatus
