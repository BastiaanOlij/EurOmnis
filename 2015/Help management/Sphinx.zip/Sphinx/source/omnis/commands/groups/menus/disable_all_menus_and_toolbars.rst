﻿Disable all menus and toolbars
##############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Disable all menus and toolbars**
Description
***********Example
*******

.. code-block:: omnis
	:linenos:	;  Disable all menus and toolbars unless the correct;  password is enterdDisable all menus and toolbarsPrompt for input Password : Returns lPasswordIf low(lPassword)='password'    Enable all menus and toolbarsEnd If;  Alternatively, you can disable all user installed menu;  and toolbar instances by setting the $enabled propertyDo $imenus.$sendall($ref.$enabled.$assign(kFalse))Do $itoolbars.$sendall($ref.$enabled.$assign(kFalse))
