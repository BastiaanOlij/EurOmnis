﻿IMAPSetMessageFlags
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**IMAPSetMessageFlags** (*socket*,*messageuid*,*answered*,*deleted*,*draft*,*flagged*,*seen*[,*stsproc*,*responselist*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**IMAPSetMessageFlags** adds and removes flags for a message in the currently selected mailbox.  Each flag value can be passedas follows:
|**Value** |**Meaning** |
|kFalse |Remove the flag from the message. |
|kTrue |Add the flag to the message. |
|kUnknown |Leave the flag unchanged. |

Before using this command, you must select a mailbox using the *`IMAPSelectMailbox <imapselectmailbox.html>`_
* command

*Socket* is an Omnis Long Integer field containing a socket opened to an IMAP serverusing *`IMAPConnect <imapconnect.html>`_
*.

*Messageuid* is an Omnis Long Integer field containing the IMAP Unique Identifier (UID) of the message for which theflags are to be set.

*Answered* is the flag value (as defined above) for \Answered.

*Deleted* is the flag value (as defined above) for \Deleted.

*Draft* is the flag value (as defined above) for \Draft.

*Flagged* is the flag value (as defined above) for \Flagged.

*Seen* is the flag value (as defined above) for \Seen.

*Stsproc* is an optional parameter containing the name of an Omnis method that this commandcalls with status messages. This command calls the method with no parameters,and the status information in the variable #S1. The status information logs protocolmessages exchanged on the connection to the server.

*Responselist* is an optional parameter into which this command places response lines received from the IMAP server.  Before callingthis command, define the *responselist* to have a single Character column.  When the command returns successfully, the response listcontains the untagged and tagged responses received from the IMAP server as a result of executing this command.  These sometimes include unsolicited information, for example, anupdate on the current number of messages in the selected mailbox. Each line in the response list is a response line received from the server.See RFC 3501 for more details, if you need to handle this sort of information.

This command returns an integer, which is less than zero if an error occurred.  Possible error codes arelisted in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

**Note:**

You use **IMAPSetMessageFlags** to delete a message, by adding the \Deleted flag to the message.  You can then permanentlydelete all messages in the currently selected mailbox with the \Deleted flag set, by calling *`IMAPExpungeMessages <imapexpungemessages.html>`_
*
Example
*******

.. code-block:: omnis
	:linenos:	;  Mark message 142 in the currently selected mailbox as deletedCalculate iUID as 142Calculate iAnswered as kUnknownCalculate iDeleted as kTrueCalculate iDraft as kUnknownCalculate iFlagged as kUnknownCalculate iSeen as kUnknownIMAPSetMessageFlags (iIMAPSocket,iUID,iAnswered,iDeleted,iDraft,iFlagged,iSeen) Returns lStatusIf lStatus&lt;0    ;  Command failedEnd If
