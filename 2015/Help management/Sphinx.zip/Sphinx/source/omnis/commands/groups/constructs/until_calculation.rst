﻿Until calculation
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Until ***calculation*****
Description
***********
This command terminates a *`Repeat <repeat.html>`_
-***Until**conditional loop specifying a calculation as the condition. The calculation is evaluatedat the end of the loop that continues if the derived value is zero.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lCount as 1Repeat     ;; Repeat loop    Calculate lCount as lCount+1Until lCount&gt;=3OK message  {Count=[lCount]}     ;; prints ‚ÄòCount=3‚Äô
