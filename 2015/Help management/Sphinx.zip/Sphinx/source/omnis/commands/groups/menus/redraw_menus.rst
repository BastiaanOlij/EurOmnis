﻿Redraw menus
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |NO |NO |All |

Syntax
******
**Redraw menus**
Description
***********
This command redraws all instances of your own custom menus. When executing **Redrawmenus**, Omnis re-evaluates any square-bracket notation contained in the menutitles and lines before redrawing the menu bar.
Example
*******

.. code-block:: omnis
	:linenos:	;  Redraw the menus so that any with the title set to;  [tMenuName] are updated with the new menu nameCalculate tMenuName as 'MyMenu'Redraw menus
