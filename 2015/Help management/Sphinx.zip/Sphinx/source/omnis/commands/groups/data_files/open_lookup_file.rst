﻿Open lookup file
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |YES |YES |NO |All |

Syntax
******
**Open lookup file** {*lookup-name*,*data-file-name*,*file-class-name*,*index-field*}
Description
***********
This command opens an Omnis data file for use as a lookup file. You give each lookupfile a reference name which you use in subsequent `lookup() <../../../functions/groups/lookup/lookup.html>`_
 functions to selecta particular data file and file class.

You can open any Omnis data file as a lookup file, including any data file accessed via the ODB (Omnis Data Bridge). In a lookup file, you can use thefile classes to look up field values based on an indexed search. Each file class shouldconsist of at least two fields: the first is the index (usually a character field), thesecond is any field type. For example, the data file Lookup.df1 has a file class calledfCities with the following structure:
|**File name** |**Field1** |**Field2** |
|fPic |Char Indexed |Picture |
|fCities |Char Indexed |Char |

The parameters for **Open lookup** **file** are separated by&quot;,&quot;. The first parameter is a label that you create to become the reference tothat lookup &quot;channel&quot;. If you omit this label, Omnis assumes that you will useonly one lookup file whereupon you can use *`lookup() <../../../functions/groups/lookup/lookup.html>`_
 *without its firstparameter. The label you give to each lookup is case-insensitive and if you use the sameone twice, the previous lookup file is closed. A flag true is returned if the data file isfound and opened.

The example at the bottom opens a data file called Lookup.df1 and assigns the label&quot;City&quot; to the lookup channel. The City lookup uses the file class fCities withinthat data file and uses the first index to search for the required data. The OK messageuses *`lookup() <../../../functions/groups/lookup/lookup.html>`_
 *to searchthe first indexed field for an exact match with the value &quot;I&quot;. If the match isfound, the value of field 2 in the matched record is returned and displayed as part of theOK message. If no match is found, `lookup() <../../../functions/groups/lookup/lookup.html>`_
returns an empty value.

Note that the index and field are specified as *numbers* because your particularlibrary may not include the file class used in the lookup data file. If you omit eithernumber, the default is to use the first field as the index, and the second as the fieldvalue to be returned in the `lookup <../../../functions/groups/lookup/lookup.html>`_
() function.

Omnis opens the data file using the following rules. Omnis first tries to open the fileusing the supplied *data-file-name.* If this fails, and if the *data-file-name*does not contain any special characters used in pathnames (for example, under Windows&#145;:&#146; and &#145;\&#146;), then Omnis searches for the file.

Under Windows and Linux, Omnis searches the paths included in the Omnis environmentvariable. The Omnis environment variable must contain a semicolon separated list ofpathnames, for example:

C:\OMNIS\LOOKUPS;D:\OMNIS\LOOKUPS 

Under MacOSX, Omnis searches the System folder, Omnis folder and then the root of eachmounted volume, in that order.

The flag is set if the lookup is successful, that is, the data file is opened, the fileslot exists and the indexed field is indeed indexed. The lookup file is closed if thecommand is reversed (see `Begin reversible block <../../groups/constructs/begin_reversible_block.html>`_
).

You can close lookup files using *`Close lookup file <close_lookup_file.html>`_
*,but this is not necessary: all lookup files associated with a library are closedautomatically when the library quits.

You can maintain the data within the lookup file from within the library by: <ol>  <li>Adding the appropriate file classes to your library,</li>  <li>Changing the data file to the lookup file using *`Open    data file <open_data_file.html>`_
*,</li>  <li>Opening a window and editing/ inserting data in the usual way, and</li>  <li>Returning to the original data file.</li></ol>
You can also load multiple data files with `Open datafile <open_data_file.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	Open lookup file {City,Lookup.df1,fCities,1}If flag true    OK message  {The city you require is [lookup('City','I',2)]}End If;  You can open more than one file class within a particular data file by assigning;  a different label to each lookupOpen lookup file {City2,Lookup.df1,fCities2}Open lookup file {City,Lookup.df1,fCities}Open lookup file {Country,Lookup.df1,fCountries};  You can also open a lookup file accessed using the ODB (Omnis Data Bridge)Open lookup file {City,odb://127.0.0.1:5900:LookUpData,fCities,1}
