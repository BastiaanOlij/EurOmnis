﻿Close lookup file
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |YES |NO |NO |All |

Syntax
******
**Close lookup file** {*lookup-name*}
Description
***********
This command closes the lookup file which matches the reference name given in theparameters. Each lookup file is given a reference label when it is opened. In this exampleit is &quot;City&quot;.

If the reference label given in the *`Open lookup file <open_lookup_file.html>`_
*command is omitted, you can omit the lookup name in the **Close lookup file****command. If the specified lookup file is closed, the flag is set; if the lookup filedoesn't exist, the flag is cleared.
Example
*******

.. code-block:: omnis
	:linenos:	Open lookup file {City,Lookup.df1,fCities}If flag true    OK message  {The city you require is [lookup('City','I',2)]}End IfClose lookup file {City}
