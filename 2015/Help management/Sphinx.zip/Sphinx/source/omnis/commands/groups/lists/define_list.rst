﻿Define list
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |NO |YES |NO |All |

Syntax
******
**Define list** {*list-of-field-or-file-names*  (F1,F2..F3,F4)}
Description
***********
This command defines the variables or file class field names to be used as the columndefinitions for the current list; it should follow *`Setcurrent list <set_current_list.html>`_
*. The variables or fields used in the definition also describe thedata type and length for each column of data held. This command clears the definition anddata in the current list. When reversed, the contents and definition of the current listare restored to their former values. Duplicate names are ignored in your list of variablesor fields.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iList1;  define columns iCol1Date, iCol2Num &amp; iCol3Char for the current listDefine list {iCol1Date,iCol2Num,iCol3Char};  same as befire but ignores the duplicate reference to iCol3CharDefine list {iCol1Date,iCol2Num,iCol3Char,iCol3Char};  define the list based upon all the columns in the file class fCustomersDefine list {fCustomers};  Alternatively, you can avoid using Set Current List by using the following notationDo iList1.$define(iCol1Date,iCol2Num,iCol3Char);  define the list based upon a table,schema or query classDo iList1.$definefromsqlclass('myTableOrSchemaOrQueryClass');  FIXED LENGTH COLUMNS;  Normally, the length of a column is set by the type or length of the variable or field defined for;  the column, therefore the column length for a default character variable would be 10 million.;  However, when you define the list you can truncate the data stored in the column using;  VariableName/N. For example to use only the first 10 characters of the variable iCol3Char in column 3Define list {iCol1Date,iCol2Num,iCol3Char/10}
