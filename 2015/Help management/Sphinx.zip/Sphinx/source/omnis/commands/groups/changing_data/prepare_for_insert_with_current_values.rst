﻿Prepare for insert with current values
######################################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Prepare for insert with current values**
Description
***********
This command prepares Omnis for inserting new data into the main file using the valuesin the current record buffer as a starting point. `Prepare for insert with current values 
`_
differs from *`Prepare for insert 
`_
* in that thefields in the main file are not cleared.

In multi-user mode, the *Prepare for...* commands reread the current records fromthe data file if another user has edited a record.
Example
*******

.. code-block:: omnis
	:linenos:	Set main file {fAccounts}Prepare for insert with current valuesIf flag false    Quit method kFalseEnd IfEnter data Update files if flag set
