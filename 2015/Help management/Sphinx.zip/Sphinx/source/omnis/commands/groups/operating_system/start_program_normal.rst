﻿Start program normal
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Start program normal** {*program-name*}
Description
***********
This command starts up a Windows or Linux application at its normal screen size. Theprogram name must be the pathname of the executable file. You can also specify the fullpathname of a file, and other parameters, separated by a space from the program name.

The flag is set if the program is found.
Example
*******

.. code-block:: omnis
	:linenos:	;  If the program lPath exists start it in its normal screen sizeCalculate lPath as 'c:\program files\windows nt\accessories\wordpad.exe'Test if file exists {[lPath]}If flag true    Start program normal {[lPath]}End If
