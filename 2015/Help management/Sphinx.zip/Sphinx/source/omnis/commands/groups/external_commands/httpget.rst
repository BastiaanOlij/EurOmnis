﻿HTTPGet
#######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPGet** (*host*,*uri*[,*cgilist*,*hdrlist*,*service*|*port*,*secure* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
},*map*+ {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPGet** is a client command that submits a GET HTTP request to aWeb server.
*
Host* is a Character field containing the hostname or IP address of the Webserver.
*
URI* is a Character field containing the URI to GET from the Web Server. Forexample, &quot;/default.html&quot;, or &quot;/cgi-bin/mycgiscript&quot;
*
CGIList* is an optional parameter. It is an Omnis list with two character columns.The list contains the CGI arguments to be appended to the URI. There is one row for eachCGI argument. For example
|**Attribute** |**Value** |
|Name |John Smith |
|City |Podunk |
|Alive |On |
|Submit |Please |
**
Note: **Before the values are sent to the Web server, **HTTPGet**automatically performs any CGI encoding required to pass special characters in thearguments. There is no need to call the `CGIEncode <../a-e/cgiencode.html>`_
command.
*
HdrList* is an optional parameter. It is an Omnis list with two charactercolumns.. The list contains additional headers to add to the headers of the HTTP GETrequest. Note that the header name excludes the &#145;:&#146;, which **HTTPGet**inserts automatically when it formats the header.

For example
|**Header name** |**Value** |
|User-Agent |My Client |
|Content-type |text/html |
*
Service|Port *is an optional parameter that specifies the service name or portnumber of the server. If you specify a service name, the lookup for the port number occurslocally. If you omit this argument, it defaults to the port number specified in thehost, or if none is present, it defaults to 80 or 443, the default port for HTTP or HTTPS respectively(depending on the value of *Secure*).

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.

*Map+* is an optional Boolean parameter which when true indicates that plus characters in CGI parameter names and valuesin the CGIList are to be URL encoded as hex.
*
Socket* receives the result of the request. **HTTPGet** opens aconnection to the Web server, and formats and sends an HTTP GET request to the server. Ifthe command succeeds, it returns the socket number for the connection to the WEB server;otherwise, it returns an error number which is less than zero. After successfully issuing **HTTPGet**,you should call *`HTTPRead <httpread.html>`_
* to read the response from theserver; ALWAYS call *`HTTPClose <httpclose.html>`_
* to close the connectionand free the socket. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
*
HTTPGet* adds the following header fields by default:
|**Attribute** |**Value** |
|Accept |*/* |
|User-Agent |TigerLogic &#150; Omnis |
**
Note: **After calling **HTTPGet**, you can call *`HTTPSend <httpsend.html>`_
* to send your own content, before you read theresponse, provided that you include Content-type and Content-length headers in the *HdrList*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open a connection to the web server and read the server respose;  into lBufferCalculate iHostName as '0.0.0.0'Do lCGIList.$define(lAttribute,lValue)Do lCGIList.$add('Name','John Smith')Do lCGIList.$add('Email','john.smith@smiths.com')HTTPGet (iHostName,'/default',lCGIList) Returns iSocketHTTPRead (iSocket,lBuffer) Returns lCharCountHTTPClose (iSocket) Returns lStatus
