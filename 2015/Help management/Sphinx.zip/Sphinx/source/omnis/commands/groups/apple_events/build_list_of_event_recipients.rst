﻿Build list of event recipients
##############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |NO |NO |NO |MacOSX |

Syntax
******
**Build list of event recipients**
Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Begin reversible block    Set current list iListEnd reversible blockDefine list {iCol1,iCol2}     ;; define a list with 2 character variablesBuild list of event recipients     ;; populates the current list
