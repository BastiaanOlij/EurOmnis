﻿Apple events
############
`Command Index <../command_index.html>`_


`Commands
******** <apple_events#commands>`_
|`Build list of event recipients <apple_events/build_list_of_event_recipients.html>`_  |`Cancel event recipient <apple_events/cancel_event_recipient.html>`_  |`Disable receiving of Apple events <apple_events/disable_receiving_of_apple_events.html>`_  |`Enable receiving of Apple events <apple_events/enable_receiving_of_apple_events.html>`_  |
|`Prompt for event recipient <apple_events/prompt_for_event_recipient.html>`_  |`Send Core event <apple_events/send_core_event.html>`_  |`Send Core event with return value <apple_events/send_core_event_with_return_value.html>`_  |`Send Database event <apple_events/send_database_event.html>`_  |
|`Send Finder event <apple_events/send_finder_event.html>`_  |`Set event recipient <apple_events/set_event_recipient.html>`_  |`Use event recipient <apple_events/use_event_recipient.html>`_  |

