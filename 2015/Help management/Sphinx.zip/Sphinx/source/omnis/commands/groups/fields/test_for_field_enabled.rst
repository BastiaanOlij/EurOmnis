﻿Test for field enabled
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for field enabled** {*field-name*}
Description
***********
This command tests if the specified field on the top window instance is enabled, thatis, if it is not currently disabled with *`Disable fields <disable_fields.html>`_
*or by setting $enabled to `kFalse <../../../notation/root/constants/boolean_values.html>`_
. The flag is always cleared if there are no windowinstances open or if the field does not exist.
Example
*******

.. code-block:: omnis
	:linenos:	Test for field enabled {myField}If flag true    Disable fields {myField}Else    Enable fields {myField}End If;  or do it like thisIf $cwind.$objs.myField.$enabled    Do $cwind.$objs.myField.$enabled.$assign(kFalse)Else    Do $cwind.$objs.myField.$enabled.$assign(kTrue)End If
