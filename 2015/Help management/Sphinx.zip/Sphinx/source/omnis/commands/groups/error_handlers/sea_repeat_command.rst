﻿SEA repeat command
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Error handlers <../error_handlers.html>`_  |NO |NO |NO |All |

Syntax
******
**SEA repeat command**
Description
***********
This command attempts to repeat the command that caused an error; SEA stands for SetError Action. This is most useful after an out of memory condition. The command is alwaysused within an error handler. It is your responsibility to ensure that an endless loopingsituation between the error handler and the command is not created. Also, you must ensurethat any side effects of the original execution of the command which caused the error aretaken into account.
Example
*******

.. code-block:: omnis
	:linenos:	;  error handler traps an attempt to edit a locked record and the user presses the Break keyIf #ERRCODE=kerrCantlock    Yes/No message  {Do you want to cancel the edit?}    If flag true        Quit all methods    Else        SEA repeat command    End IfEnd If
