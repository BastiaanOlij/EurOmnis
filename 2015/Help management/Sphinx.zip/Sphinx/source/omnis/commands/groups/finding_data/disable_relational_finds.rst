﻿Disable relational finds
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |NO |YES |NO |All |

Syntax
******
**Disable relational finds**
Description
***********
This command reverses the action of *`Enablerelational finds <enable_relational_finds.html>`_
*. The default situation is reinstated, that is, the main file andits connected parent files are joined using the Omnis connection.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a sorted combined list of parent and child data;  using an existing omnis connectionDisable relational finds     ;; this is the default actionSet main file {fChild}Set current list lMyListDefine list {fChild,fParent}Set sort field fParent.IDBuild list from file  (Use sort)
