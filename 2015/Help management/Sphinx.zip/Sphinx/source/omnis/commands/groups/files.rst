﻿Files
#####
`Command Index <../command_index.html>`_


`Commands
******** <files#commands>`_
|`Build field names list <files/build_field_names_list.html>`_  |`Build file list <files/build_file_list.html>`_  |`Clear all files <files/clear_all_files.html>`_  |`Clear main &amp; connected <files/clear_main_&amp;_connected.html>`_  |
|`Clear main file <files/clear_main_file.html>`_  |`Clear range of fields <files/clear_range_of_fields.html>`_  |`Clear selected files <files/clear_selected_files.html>`_  |`Set closed files <files/set_closed_files.html>`_  |
|`Set main file <files/set_main_file.html>`_  |`Set memory-only files <files/set_memory-only_files.html>`_  |`Set read-only files <files/set_read-only_files.html>`_  |`Set read/write files <files/set_read_write_files.html>`_  |

