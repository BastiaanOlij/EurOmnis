﻿Popup menu
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |NO |NO |All |

Syntax
******
**Popup menu** *menu-name* (*x-coordinate*, *y-coordinate*)
Description
***********
This command installs the specified menu as a popup menu at the specified location. Thelocation is the *x,y* screen coordinate relative to the (0,0) position. UnderWindows, the coordinate (0,0) is the point directly under the menu bar within the Omnisapplication window. Under Linux and MacOSX, (0,0) is literally the top left corner of thescreen. If you omit the x,y coordinates the menu pops up at the current mouse position.

The *`mouseover() <../../../functions/groups/mouse/mouseover.html>`_
*function returns the mouse position relative to the open window and not the Omnisapplication window. Using this function to specify the x and y position of the popup menumay not produce the effect you want.
*
***Popup menu*** *behaves much like *`Popup menu from list 
`_
* except the source of thepopup is a user-defined menu. It clears the flag if the user does not select a menu line,otherwise, the line selected from the popup is executed.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prevent the default context menu appearing and;  open the menu mView instead;  $event of object on window classOn evRMouseDown     ;; requires the property $rmouseevents set to kTure    Process event and continue (Discard event)    Popup menu mView
