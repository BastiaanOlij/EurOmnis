﻿POP3Disconnect
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3Disconnect** (*socket*[,*stsproc*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3Disconnect** closes a connection to a POP3 server.
*
Socket* is an Omnis Long Integer field containing a socket opened to a POP3 serverusing *`POP3Connect 
`_
*.
*
StsProc* is an optional parameter containing the name of an Omnis method that **POP3Disconnect**calls with status messages. **POP3Disconnect** calls the method with noparameters, and the status information in the variable #S1. The status information logsprotocol messages exchanged on the connection to the server.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Close the connection to the POP3 server lServerCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocketPOP3Disconnect (iSocket) 
