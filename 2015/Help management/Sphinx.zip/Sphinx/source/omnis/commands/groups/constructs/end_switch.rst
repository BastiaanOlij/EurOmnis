﻿End Switch
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**End Switch**
Description
***********
This command terminates a *`Switch <switch.html>`_
* statement and definesthe point where method execution continues after each *`Case <case.html>`_
*statement.
Example
*******

.. code-block:: omnis
	:linenos:	;  Select the correct graph window depending on the graph type selected in the pGraphType parameter.;  Declare Parameter GraphType (Short integer (0 to 255))Switch pGraphType    Case kGRpie        Open window instance wGraphPieWindow    Case kGRbars,kGRarea,kGRlines        Open window instance wGraph2DWindow    Case kGR3D        Open window instance wGraph3DWindowEnd Switch
