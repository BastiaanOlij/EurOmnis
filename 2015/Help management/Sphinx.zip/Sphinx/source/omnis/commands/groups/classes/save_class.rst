﻿Save class
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Save class** {*class-name*}
Description
***********
This command writes the specified class, which normally contains changes made bynotation, into the library file on disk. You use **Save class** to make thechanges permanent. The flag is set if the class is successfully saved. A runtime erroroccurs if the specified class cannot be found.
Example
*******

.. code-block:: omnis
	:linenos:	;  get a reference to a window in the current librarySet reference lWinRef to $windows.wMyWindow;  create a pushbutton object on the windowSet reference lObjRef to lWinRef.$objs.$add(kPushbutton,5,5,23,120);  save the classSave class {wMyWindow};  opens the window with the new buttonOpen window instance wMyWindow
