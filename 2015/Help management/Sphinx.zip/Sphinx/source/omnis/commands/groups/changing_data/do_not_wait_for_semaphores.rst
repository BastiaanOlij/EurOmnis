﻿Do not wait for semaphores
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |NO |YES |NO |All |

Syntax
******
**Do not wait for semaphores**
Description
***********
This command causes all commands which set semaphores to return with a flag clear ifthe semaphore is not available.

If **Do not wait for semaphores **is run first in a method, it will ensurethat any subsequent commands that lock records, such as *Prepare for...*, *Update*commands, do not wait for records to be released. It causes the command to return a flagfalse and control to return immediately to the method, if a record is locked.
**
Semaphores
**
Semaphores are internal flags or indicators set in the data file to show other usersthat the record has been required elsewhere for editing. Semaphores are only set whenrunning in multi-user mode, that is, the data file is located on a networked server, a Macvolume or on a DOS machine on which SHARE has been run.

The commands which set semaphores are *`Prepare foredit 
`_
*, *`Prepare for insert 
`_
*, *`Update files <update_files.html>`_
* and *`Delete <delete.html>`_
*,and also, if prepare for update mode is on and the file acted upon is Read/Write, `Single file find <../../../commands/groups/finding_data/single_file_find.html>`_
,`Loadconnected records <../../../commands/groups/finding_data/load_connected_find_records.html>`_
, `Set read/write files <../../../commands/groups/files/set_read_write_files.html>`_
,all types of *`Find <../../../commands/groups/finding_data/find.html>`_
*, *`Next <../../../commands/groups/finding_data/next.html>`_
*, and *`Previous <../../../commands/groups/finding_data/previous.html>`_
*. *`Update files <update_files.html>`_
 *commands lock the whole data file whileindexes are re-sorted.

The *Edit/Insert* commands always wait for a semaphore, as do automatic find entryfields.

The example below illustrates how any command which causes a change in record lockingrequirements can fail (returning flag false). If, when in &#145;Prepare for&#146; mode, a `Single file find <../../../commands/groups/finding_data/single_file_find.html>`_
cannot lock the new record, it returns a flag false. This could mean either that therecord could not be found, or that it was in use by another workstation. For this reason,it was made read-only before the `Single file find <../../../commands/groups/finding_data/single_file_find.html>`_
and then changed to read/write. Note also that *`Update files <update_files.html>`_
*can fail if the file cannot be locked while the indexes are re-sorted.
Example
*******

.. code-block:: omnis
	:linenos:	Do not wait for semaphoresPrepare for editIf flag true    Set read-only files {fAccounts}    Single file find on fAccounts.Code (Exact match)    If flag false        Cancel prepare for update        Quit method kFalse    End If    Repeat        Set read/write files {fAccounts}    Until flag true    Repeat        Update files    Until flag trueEnd If
