﻿Signal error
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Error handlers <../error_handlers.html>`_  |NO |NO |NO |All |

Syntax
******
**Signal error** {*error-number*, *error-text* (e.g. 5, 'Error 5 occurred')}
Description
***********
This command reports a fatal error which can be either a user-defined error or abuilt-in Omnis error. A fatal error is any error that normally halts method execution andreports an error (for example, syntax error, or an out of memory error).

The fatal error is reported with the specified error code and text. Any error handlerfor that code will be invoked. If there is no error handler or the error handler does notmake a set error action (SEA), the debugger is invoked, if available. Otherwise, executionhalts with the error message.

This command is useful for trapping user-defined errors, and is a convenient tool fortriggering an error situation inside Omnis for whatever condition you may want to specify.
Example
*******

.. code-block:: omnis
	:linenos:	Test for only one userIf flag false    Signal error {99,'Test for one user failed'}End If
