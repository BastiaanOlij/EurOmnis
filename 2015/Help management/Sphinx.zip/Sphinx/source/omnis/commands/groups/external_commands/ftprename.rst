﻿FTPRename
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPRename** (*socket*,*oldname*,*newname*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPRename** renames a remote file.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
OldName* is an Omnis Character field containing the pathname of the file to rename.
*
NewName* is an Omnis Character field containing the new pathname for the file
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
**
Note: **Local filename conventions may not be acceptable to the remote system.
Example
*******

.. code-block:: omnis
	:linenos:	;  rename a file or folder in the current working directoryFTPRename (iFTPSocket,lFileName,lNewFileName) Returns lErrCodeIf lErrCode    FTPGetLastStatus (iServerReplyText) Returns lErrCode    OK message FTP Error {[con(&quot;Error renaming &quot;,lFileName,&quot; to &quot;,lNewFileName,kCr,&quot;Details follow:&quot;,kCr,iServerReplyText)]}End If
