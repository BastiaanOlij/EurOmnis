﻿Queue close
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue close** *window-instance-name*
Description
***********
This command queues a &quot;close window&quot; event for the specified window instanceas if the user had selected the close option (system menu under Windows and Linux, or closebox under MacOSX).

The specified window instance is closed, and an `evClose <../../../notation/root/iwindows/window.html>`_
 event is produced. If thespecified window instance does not exist, the command has no effect. If you omit thewindow instance name, the top window instance at the time of execution will be closed, andan `evClose <../../../notation/root/iwindows/window.html>`_
 event is generated.
Example
*******

.. code-block:: omnis
	:linenos:	Open window instance wMyWindow/wInst1Open window instance wMyWindow/wInst2Queue close      ;; close wInst2, the top instance
