﻿Disable fields
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |NO |NO |NO |All |

Syntax
******
**Disable fields** {*list-of-field-names* (Name1,Name2,...)}
Description
***********
This command disables the specified field or list of fields, making them inactiveduring `Enter data <../../groups/enter_data/enter_data.html>`_
 and `Prompted find <../../groups/finding_data/prompted_find.html>`_
. Thus the dataentry cursor skips a disabled entry field when in data entry mode, find, and so on, anddisabled pushbuttons cannot be clicked. If an entry field with scroll bar is disabled, youcan tab to it but not change the data. You can reverse **Disable fields** orenable a display field using *`Enable fields <enable_fields.html>`_
*.
Example
*******

.. code-block:: omnis
	:linenos:	;  disable 2 fieldsBegin reversible block    Disable fields {myField1,myField2}End reversible blockDo method CheckCreditQuit method ;  now this method ends and the fields are re-enabled as they are in a reversible block;  to disable a single field on the current windowDo $cwind.$objs.myField1.$enabled.$assign(kFalse);  to disable all fields on the current window like thisDo $cwind.$objs.$sendall($ref.$enabled.$assign(kFalse))
