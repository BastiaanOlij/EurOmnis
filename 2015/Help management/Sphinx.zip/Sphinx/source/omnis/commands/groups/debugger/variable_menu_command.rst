﻿Variable menu command
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |NO |All |

Syntax
******
**Variable menu command:** *command* {*list-of-field-or-file-names*  (F1,F2..F3,F4)}

Commands
********|Set Break On Variable Change | |
|Clear Break On Variable Change | |
|Set Break On Calculation | |
|Clear Break On Calculation | |
|Store Min & Max | |
|Do Not Store Min & Max | |
|Add To Watch Variables List | |
|Remove From Watch Variables List | |
|Send Value To Trace Log | |
|Send Minimum To Trace Log | |
|Send Maximum To Trace Log | |
|Send All To Trace Log | |
|Open Value Window | |
|Open Values List... | |

Description
***********
This command performs one of the Variable context menu options on the specified fieldor list of fields. You can specify one of the following Variable menu options:
**
****Set break on variable change*** *sets a variable change breakpoint foreach variable in the list.
**
****Clear break on variable change**** **clears any variable changebreakpoint for each variable in the list. If no variable names list is specified, allcurrent variable change breakpoints are cleared.
**
****Set break on calculation** sets a calculation breakpoint for each variablein the list. You can set the calculation for each variable using *Set break calculation*.Setting calculation breaks for more than a very few variables will cause methods to runvery slowly.
**
****Clear break on calculation** clears any variable change breakpoints for eachvariable in the list. If no variable names list is specified, all current calculationbreakpoints are cleared.
**
****Store min &amp; max** causes minimum and maximum values to be stored foreach variable in the list.
**
****Do not store min &amp; max** clears &#145;Store min and max&#146; mode foreach variable on the list. If no variables are specified, all current &#145;Store min andmax&#146; are cleared.
**
****Add to watch variables list** marks each variable on the list as a watchvariable.
**
****Remove from watch variables list*** *marks each variable on the list asnot watched. If no variables are specified, all variables are marked as not watched. Notethat variables with breakpoints or with &#145;Store min and max&#146; mode set alwaysappear in the watch variables list.
**
****Send value to trace log**** **adds a line to the trace log for eachvariable on the list. If no variables are specified, all values for all variables on thewatch variables list are sent to the trace log.
**
****Send minimum to trace log** adds a line to the trace log for each variableon the list for which &#145;Store min and max&#146; is set. If no variables are specified,the minimum values for all variables for which &#145;Store min and max&#146; is set aresent to the trace log.
**
****Send maximum to trace log**** **adds a line to the trace log for eachvariable on the list for which &#145;Store min and max&#146; is set. If no variables arespecified, the maximum values for all variables for which &#145;Store min and max&#146; isset are sent to the trace log.
**
****Send all to trace log**** **adds a value line to the trace log for eachvariable on the list, and adds minimum and maximum line(s) to the trace log for eachvariable on the list for which &#145;Store min and max&#146; is set. If no variables arespecified, this is carried out for all appropriate variables on the watch variables list.
**
****Open value window** opens a value window for each variable on the list, orfor every variable on the watch variables list if no variables are specified. There is alimit on the number of windows that you can open at once.
**
****Open values list** opens the values list for each of the variable typesgiven in the command parameters. For example, *Variable menu command: open values list{lValue, iCount}* opens two values lists, one for Local variables, the other forInstancel variables. There is one values list for each file class, so if more than onevariable name in a particular file class is specified the values list for that file willonly be opened once. There is also a limit on the number of windows that you can open atonce.
Example
*******

.. code-block:: omnis
	:linenos:	;  pause method execution when the value of iValue changesCalculate iValue as 5Variable menu command: Set Break On Variable Change {iValue}Calculate iValue as 2Variable menu command: Clear Break On Variable Change {iValue};  open two variable windows one showing the value of lCount and the other the value of iValueCalculate lCount as 10Variable menu command: Open Value Window {lCount,iValue}
