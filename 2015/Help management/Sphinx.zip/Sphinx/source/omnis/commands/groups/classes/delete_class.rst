﻿Delete class
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Delete class** {*class-name*}
Description
***********
This command deletes the specified library class. It is not possible to delete a fileclass, an installed menu or an open window. It is also not possible to delete a class ifone of its methods is currently executing, that is, if it is somewhere on the methodstack. Deleting a class does not reduce the library file size. It does, however, createfree library file blocks so that creation of another class may be possible without furtherincrease in library size. Errors, such as attempting to delete a name that does not exist,simply clear the flag and display an error message.
Example
*******

.. code-block:: omnis
	:linenos:	Delete class {sUser}
