﻿FTPChmod
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPChmod** (*socket*,*filename*,*mode*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPChmod** changes the protection mode of a remote file on theconnected FTP server.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
Filename* is an Omnis Character field containing the pathname of the remote file.
*
Mode* is an Omnis Character field containing the system-dependent file-protectionspecifier to apply to the named file. Many FTP servers accept the Linux-styleOwner/Group/World 3-digit Read/Write/Execute scheme (for example*,* 754 = OwnerRead/Write/Execute, Group Read/Execute World Read-Only). Consult the documentation for theremote system to determine the acceptable syntax for this argument.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  allow owner to read/write &amp; execute, group to read &amp; execute and world to read-only this fileCalculate lFileMode as 754FTPChmod (iFTPSocket,lFileName,lFileMode) Returns lErrCode
