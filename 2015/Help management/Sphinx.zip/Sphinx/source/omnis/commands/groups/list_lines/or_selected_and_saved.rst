﻿OR selected and saved
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**OR selected and saved** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command performs a logical OR of the Saved selection with the Current selection.To allow sophisticated manipulation of data via lists, a list can store two selectionstates for each line; the &quot;Current&quot; and the &quot;Saved&quot; selection. TheCurrent and Saved selections have nothing to do with saving data on the disk; they are nomore than labels for two sets of selections. The lists may be held in memory and neversaved to disk: they will still have a Current and Saved selection state for each line butthey will be lost if not saved. When a list is stored in the data file, both sets ofselections are stored.

You can specify a particular line in the list by entering either a number or acalculation.

The **OR selected and saved** command performs a logical OR on the Savedand Current states and puts the result into the Current selection. Hence, if either orboth the Current and Saved states are selected, the Current state becomes selected, but ifboth states are deselected, the resulting Current state will remain deselected.
**
Logic Table (S=selected, D=deselected)
**|**Saved** |**Current** |**Resulting Current State** |
|S |S |S |
|D |S |S |
|S |D |S |
|D |D |D |

The **All lines** option performs the OR on all lines of the current list. Thefollowing example selects all lines of the list.
Example
*******

.. code-block:: omnis
	:linenos:	;  Lines 3 and 5 remain selected as line 3 is the;  only line selected in the saved list and line 5 is;  the only line selected in the current listSet current list lMyListDefine list {lCol1}For lCol1 from 1 to 6 step 1    Add line to list {lCol1}End ForSelect list line(s) {3}Save selection for line(s) (All lines)Deselect list line(s) (All lines)Select list line(s) {5}OR selected and saved (All lines)
