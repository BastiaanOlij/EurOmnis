﻿Show Omnis maximized
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Show Omnis maximized**
Description
***********
This command shows Omnis at its maximum size within the application window. Thiscommand performs the same action as the **Maximize** option in the **System**menu and the Maximize button on the application window.
Example
*******

.. code-block:: omnis
	:linenos:	;  Maximize Omnis after processingShow Omnis minimizedFor lCount from 1 to 100000 step 1    ;  delayEnd ForShow Omnis maximized
