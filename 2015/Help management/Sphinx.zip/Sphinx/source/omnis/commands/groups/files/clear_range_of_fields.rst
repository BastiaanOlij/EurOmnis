﻿Clear range of fields
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear range of fields** *****first-data-name*** to ***final-data-name*
Description
***********
This command clears the specified range of fields from the current record buffer.

Note that *first-data-name* and *last-data-name* identify the first and lastfield of the range to be cleared, in the order that the fields occur in the current recordbuffer. In certain current record buffers, for example the instance variables of aninstance, the order of the fields in the current record buffer is the order in which thefields were created, not the alphabetic order in which they are displayed in the variablepane of the method editor.

When used in a reversible block, the fields cleared are restored when the methodterminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear the current record buffer of fields Surname to Balance;  from fAccounts and redraw the current window instanceClear range of fields fAccounts.Surname to fAccounts.BalanceDo $cinst.$redraw()
