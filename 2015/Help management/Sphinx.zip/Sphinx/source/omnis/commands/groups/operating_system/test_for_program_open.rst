﻿Test for program open
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Test for program open** {*program-name*}
Description
***********
This command tests whether the specified program is running. The flag is set if thespecified program is running. You can use this command under Windows and Linux.

The program name can be the Windows module name, or the full pathname for the program.Under Windows NT/2000, the file PSAPI.DLL must be present in the Omnis directory or on theWindows path for this command to work. PSAPI.DLL is supplied in the Omnis directory of theWindows NT/2000 version of Omnis Studio.
Example
*******

.. code-block:: omnis
	:linenos:	;  Test to see if the program lPath is openCalculate lPath as 'c:\program files\windows nt\accessories\wordpad.exe'Test for program open {[lPath]}If flag false    Start program normal {[lPath]}End If
