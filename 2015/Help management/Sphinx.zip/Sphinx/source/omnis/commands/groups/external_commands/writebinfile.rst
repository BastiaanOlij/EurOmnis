﻿WriteBinFile
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**WriteBinFile** (*pathname*, *binfld* [, *start* [, *length*]] ) **Returns** *return-value*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

**WriteBinFile** writes binary data to the file system or data fork (notthe resource fork).
**
Note for MacOSX Users:** *`ReadBinFile <readbinfile.html>`_
* and **WriteBinFile**are useful for reading and writing documents but not system and application files.
*
Pathname* is a character field containing the full path of the file to which towrite. If the output file does not already exist, **WriteBinFile** createsit.

*Binfld* is a binary field from which to write the data.
*
Start* is an integer field specifying the byte position in the file where writingshould begin. If the parameter is not used, the command defaults to 0 (zero), that is, thebeginning of the file. To append data to an existing file, set *Start *to -1 (minusone).
*
Length* is an integer field containing the number of bytes to write. If theparameter is not used, the value defaults to the length of the Binary field.
*
Return-value* is an integer field that is the number of bytes written if no errorcode is returned. Otherwise, it is an error code, one of:

-1: End of file

-2: Out of memory

-10: File not found

-11: Bad file name

-12: Volume not found

-20: IO error

-100: Incorrect number of parameters

-101: Bad parameter value

-998: File too large
Example
*******

.. code-block:: omnis
	:linenos:	;  write the binary class data of the window class 'MyWindow' to a file named;  'binfile' in the root of the omnis treeCalculate lPathname as con(sys(115),'binfile')Calculate lBinfld as $clib.$windows.MyWindow.$classdataWriteBinFile (lPathname,lBinfld) Returns lNumbytesOK message  {[lNumbytes] bytes written}
