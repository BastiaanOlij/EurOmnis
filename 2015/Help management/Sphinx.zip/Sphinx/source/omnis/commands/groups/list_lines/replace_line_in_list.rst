﻿Replace line in list
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Replace line in list** {*line-number* (*values*) {default is current line}}
Description
***********
This command transfers field values from the current record buffer to the correspondingfields in the current list. Alternatively, it is possible to specify a comma-separatedlist of values enclosed in brackets after the line number. In this case, the values storedin the specified line of the list are set up from the values in the brackets and not fromthe variables specified when the list was defined. 

will store 'abc' into the first column of the final line of the current list, leave thevalue of the second column unchanged, and load the result of LVAR12+3 into the thirdcolumn. If too few values are specified, the other columns will be left unchanged; if toomany values are specified, the extra values are ignored. Any conversions required betweendata types are carried out.

If the line number specified in the command line is empty, or if it evaluates to zero,the current line is used. If the list is empty or if the line is beyond the current end ofthe list, the flag is cleared.
Example
*******

.. code-block:: omnis
	:linenos:	;  Replace Harry with Arnold and increment;  the age of everybody in the list by 1Set current list lMyListDefine list {lName,lAge}Add line to list {('Fred',10)}Add line to list {('George',20)}Add line to list {('Harry',22)}Add line to list {('William',31)}Add line to list {('David',62)}Replace line in list {3 ('Arnold',47)}For each line in list from 1 to lMyList.$linecount step 1    Load from list    Calculate lAge as lAge+1    Replace line in list {(,lAge)}End For
