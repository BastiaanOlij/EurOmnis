﻿ReadBinFile
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**ReadBinFile** (*pathname*, *binfld* [, *start* [, *length*]] ) **Returns** *return-value*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

**ReadBinFile** reads binary data from the file system or data fork (notthe resource fork).
**
Note for MacOSX Users:** **ReadBinFile** and *`WriteBinFile <writebinfile.html>`_
* are only useful for reading and writing thedata fork of files.
*
Pathname* is a character field containing the full path of the file to read.
*
Binfld* is a binary field in which the data is stored.
*
Start* is an optional parameter specifying an integer field that contains the byteposition in the file where the command should start reading. Defaults to 0 (zero), thatis, the beginning of the file.
*
Length* is an optional parameter specifying an integer field containing the numberof bytes to read. If the parameter is not used, the value defaults to the length of thefile.
*
NumBytes* is a long Integer that is the number of bytes read, if no error occurs.Otherwise, it is an error code, one of:

-1: End of file

-2: Out of memory

-10: File not found

-11: Bad file name

-12: Volume not found

-20: IO error

-100: Incorrect number of parameters

-101: Bad parameter value

-998: File too large
Example
*******

.. code-block:: omnis
	:linenos:	;  read the binary data from the file lPathnameCalculate lPathname as con(sys(115),'binfile')ReadBinFile (lPathname,lBinfld) Returns lNumbytesOK message  {[lNumbytes] bytes read}
