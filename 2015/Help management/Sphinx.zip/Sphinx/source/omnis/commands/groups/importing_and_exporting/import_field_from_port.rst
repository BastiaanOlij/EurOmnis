﻿Import field from port
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Import field from port** **into ***field-name***** ([*Single character*][,*Leave in buffer*][,*Clear buffer*][,*Do not wait*])

Options
*******|Single character |If specified,the command reads a single character at a time |
|Leave in buffer |If specified,the command leaves the data it returns in the buffer,meaning that the next call to the command will return the same value |
|Clear buffer |If specified,the command clears the import buffer before executing |
|Do not wait |If specified,the command will not wait until data is available |

Description
***********
This command reads a line of characters from the current port to the specified field. **Importfield from port** lets you read fields from a port without using a window and *`Import data <import_data.html>`_
*. Usually the command reads a whole line at atime but there are options which modify this:
**
****Single character** tells Omnis to read a single character at a time. If thefield is a Character or a National field, it is set to have a length of one, containingthe single character imported from the port. If the field is a Number field, the fieldvalue is set to the ASCII code of the single character imported from the port.
**
****Leave in buffer** tells Omnis to read the string or single character but notremove it from the buffer. Therefore, the next* ***Import field from port**command will read exactly the same value.
**
****Clear buffer** clears the import buffer so that previously received valuesare ignored.
**
****Do not wait**** **prevents Omnis from waiting until a string or characteris available.

An error will occur if the import port has not been opened; Omnis clears the flag ifnothing has been read. Do not mix the `Import data <import_data.html>`_
 and****Import field from port** commands because they use the input buffer indifferent ways.
Example
*******

.. code-block:: omnis
	:linenos:	Set port name {COM1:}Prepare for import from port {One field per line}Repeat    Import field from file into lImportFieldUntil lImportField='start data'Do method ImportDataClose import file
