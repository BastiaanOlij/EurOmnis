﻿Read file as character
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Read file as character** (*refnum*, *character*-*variable* [,*start*-*position*] [,*num*-*characters*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command reads a file, or part of a file, into a character variable. You specifythe file reference number returned by the *Open file* command in *refnum*. Thetext read from the file is returned in *character-variable*.

If you specify the *start-position*, the file is read at that absolute characterposition (0 is the first character in the file, 1 is the second, and so on), otherwise itbegins at the current position (the first character when the file is first opened). If youspecify *num-characters*, only that many characters are read, otherwise the file isread until the end of the file is reached.

If you specify a *start-position* of 0 and *num-characters* equal to 0, thefile pointer is reset to character position 0 in the file. If a *start-position* of-1 is given, the file pointer is reset to the end of the file. For both cases an empty *character-variable*buffer is returned.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs. Note the special case for end of file. In this case, the command returns theerror code &#150;39, but may still have read some data.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a text file and read it's contents into the character;  variable lCharVarDo FileOps.$putfilename(lPathname,'Select a text file','*.txt') Returns lReturnFlagIf lReturnFlag    Open file (lPathname,lRefNum)     Read file as character (lRefNum,lCharVar) Returns lErrCode    Close file (lRefNum) End If
