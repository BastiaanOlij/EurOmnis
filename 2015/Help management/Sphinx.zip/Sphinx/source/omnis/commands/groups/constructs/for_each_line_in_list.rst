﻿For each line in list
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |NO |All |

Syntax
******
**For each line in list** ([*Selected lines only*][,*Descending*])** from ***start*** to ***stop*** step ***step*****

Options
*******|Selected lines only |If specified,the for loop only operates on the selected lines in the list |
|Descending |If specified,the for loop steps through the list from the largest line number to the smallest line number |

Description
***********
This command marks the beginning of a loop that processes the lines of the currentlist. You must specify the current list before executing the For loop. The For loop is aconvenient way to write *`While <while_calculation.html>`_
/`End While <end_while.html>`_
* loops to step through each line of a list. With the**Selected lines only** option, the loop will skip over any lines encountered thatare not selected.

The **Start **value specifies the line in the list at which method execution ofthe For loop starts. The loop continues until the processed line exceeds or is equal tothe **Stop** value. If the **Step**** **value** **is not specified, thedefault value of 1 is used. The values involved must all be integers. The **Descending**option tells Omnis to step through the list from a high line number to a low line number.The **Start** and **Stop** values are swapped if the **Stop** value is lessthan the **Start** value.

You can use *`Jump to start of loop <jump_to_start_of_loop.html>`_
* withinthe loop to continue the next iteration of the loop. Similarly, *`Break to end of loop <break_to_end_of_loop.html>`_
* will exit the loopprematurely.
*
***For each line in list** operates on the current list. The matching *`End For <end_for.html>`_
* will also operate on the current list. Unpredictablebehavior will result if the current list is changed and not restored within the *For/`End For <end_for.html>`_
* construct.
Example
*******

.. code-block:: omnis
	:linenos:	Prepare for printSet current list iMyListFor each line in list from 1 to iMyList.$linecount step 1    Load from list    Print recordEnd ForEnd print;  this is equivalent to the method belowPrepare for printSet current list iMyListCalculate iMyList.$line as 1While iMyList.$line&lt;=iMyList.$linecount    Load from list    Print record    Calculate iMyList.$line as iMyList.$line+1End WhileEnd print
