﻿Enable enter &amp; escape keys
##############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Enter data <../enter_data.html>`_  |NO |YES |NO |All |

Syntax
******
**Enable enter &amp; escape keys**
Description
***********
This command enables the Enter key on all platforms; on Windows and Linux, it alsoenables the Escape key, whereas on MacOSX it also enables the Escape key and Cmnd-period.It reverses the action of the *`Disableenter &amp; escape keys <disable_enter_&amp;_escape_keys.html>`_
* command.

In some libraries where the user may accidentally press Enter and terminate enter datamode, it is useful to disable the Enter key.
Example
*******

.. code-block:: omnis
	:linenos:	;  $construct of window classDisable enter &amp; escape keysEnter data If flag true    OK message  {OK Button Pressed}End IfEnable enter &amp; escape keys
