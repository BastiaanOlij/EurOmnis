﻿Set current list
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |NO |YES |NO |All |

Syntax
******
**Set current list** *list-or-row-name*
Description
***********
This command sets the current list, that is, the list to be processed in the subsequentlist commands. You can make any type of list the current list, including local, class, andlibrary variables of list data type. If you use this command as part of a reversibleblock, the current list reverts to its former value when the method containing thereversible block finishes.

See also **`Define list <define_list.html>`_
.**
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iMyListDefine list {fCustomers}Set main file {fCustomers}Build list from file on fCustomers.CustomerID
