﻿Add line to list
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Add line to list** {*line-number* (*values*) {default is end of list}}
Description
***********
This command adds a new line to the current list using the current field values in theCRB or values you specify in the list of values. Any conversions required between datatypes are carried out automatically. The flag is cleared if the line cannot be added,either because the maximum number of lines in the list or the memory limits have beenexceeded.

You can specify the line number at which the new line is inserted, otherwise the lineis added to the end of the list. If the line number you specify in the command line isempty or evaluates to zero, the new line is added to the end of the list.  If too fewvalues are specified, the other columns are left empty; if too many values are specified,the extra values are ignored. When you supply a comma-separated list of values, the valuesin the CRB are ignored.
Example
*******

.. code-block:: omnis
	:linenos:	;  Create a fixed list of string and numeric dataSet current list lMyListDefine list {lName,lAge}Add line to list {('Fred',10)}Add line to list {('George',20)};  Insert the values of the variables lName and lAge to lMyList at line 1Calculate lName as 'Harry'Calculate lAge as 22Add line to list {1 (lName,lAge)};  If no values are defiened, the current values of the variables;  used in the Define List are addedAdd line to list;  Alternatively, you can use the $add() method to add lines to your listDo lMyList.$define(lName,lAge)Do lMyList.$add('Fred',10)Do lMyList.$add('George',20);  You can also use the $addbefore() and $addafter() methods to add;  lines at a specific position in the listDo lMyList.$addbefore(1,'Harry',22)
