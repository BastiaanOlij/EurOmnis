﻿Rename data
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Rename data** {*file-name*/*new-slot-name*}
Description
***********
This command renames the data for a specified file class in a data file so that thedata will then belong to a file with a different name; that is, it renames a slot. Theexisting file class name and the new slot name are specified as parameters.

The specified file class is disconnected from the data, and an empty slot and indexesfor that file will be created as soon as that file is accessed again.

If the specified file name does not include a data file name as part of the notation,the default data file for that file is assumed.

If the file is closed or memory-only, the command does not execute and returns flagfalse.

If you are not running in single user mode, Omnis automatically tests that only oneuser is logged onto the data file (the command fails with flag false if this is not true),and further users are prevented from logging onto the data until the command completes.

This command sets the flag if it completes successfully and clears the flag otherwise.The command is not reversible.
Example
*******

.. code-block:: omnis
	:linenos:	Rename data {fCustomers/fCustomersArchive}If flag true    OK message  {File archived}Else    OK message  {Cannot archive while more than 1 user is logged on}End If
