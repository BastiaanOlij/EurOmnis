﻿Test if file exists
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |All |

Syntax
******
**Test if file exists** {*file-name*}
Description
***********
This command tests if the specified file exists and can be opened. The flag is set ifthe file exists and can be opened. Otherwise, it is cleared. You can use this command toprevent the user from overwriting existing files with print files, and so on. To performthe test, the command opens the file in shared read mode, and then closes it, if the openwas successful.

To just test for the existence of a file, without opening it, use the Fileops function *FileOps.$doesfileexist*.

You cannot use this command to check for the existence of a data file if the data fileis in use by another workstation. Use *`Open data file <../../../commands/groups/data_files/open_data_file.html>`_
* forthis type of checking.

You can use this command to test for the existence of a data file that is to be accessed using the ODB (Omnis Data Bridge).Specify the location of the file using the ODB syntax:
<ul>  <li>**odb://[address:port:]name**</li></ul>
where *address:port* is the TCP/IP address and port numberof the ODB server, e.g.  127.0.0.1:5900, and *name* is the name of a data file accessed using theODB server.  You can omit address:port:, in which case Omnis uses the address and port stored in the`$odbserver <../../../notation/root/prefs.html>`_
 root preference.  Note that the value of`$odbserver <../../../notation/root/prefs.html>`_
 is stored in the file odb.txt in the studiofolder of the Omnis installation tree.
Example
*******

.. code-block:: omnis
	:linenos:	;  If the file myfile already exists in the root;  of the studio tree show a ok messageCalculate lPath as con(sys(115),'myfile')Test if file exists {[lPath]}If flag true    OK message  {The file [lPath] already exists}Else    Create file ([lPath]) End If
