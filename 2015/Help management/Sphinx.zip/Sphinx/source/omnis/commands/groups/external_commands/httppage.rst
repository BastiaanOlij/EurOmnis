﻿HTTPPage
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPPage** (*url*[,*service*|*port*]) **Returns** *html-text*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPPage** is a client command that retrieves the content of the Webpage specified by the URL, into an Omnis Character or Binary variable.
**
Note: ****HTTPPage** allows you to get HTML text source through aserver, transparently and without additional coding.
*
URL* is an Omnis Character field containing a standard Web page URL of the formhttp://domaininfo.xxx/path/webpagepage.  If you prefix the URL with https://, the commandattempts to use a secure connection.
*
Service|Port *is an optional parameter that specifies the service name or portnumber of the server. If you specify a service name, the lookup for the port number occurslocally. If you omit this argument, it defaults to the port number specified in the URL,or if none is present, it defaults to 80 or 443, the default port for HTTP or HTTPS respectively.

The primary role of **HTTPPage** is to grab, simply and quickly, the HTMLtext source of the page specified by the URL. The URL may also specify a CGI name andarguments, but it is simpler to access CGIs by using the *`HTTPPost <httppost.html>`_
*or *`HTTPGet <httpget.html>`_
* functions.

If an error occurs, the command returns a negative number to *Page.* Otherwise, *Page*receives the contents of the specified URL. In other words, it receives the complete HTTPresponse for the URL, including the status line and the headers. Possible error codes arelisted in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Read the html content from lURL into the character variable lHtmlPageCalculate lUrl as 'http://www.omnis.net/news/index.html'HTTPPage (lUrl) Returns lHtmlPage
