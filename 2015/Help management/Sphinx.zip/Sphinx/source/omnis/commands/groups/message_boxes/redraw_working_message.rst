﻿Redraw working message
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |NO |NO |NO |All |

Syntax
******
**Redraw working message**
Description
***********
This command redraws the text in the working message after evaluating any squarebracket notation. Omnis does not increment the working message count and does nothing ifthere is no open working message. 
Example
*******

.. code-block:: omnis
	:linenos:	;  Redraw the working message to update the record;  counterWorking message  {Processing Record [lCount]}For lCount from 1 to 20000 step 1    Redraw working messageEnd For
