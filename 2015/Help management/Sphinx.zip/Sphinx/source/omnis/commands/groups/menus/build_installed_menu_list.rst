﻿Build installed menu list
#########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |YES |NO |All |

Syntax
******
**Build installed menu list** ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |

Description
***********
This command builds a list containing the name of all menu instances on the main Omnismenu bar, starting from the left. All the standard Omnis menus such as ****File** **and****Edit**** are ignored. The list is built in the current list for which you mustdefine the following columns:
|**Column 1 (Character)** |**Column 2 (Character)** |
|Menu instance name |Description for menu class (if one has been entered) |

When you use the **Clear list** option you get column 1 only defined as #S5 with a15 character column width. With this option, the command becomes reversible.

Menu instances from libraries other than the current library are prefixed with theirlibrary names. The flag is cleared if the command fails due to a shortage of memory.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list of all menu instances installed on the;  main Omnis menu barSet current list lMenuListDefine list {lMenuName,lMenuDesc}Build installed menu list;  Alternatively, you can use $makelistDo $imenus.$makelist($ref.$name) Returns lMenuListDo lMenuList.$redefine(lMenuName)
