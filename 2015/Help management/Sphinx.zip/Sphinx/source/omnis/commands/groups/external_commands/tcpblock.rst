﻿TCPBlock
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPBlock** (*socket*,*option* {Zero for blocking; Non-zero for non blocking}) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

The **TCPBlock** command makes a socket blocking or non-blocking.

The blocking state of a socket affects the commands *`TCPAccept <tcpaccept.html>`_
*,*`TCPReceive <tcpreceive.html>`_
*, *`TCPSend <tcpsend.html>`_
*,and *`HTTPSend <httpsend.html>`_
*. If you use **TCPBlock** tochange the blocking state of sockets returned for FTP connections, this could result inundesirable behavior of the FTP commands.

If a socket is blocking, the commands listed above wait until they can completesuccessfully; in other words, a receive waits until it has received some data, a sendwaits until it has sent some data, and an accept waits until an incoming connectionrequest arrives.

If a socket is non-blocking, the commands listed above will complete successfully ifthey can do so immediately; if not, they will return the error code &#150;10035, whichmeans that the command needs to block before it can complete successfully.
*
Socket* is an Omnis Long Integer field containing a number identifying a validsocket.
*
Option* is an Omnis integer field. Non-zero means non-blocking and zero meansblocking.
*
Status* is an Omnis Long Integer field which receives the value zero for success, oran error code &lt; 0 for failure. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

**Note:**


If the connection is secure (see *`TCPConnect <tcpconnect.html>`_
*) then calls to *`TCPSend <tcpsend.html>`_
* will always be blocking, even if the socket is marked as non-blocking.

Example
*******

.. code-block:: omnis
	:linenos:	;  Listen for incoming connections with blocking offCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPBlock (iSocket,1) Returns lStatusTCPListen (iSocket) Returns lStatusIf lStatus=0    Repeat        TCPAccept (iSocket) Returns lConnectedSocket    Until lConnectedSocket&gt;=0    ;  client connectedEnd IfTCPClose (iSocket) Returns lStatus
