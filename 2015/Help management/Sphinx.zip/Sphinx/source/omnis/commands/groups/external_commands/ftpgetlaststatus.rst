﻿FTPGetLastStatus
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPGetLastStatus** (*socket*[,*protocoltext*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPGetLastStatus** returns status information corresponding to thelast FTP command executed on a connected FTP socket.

*Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.

*ProtocolText* is an optional Omnis Character field parameter, into which **FTPGetLastStatus**places the FTP protocol exchange that occurred on the control connection to the FTP server, for the last FTPcommand executed. For example, if you execute *`FTPPwd <ftppwd.html>`_
*, andthen call **FTPGetLastStatus**, *ProtocolText* might contain:

-&gt; PWD

&lt;- 257 &quot;/&quot; is current directory.

Note that &quot;-&gt;&quot; prefixes text sent to the server, and &quot;&lt;-&quot;prefixes text received from the server.
*
Status* is an Omnis Long Integer field which receives the return status of the lastFTP command executed. This information is really redundant, but is provided forcompatibility. The value returned is one of the negative error codes. Possible error codesare listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Example to show how to get the error message from the FTP server when the download fails;  set file transfer mode to asciiFTPType (iFTPSocket,0) Returns lErrCodeIf not(lErrCode)    ;  assumes you are already in the correct folder on the ftp server so only the file name is needed    Calculate lRemoteFile as 'myFileToDownload.txt'    ;  identify where to download the file to    Calculate lLocalFileName as con(sys(115),'downloadFolder',sys(9),lRemoteFile)    ;  download the file    FTPGet (iFTPSocket,lRemoteFile,lLocalFileName) Returns lErrCode    If lErrCode        FTPGetLastStatus (iFTPSocket,iServerReplyText) Returns lErrCode        OK message FTP Error {[con(&quot;Error transferring file &quot;,upp(lRemoteFile),kCr,&quot;Error text from the server: &quot;,kCr,iServerReplyText)]}    End IfEnd If
