﻿On
##
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**On** *event-code* or *codes* (code1,code2,...)
Description
***********
This command is used in an event handling method and marks the beginning of a codesegment that executes when the specified event (or one of a number events) is received bythe current event handling method. An **On** command also marks the end ofany preceding **On** statement. You specify the event or list of events usingthe event constants.

When Omnis generates an event it sends the event information as a series of eventparameters to the appropriate event handling method. The first parameter is always anevent constant. Further parameters, if any, depend on the event and further describe theevent. This event information is interpreted by the **On** statements in theevent handling methods. Window field events are sent to the $event() method behind thefield, then to the $control() method for the window instance, and then to the $control()method for the current task. Events that occur in the window itself, such as a click onthe window background, are sent to the class method called $event(), then to the$control() method for the current task. A particular event is sent to the first **On**command which applies, and when the next **On** command is encountered quitsthe method.

You should place any code which is to be executed for all events before the first **On**command. You cannot nest **On** commands or put them in an `If <../../groups/constructs/if_calculation.html>`_
 or `Else <../../groups/constructs/else.html>`_
 statement. You can use `On default <on_default.html>`_
 to handle any events not handled by an earlier**On** event command. The **On** commands must be in eventhandling methods only: if used elsewhere they are not executed. The function `sys(86) <../../../functions/groups/general/sys.html>`_
 at the start of amethod reports any events received by the object.

See also *`Quit event handler <quit_event_handler.html>`_
*.
Example
*******

.. code-block:: omnis
	:linenos:	;  This example shows typical event handling for a fieldOn evBefore    ;  code to process an evBefore event    On evAfter    ;  code to process an evAfter event    On evClick,evDoubleClick    ;  code to process both evClick and evDoubleClick events
