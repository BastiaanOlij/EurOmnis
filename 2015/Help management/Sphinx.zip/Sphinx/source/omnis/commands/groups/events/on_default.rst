﻿On default
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**On default**
Description
***********
This command is used in an event handling method and handles any events not handled bythe preceding *`On <on.html>`_
* commands. You use the `On <on.html>`_
command to mark the beginning and end of an `On <on.html>`_
 statement. Youshould place any code which is to be executed for all events before the first `On <on.html>`_
 command.
Example
*******

.. code-block:: omnis
	:linenos:	On evClick    ;  process code for evClick event    On default    ;  handle all other events
