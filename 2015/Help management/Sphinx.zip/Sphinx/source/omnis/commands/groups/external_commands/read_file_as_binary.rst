﻿Read file as binary
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Read file as binary** (*refnum*, *binary*-*variable* [,*start*-*position*] [,*num*-*bytes*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command reads a file, or part of a file, into a binary variable. You specify thefile reference number returned by the *Open file* command in *refnum*. Thebinary data read from the file is returned in *binary-variable*.

If you specify the *start-position*, the file is read at that absolute byteposition (0 is the first byte in the file, 1 is the second byte in the file, and so on),otherwise it begins at the current position (0 when the file is first opened). If youspecify the number of *num-bytes*, only that many bytes are read, otherwise the fileis read until the end of the file is reached.

If you specify a *start-position* of 0 and *num-bytes* equal to 0, the filepointer is reset to byte position 0 in the file. If a *start-position* of -1 isgiven, the file pointer is reset to the end of the file. For both cases an empty *binary-variable*buffer is returned.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs. Note the special case for end of file. In this case, the command returns theerror code &#150;39, but may still have read some data.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a file and read it's contents into the binary;  variable lBinfldDo FileOps.$putfilename(lPathname,'Select a file','') Returns lReturnFlagIf lReturnFlag    Open file (lPathname,lRefNum)     Read file as binary (lRefNum,lBinfld) Returns lErrCode    Close file (lRefNum) End If
