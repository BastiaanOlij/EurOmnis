﻿Queue cancel
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue cancel**
Description
***********
This command queues a &quot;cancel&quot; event, as if the user had clicked on theCancel button or pressed the escape key. The command takes no parameters.
Example
*******

.. code-block:: omnis
	:linenos:	;  Setup a timer call to cancel the edit after 120 secondsSet timer method  sec cGeneral/TimerSetupPrepare for editEnter data Update files if flag set;  Code for cGeneral/TimerSetupSend to trace log {No edit has occurred - Timed out}Queue cancel
