﻿Open DDE channel
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |YES |NO |Windows |

Syntax
******
**Open DDE channel** {*program-name* | *topic-name*}
Description
***********
This command opens the current channel for exchanging data. If there is a validresponse, the flag is set and the channel is successfully opened. If the channel isalready open, the existing conversation is closed.

When entering the command in a method, you use the parameters to specify the programand the topic to which the message is to be addressed. Note that the &quot;pipe&quot; (orvertical bar) between the program name and topic name is required.

This command is reversible, that is, a previous conversation will reopen if thiscommand is contained within a reversible block.

When the command is used in a method containing a reversible block, and if a newconversation is initiated using the same channel number as an existing conversation, theoriginal continues to process incoming messages only, and at the end of the method, thenew conversation is stopped and the original becomes fully active.
Example
*******

.. code-block:: omnis
	:linenos:	Set DDE channel number {2}Open DDE channel {Omnis|Country}If flag false    OK message  {The Country library is not running}Else    Do method TransferData    Close DDE channel    OK message  {Update finished}End If
