﻿Define list from SQL class
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |NO |YES |NO |All |

Syntax
******
**Define list from SQL class** *query*, *schema*, or *table-name*(*parameters*)
Description
***********
This command defines the column names and data types for the current list based on thespecified schema, query, or table class.

This results in the creation of a new table instance associated with the list. If the *sql-class-name*refers to a table class, the command passes the *parameters* to the $construct methodof the table class.

When reversed, the contents and definition of the list are restored to their formervalues.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iMyListDefine list from SQL class sMySchema;  or do it this wayDo iMyList.$definefromsqlclass('sMySchema')
