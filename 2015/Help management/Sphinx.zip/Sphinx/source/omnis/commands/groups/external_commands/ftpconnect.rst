﻿FTPConnect
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPConnect** (*serveraddr*,*username*,*password*[,*port*,*errorprotocoltext*,*secure* {Default zero insecure;1 secure;2 use AUTH TLS},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**FTPConnect** establishes a connection to the specified FTP server.

*ServerAddr* is an Omnis Character field containing the hostname or IP address of theFTP server.

*Username* is an Omnis Character field containing the user ID with which the commandwill log on to the server.

*Password* is an Omnis Character field containing the password for the user ID.

*Port* is an optional number or service name, which identifies the TCP/IP port of theFTP server. If you omit this parameter or pass an empty value, it defaults to the standard FTP port (21 for non-secure or AUTH TLS secure connections, or990 for other secure connections). If you use a service name, the lookup for the service will occur locally.

*ErrorProtocolText* is an optional Omnis Character field parameter, into which **FTPGetConnect**places the protocol exchange that occurred on the control connection to the FTP server, if an error occurred.  Note that you can use the command*`FTPGetLastStatus <ftpgetlaststatus.html>`_
* to obtain the protocol exchange in the case when a connection issuccessfully established.

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

**FTPConnect** also supports an alternative *secure* option,  If you pass *secure* with the value 2, theconnection is initially not secure, but after the initial exchange with the server, **FTPConnect** issues an AUTH TLSFTP command to make the connection secure if the server supports it (see RFC 4217 for details), followed by further commandsnecessary to set up the secure connection.  Authentication occurs after a successful AUTH TLS command.

Note that if you use either of the secure options, all data connections are also secure, and all data transfer uses passive FTP.

AUTH TLS is the standard recommended mechanism for FTPS, and is referred to as **explicit** FTPS.  The other secureform of FTP supported by this command is referred to as **implicit** FTPS, and is no longer recommended; however, we providesupport for implicit FTPS to cater for servers which do not support explicit FTPS.

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.

*Socket* is an Omnis Long Integer field, which receives the result of the command. Ifthe command successfully establishes a connection and logs on to the server, *Socket*has a value &gt;= 0; you pass this value to the other FTP commands, to execute requests onthis connection. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	FTPConnect (iServerAddress,iUserName,iPassword) Returns iFTPSocketIf iFTPSocket&lt;0    FTPGetLastStatus (iServerReplyText) Returns lErrCode    OK message FTP Error {[con(&quot;An error occurred logging on to &quot;,iServerAddress,&quot; - Details follow&quot;,kCr,iServerReplyText)]}End If
