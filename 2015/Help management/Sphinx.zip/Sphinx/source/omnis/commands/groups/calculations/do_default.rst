﻿Do default
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |YES |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Do default** **Returns** *return-value*
Description
***********
This command is used within the code for a custom property, and performs the defaultbehavior for the built-in property with the same name as a custom property. **Dodefault** sets the flag if some built-in processing for the property exists.

Note that where the return field is an item reference, the command sets the referencebut does not assign to it: you must do this with *`Calculate <calculate.html>`_
*or *Do Itemref.$assign(value).*
Example
*******

.. code-block:: omnis
	:linenos:	;  Adding a method called $horzscroll.$assign to a window causes this method to be executed whenever;  Do $horzscroll.$assign is called.  If the window is over 20 pixels wide when the method is called the default;  behavior for $horzscroll.$assign is performed, that is a scroll bar is added.;  declare parameter pScrollBarOn of type BooleanIf pScrollBarOn&amp;$cinst.$width&lt;20    ;  window too narrow for a scroll bar    Quit method Else    ;  assign a horz scroll bar    Do default End If
