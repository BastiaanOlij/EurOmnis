﻿Delete data
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Delete data** {*file-name*}
Description
***********
This command deletes all the data and indexes for a specified file in a data file. Thedata and indexes for a file class are called a &quot;slot&quot;. You can delete a slotonly if and when one user is logged onto the data file.

If a specified file name does not include a data file name as part of the notation, thedefault data file for that file is assumed. If the file is closed or memory-only, thecommand does not execute and returns flag false. If you are not running in single usermode, the command automatically tests that only one user is using the data file (thecommand fails with the flag false if this is not true), and further users are preventedfrom logging onto the data until the command completes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute, andit is not possible to cancel execution even if a working message with cancel box is open.The command sets the flag if it completes successfully and clears the flag otherwise. Itis not reversible.
Example
*******

.. code-block:: omnis
	:linenos:	Delete data {fCustomers}If flag true    OK message  {Data for fCustomers has been deleted}Else    OK message Error {Data could not be deleted}End If
