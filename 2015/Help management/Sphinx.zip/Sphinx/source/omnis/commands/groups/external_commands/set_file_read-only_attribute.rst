﻿Set file read-only attribute
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Set file read-only attribute** (*path*, *read*-*flag*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command lets you set the read-only attribute of the file specified in *path-name*.If you set the *read-flag* parameter to `kTrue <../../../notation/root/constants/boolean_values.html>`_
 the file is set to read-only, or ifkFalse the file is set to read/write.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  set the read-only attribute of lPathname to kTrueCalculate lPathname as 'c:\desktop\myfolder\mylibrary.lbs'Set file read-only attribute (lPathname,kTrue) 
