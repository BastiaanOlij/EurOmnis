﻿Load external routine
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Externals <../externals.html>`_  |YES |YES |NO |All |

Syntax
******
**Load external routine** *routine-name* or *library-name*/*routine-name* (*parameters*)
Description
***********
This command loads the specified external code into memory. You can enter the routinename as the parameter. If the library/resource is not in the EXTERNAL folder, the name ofthe file containing the library/resource and the library/resource name within that fileare given as parameters.

If the library/resource is already loaded or is not found, the flag is cleared and noaction is taken. If this command is included in a reversible block, the library/resourceis unloaded when the method terminates. If the library/resource is loaded in, it is calledwith the mode set at ext_load.

You can pass parameters to the external code by enclosing a comma-separated list offields and calculations. If you pass a field name, for example, *`Call external routine <call_external_routine.html>`_
 Maths1 (LVAR1,LVAR2), *theexternal can directly alter the field value. Enclosing the field in brackets, for example,*`Call external routine <call_external_routine.html>`_
 Maths1 ((LVAR1),(LVAR2)),*converts the field to a value and protects the field from alteration.

In the routine itself, the parameters are read using the usual GetFldVal or GetFldNvalwith the predefined references Ref_parm1, Ref_parm2, and so on, Ref_parmcnt gives thenumber of parameters passed. If the field name is passed as a parameter, you can useSetFldVal or SetFldNval with Ref_parm1, and so on, to change the field's value.
Example
*******

.. code-block:: omnis
	:linenos:	Load external routine MathsLib/sqroot (iNumber,iNumber2)
