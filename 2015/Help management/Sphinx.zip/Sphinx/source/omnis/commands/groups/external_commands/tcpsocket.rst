﻿TCPSocket
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPSocket** () **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPSocket** creates a new socket. The only use of such a socket isto bind a port to it using *`TCPBind <tcpbind.html>`_
*, start listening onthe port using *`TCPListen <tcplisten.html>`_
*, and then accept incomingconnections using *`TCPAccept <tcpaccept.html>`_
*.
*
Socket *is an Omnis Long Integer field which receives the number of the allocatedsocket. If an error occurs, the command returns a negative number. 
Example
*******

.. code-block:: omnis
	:linenos:	;  Create a new socket, bind it to port 6000 and listen for a incoming;  client connectionCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPListen (iSocket) Returns lStatusIf lStatus=0    Repeat        TCPAccept (iSocket) Returns lConnectedSocket    Until lConnectedSocket&gt;=0    ;  client connectedEnd IfTCPClose (iSocket) Returns lStatus
