﻿Break to end of loop
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Break to end of loop**
Description
***********
This command terminates a *`Repeat <repeat.html>`_
,* *`While <while_calculation.html>`_
* or **For loop**, passing control to thecommand following the* `Until <until_calculation.html>`_
, `End While <end_while.html>`_
 *or *`End For <end_for.html>`_
*command. An *`If <if_calculation.html>`_
 *command is usually placed beforethe **Break to end of loop** to determine the condition under which a breakoccurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  loop until user replies yes to yes/no message or lCount=100While lCount&lt;-100    Yes/No message  {Break to end of loop ?}    If flag true        Break to end of loop    End If    Calculate lCount as lCount+1End While
