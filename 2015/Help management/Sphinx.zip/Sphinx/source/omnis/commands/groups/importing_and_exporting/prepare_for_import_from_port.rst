﻿Prepare for import from port
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Prepare for import from port** {*export-format*}

Export Formats
**************|Delimited (commas) | |
|Delimited (tabs) | |
|One field per line | |
|Omnis data transfer | |
|Delimited (user delimiter) | |

Description
***********
This command prepares Omnis for importing data from a port. It is similar to the `Prepare for import from file 
`_
 command.The user can cancel the import of data while **Prepare for import from port**is waiting for data from the port. If this happens, Omnis clears the flag.
*
`Set port name <../../groups/report_destinations/set_port_name.html>`_
 *defineswhich port is used. Under MacOSX, the choice is 1 (Modem port) or 2 (Printer port). UnderLinux and Windows, the choices are Com1:, Com2:, and so on.
Example
*******

.. code-block:: omnis
	:linenos:	Set port name {COM1:}Prepare for import from port {One field per line}Repeat    Import field from file into lImportFieldUntil lImportField='start data'Do method ImportDataClose import file
