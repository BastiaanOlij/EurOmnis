﻿Get files
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Get files** (*list*-*name*, *first*-*column*, *path*, *file*-*type* [,*creator*-*type*] [,*8.3*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command returns a list of files in a directory or folder.

To list only files of a specified type, specify the *file-type*,which is a wildcard, such as &#145;*.LBS&#146;.

If you omit the *file-type*, the command returns the names of all the files.

You specify the list with *list-name*. The list must have a column defined as *list-column-name*,where *list-column-name *is the name of a variable. This column will receive thenames of the files found under the specified *path-name*, including the extension.

On Windows, you can also supply the *8.3* parameter. This defaults to `kFalse <../../../notation/root/constants/boolean_values.html>`_
. Ifyou pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
, then **Get files** returns the 8.3 name equivalent to anylong file names.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.

The following example uses **Get files*** *to build a list of all thelibraries in the folder returned by `sys <../../../functions/groups/general/sys.html>`_
(10).
Example
*******

.. code-block:: omnis
	:linenos:	Do lFileList.$define(lFileName);  get the path of the examples folder in the studio treeCalculate lPathname as con(sys(115),'welcome',sys(9),'examples');  return the list of all example librariesGet files (lFileList,lFileName,lPathname,'*.lbs') Returns lErrCode
