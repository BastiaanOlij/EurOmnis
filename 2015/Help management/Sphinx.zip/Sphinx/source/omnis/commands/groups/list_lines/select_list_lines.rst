﻿Select list line(s)
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Select list line(s)** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command selects the specified list line. The specified line of the current list isselected and is shown highlighted (or checked on popup lists) on any window list fieldsprovided that the field has $multipleselect on. If the line number is not specified, thecurrent list line is selected. The **All lines** option selects all lines of thecurrent list. The current line is not affected. When a list is saved in the data file, theline selection is stored. The following example selects the middle line of the list:
Example
*******

.. code-block:: omnis
	:linenos:	;  Select line 3 of the listSet current list lMyListDefine list {lCol1}For lCol1 from 1 to 6 step 1    Add line to list {lCol1}End ForSelect list line(s) {lMyList.$linecount/2};  Alternatively, you can select a line by assigning its $selected property.Do lMyList.1.$selected.$assign(kTrue)
