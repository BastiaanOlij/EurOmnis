﻿Flush data now
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |NO |NO |NO |All |

Syntax
******
**Flush data now**
Description
***********
This command causes any modified data which has not been written to disk to beimmediately written to disk. This command will only do something if a *`Do not flush data <do_not_flush_data.html>`_
* command has been executed.

This command leaves the flag unaffected and is not reversible.
Example
*******

.. code-block:: omnis
	:linenos:	;  fast importTest for only one userIf flag true    Do not flush data    Drop indexesEnd IfPrompt for import filePrepare for import from file {Delimited(tabs)}Import data lImportListEnd importClose import fileFor each line in list from 1 to lImportList.$linecount step 1    Prepare for insert     ;; transfer list to file    Load from list    Update filesEnd ForFlush data now     ;; writes the data immediately to diskBuild indexes     ;; rebuild indexesFlush data     ;; Changes mode back to 'Flush data'
