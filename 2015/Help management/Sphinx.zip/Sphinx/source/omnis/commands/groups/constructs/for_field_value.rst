﻿For field value
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**For ***field-name******* from ***start*** to ***stop*** step ***step*****
Description
***********
This command marks the beginning of a For loop which defines a series of commands to berepeated a number of times. You use *field-name* as a counter that is automaticallyincremented by the *step *value each time the *`End For <end_for.html>`_
*statement is reached.

The values involved must all be numbers, preferably integers. If *start *value isgreater than *end *value, and *step *value is positive, the command will performno loops. Similarly, no loops are performed if *start *value is less than *end *value,and *step *value is negative.

The * end* value is evaluated once at the start of the loop, and saved, for performancereasons, so changing the end value during the loop will have no effect. You can use *`Jump to start of loop <jump_to_start_of_loop.html>`_
* withinthe loop to continue the next iteration of the loop. Similarly, you can terminate the loop early using*`Break to end of loop <break_to_end_of_loop.html>`_
 *if desired.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lString as ''For lCount from 0 to 9 step 1    Calculate lString as con(lString,lCount)End ForOK message  {String=[lString]}     ;; shows 'String=0123456789'Calculate lString as ''For lCount from 9 to 0 step -1    Calculate lString as con(lString,lCount)End ForOK message  {String=[lString]}     ;; shows 'String=9876543210'
