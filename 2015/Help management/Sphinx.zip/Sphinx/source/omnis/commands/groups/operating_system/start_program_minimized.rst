﻿Start program minimized
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Start program minimized** {*program-name*}
Description
***********
This command starts up an application as a minimized icon. The program name must be thepathname of the executable file. You can also specify the full pathname of a file, andother parameters, separated by a space from the program name. You can use this command onWindows and Linux, although on Linux the command does not minimize the application. The flagis set if the program is found.
Example
*******

.. code-block:: omnis
	:linenos:	;  If the program lPath exists start it minimizedCalculate lPath as 'c:\program files\windows nt\accessories\wordpad.exe'Test if file exists {[lPath]}If flag true    Start program minimized {[lPath]}End If
