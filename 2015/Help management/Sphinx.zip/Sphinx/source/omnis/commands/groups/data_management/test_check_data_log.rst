﻿Test check data log
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Test check data log** ([*Perform repairs*])

Options
*******|Perform repairs |If selected,repairs to the data file are automatically carried out |

Description
***********
This command tests if there are any reports of nonrepaired damage in the check datalog. If the **Perform repairs** option is not specified, the flag is set if there areany reports of nonrepaired damage.

If the **Perform repairs** option is specified, an attempt is made to repair thedamage. There is no need for the check data log to be open. Furthermore, Omnisautomatically tests that only one user is logged onto the data file (if not, the commandfails with flag false), and further users are prevented from logging onto the data untilthe command completes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute, andit is not possible to cancel execution even if a working message with cancel box is open.

The command sets the flag if it completes the data repair successfully and clears theflag otherwise. The command is not reversible.
Example
*******

.. code-block:: omnis
	:linenos:	Quick checkTest check data logIf flag true    OK message  {Problems found in data file}    Open check data logEnd If
