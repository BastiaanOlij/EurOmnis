﻿Send command
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |NO |NO |Windows |

Syntax
******
**Send command** {*text*}
Description
***********
DDE command, Omnis as client. This command sends a command or a series of commands astext to the current channel.

The command-text syntax must conform to whatever syntax rules apply to the serverprogram.

The DDE syntax dictates that the commands be enclosed in square brackets and Omnisattaches special meaning to them in strings. Therefore, it may be necessary to put thecommand text into one of the Omnis string variables. 

The flag is set if the server accepts the command(s).
**Syntax and errors
=================**
When you send commands to Omnis, the syntax is defined by the text shown in the methodeditor. You can enter scripts in Omnis, copy them to the clipboard and paste them into theclient application. If the sent command returns an error to Omnis, the hash variables **`#ERRCODE <../../../notation/root/hashvars/errors.html>`_
** and **`#ERRTEXT <../../../notation/root/hashvars/errors.html>`_
** store the error codeand message.
Example
*******

.. code-block:: omnis
	:linenos:	;  put your command text into the character variable lStringCalculate lString as '[your command]'Send command {[lString]}     ;; send the command to the server;  else you can enter the command directly into the command parameter by doubling the;  first set of brackets; egSend command {[[releasecontrol]};  ExampleSet DDE channel number {2}Open DDE channel {Omnis|Country}If flag false    OK message  {The Country library is not running}Else    Calculate lString as &quot;Ok Message {Hi, this is DDE magic'}&quot;    Send command {[lString]}    Send command {'Next'}    Close DDE channel    OK message  {Update finished}End If
