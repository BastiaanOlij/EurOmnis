﻿Wait for semaphores
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |NO |YES |NO |All |

Syntax
******
**Wait for semaphores**
Description
***********
This command causes all the commands which set semaphores to wait with a lock cursoruntil the semaphores for the required records are available.

When a library is first selected, **Wait for semaphores** is automaticallyselected to ensure compatibility with existing libraries. It causes all the commands whichset semaphores to wait with a lock cursor until the semaphore is available then returnwith the flag set, or to wait until the user cancels with a Ctrl-Break/Ctrl-C/Cmnd-periodthen return with a flag clear.

**Semaphores**

Semaphores are internal flags or indicators set in the data file to show other usersthat the record has been required elsewhere for editing. Semaphores are set only whenrunning in multi-user mode, that is, the data file is located on a networked server, a Macvolume or on a DOS machine on which SHARE has been run.

The commands which set semaphores are *`Prepare foredit 
`_
*, *`Prepare for insert 
`_
*, *`Update files <update_files.html>`_
* and *`Delete <delete.html>`_
*,and also, if pfu mode is on, *`Single file find <../../../commands/groups/finding_data/single_file_find.html>`_
*,*`Loadconnected records <../../../commands/groups/finding_data/load_connected_records.html>`_
*, *`Next <../../../commands/groups/finding_data/next.html>`_
,`Previous <../../../commands/groups/finding_data/previous.html>`_
* and *`Set read/write files <../../../commands/groups/files/set_read_write_files.html>`_
*.Auto finds on windows always wait for semaphores.

The Edit/Insert commands from the Commands menu always wait for a semaphore as doautomatic find entry fields.
Example
*******

.. code-block:: omnis
	:linenos:	Wait for semaphoresPrepare for edit     ;; waits for record if locked by another userEnter data Do not wait for semaphoresIf flag true    Update files    If flag false        OK message  {File was locked, update failed}    End IfEnd If
