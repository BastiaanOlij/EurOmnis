﻿Close working message
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |NO |NO |NO |All |

Syntax
******
**Close working message**
Description
***********
This command closes the current working message. No error occurs if there is no workingmessage displayed. Working messages close themselves when methods stop running and controlreturns to the user.  Once a working message is displayed, a call to another methodleaves the message on the window. The message is not cleared automatically until the firstmethod ends.
Example
*******

.. code-block:: omnis
	:linenos:	;  Close the working message before this method;  has finishedWorking message  {Processing Record [lCount]}For lCount from 1 to 20000 step 1    Redraw working messageEnd ForClose working messageFor lCount from 1 to 50000 step 1    Calculate lValue as lValue+lCountEnd For
