﻿FTPGet
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPGet** (*socket*,*remotefile*,*localfile*[,*filetype*,*creator*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPGet** downloads a file from an FTP server. The file istransferred using the currently specified transfer type of ASCII or binary, as specifiedby the *`FTPType <ftptype.html>`_
* command. It is important that you set thetransfer type correctly for each file you download, since an incorrect transfer type willresult in a bad downloaded copy of the file.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
RemoteFile* is an Omnis Character field containing the pathname of the remote fileto download.
**
Note: **The remote filename may not be acceptable to the local system.
*
LocalFile* is an Omnis Character field containing the pathname of the downloadedfile. If the file already exists, **FTPGet** will overwrite it with thedownloaded file.
*
FileType* and *Creator* are optional arguments, which the command uses on theMacintosh platforms only. These specify a file type and creator for the downloaded copy ofthe file. If you omit these arguments when calling **FTPGet** on a Macintosh,they default as follows: <ul>  <li>For ASCII transfer type: *FileType* = TEXT, *Creator* = ttxt</li>  <li>For binary transfer type: *FileType* = TEXT, *Creator* = mdos</li></ul>*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  set file transfer mode to asciiFTPType (iFTPSocket,0) Returns lErrCodeIf not(lErrCode)    ;  assumes you are already in the correct folder on the ftp server so only the file name is needed    Calculate lRemoteFile as 'myFileToDownload.txt'    ;  identify where to download the file to    Calculate lLocalFileName as con(sys(115),'downloadFolder',sys(9),lRemoteFile)    ;  download the file    FTPGet (iFTPSocket,lRemoteFile,lLocalFileName) Returns lErrCode    If lErrCode        OK message FTP Error {[con(&quot;Error transferring file &quot;,upp(lRemoteFile),&quot; to &quot;,upp(lLocalFileName),kCr,&quot;Error code : &quot;,lErrCode)]}    End IfEnd If
