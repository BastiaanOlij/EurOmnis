﻿Set timer method
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |YES |NO |All |

Syntax
******
**Set timer method ***interval* (seconds)** sec** [*name*/]*name*
Description
***********
This command calls the specified method at regular intervals while waiting for akeyboard input; the called method should preferably be one contained in a code class. Youcould use this command for automatic telephone dialing, regular checks for electronicmail, and so on.

The command specifies the timer method and the interval in seconds between calls to thetimer method. This interval can be between 1 and 30,000 in the form &quot;n sec&quot;where n is the number of seconds. Omnis will start the next timer method when the methodwhich is currently executing, finishes. Timer methods cannot operate in real time as Omniswill not execute a timer method while another method is running or when an `OK <../../../commands/groups/message_boxes/ok_message.html>`_
 or `Yes/No message <../../../commands/groups/message_boxes/yes_no_message.html>`_
 isdisplayed on the screen.

The timer method in your code class should not contain a *`Quit all methods <quit_all_methods.html>`_
* as this will terminate any *`Enter data <../a-e/enter_data.html>`_
* commands which are running. You can alsouse an *Enter data* inside a timer method: if so and you do not clear the timermethod, the timer method continues to be active while Omnis carries out the Enter datapart of the timer method.

You can use **Set timer method** in a reversible block, in which case thetimer method is cleared when the executing method terminates.

Note that the timer method does not run in the context of a task instance, meaning thatyou cannot access task variables from the method. If you want your timer code to run inthe context of a task instance, then create an object class which has a superclass of theTimer external object.
Example
*******

.. code-block:: omnis
	:linenos:	;  Call the method Timer every 5 secondsSet timer method 5 sec Timer;  method TimerOK message  {Timer method triggered}
