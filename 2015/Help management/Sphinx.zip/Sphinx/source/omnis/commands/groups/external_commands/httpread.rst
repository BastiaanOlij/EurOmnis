﻿HTTPRead
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPRead** (*socket*,*buffer*[,*type* {Default zero for server; Non-zero for client}]) **Returns** *received-byte-count*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**HTTPRead** is a client and server command that reads a complete HTTPrequest message or response. Servers use it to read requests, and clients use it to readresponses.

*Socket* is a long integer field containing the socket number of an open HTTPconnection.

*Buffer* is a character or binary field into which **HTTPRead**places the received request or response.  If the field is character, then the response must be encoded in UTF-8; in this case, **HTTPRead** converts the received data from UTF-8 to character.

*Type* is an optional parameter. It is a Boolean value, where zero indicates serverbehavior, and non-zero indicates client behavior. If omitted, it defaults to zero.

*Received-byte-count* is a long Integer field which receives the number ofbytes placed in *Buffer*. If an error occurs, an error code less than zero isreturned here. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

Note: **HTTPRead** always operates in blocking mode, and will timeoutafter the connection is inactive for the comms timeout value (which can be changed from itsdefault of 1 minute using the command `WebDevSetConfig <webdevsetconfig.html>`_
). The server reads until the HTTP requestheader is complete, and it has received content of the correct size. The client behavessimilarly, but will also treat graceful closure of the connection as marking the end ofthe response.
Example
*******

.. code-block:: omnis
	:linenos:	;  When a new connection is received call the method $newconnection;  to read the messageHTTPServer ('$newconnection',6001) Returns lStatus;  method $newconnectionHTTPRead (iSocket,lBuffer) Returns lByteCount
