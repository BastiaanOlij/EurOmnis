﻿Omnis environment
#################
`Command Index <../command_index.html>`_


`Commands
******** <omnis_environment#commands>`_
|`Set 'About...' method <omnis_environment/set_'about...'_method.html>`_  |`Set Omnis window title <omnis_environment/set_omnis_window_title.html>`_  |`Show 'About...' window <omnis_environment/show_'about...'_window.html>`_  |`Show Omnis maximized <omnis_environment/show_omnis_maximized.html>`_  |
|`Show Omnis minimized <omnis_environment/show_omnis_minimized.html>`_  |`Show Omnis normal <omnis_environment/show_omnis_normal.html>`_  |`Test if running in background <omnis_environment/test_if_running_in_background.html>`_  |

