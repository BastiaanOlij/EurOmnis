﻿Do redirect
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |YES |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Do redirect ***notation-for-object*** Returns ***return-value*****
Description
***********
This command redirects execution from a custom property to any other public method. Youspecify the notation (or a calculation which evaluates to a reference to an object) forthe recipient. The recipient of the custom property being processed is $crecipient. Theflag is set if the recipient exists and handles the property with a built-in or customproperty.
Example
*******

.. code-block:: omnis
	:linenos:	Do $cwind.$setup     ;; the call to $setup in current window instance ..;  $setup method of the window instanceDo redirect $cwind.$objs.EntryField     ;; .. is diverted ..;  $setup method of EntryField     ;; .. to hereOK message  {redirected to [$crecipient().$name]}
