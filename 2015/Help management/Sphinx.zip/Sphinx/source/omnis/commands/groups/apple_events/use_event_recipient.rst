﻿Use event recipient
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |NO |NO |MacOSX |

Syntax
******
**Use event recipient** {*recipient-tag*}
Description
***********
This command sets the event recipient by specifying the recipient tag. The named eventrecipient must be currently available on the network; that is, its name must be on theApple Application menu.

When Omnis is launched, the recipient defaults to Omnis, that is, events are sent toitself. Similarly if you use this command without a parameter, the recipient reverts toOmnis.

The following example shows the difference between **Use event recipient**,which is used with a tag previously assigned by the user with *`Prompt for event recipient 
`_
*, and *`Set event recipient <set_event_recipient.html>`_
*, which takes a localapplication name as a parameter, and turns it into a recipient tag.
Example
*******

.. code-block:: omnis
	:linenos:	;  prompt user and select applicationPrompt for event recipient {MyAppl};  do something with MyAppl;  This is the name of the current application, as shown on the Apple Application menuSet event recipient {Microsoft Excel};  do something in 'Excel';  go back to the tagged recipient, previously prompted forUse event recipient {MyAppl};  do something else;  Finally go back to Omnis by resetting recipient with no promptUse event recipient
