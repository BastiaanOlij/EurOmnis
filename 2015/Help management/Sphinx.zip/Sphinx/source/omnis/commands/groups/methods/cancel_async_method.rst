﻿Cancel async method
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |YES |NO |NO |All |

Syntax
******
**Cancel async method** {*id-to-cancel* (*return-value-from-do-async-method*)}
Description
***********
This command allows you to cancel the execution of a method that is executing as a result of a call to the*`Do async method <../../../commands/groups/methods/do_async_method.html>`_
* command.
This command takes a single parameter *id-to-cancel*, which is the **asynchronous call id** returned by *`Do async method <../../../commands/groups/methods/do_async_method.html>`_
*.

This command sets the flag if it has marked the async method for cancellation. Omnis only checks to see if the methodis marked for cancellation after the completion of each method command, so cancellation may not occur immediately.  Also,if you are executing a sensitive block of code, which should not be cancelled in this way, you can use the*`Begin critical block <../../../commands/groups/threads/begin_critical_block.html>`_
* and *`End critical block <../../../commands/groups/threads/end_critical_block.html>`_
* commands around the sensitive code.  Omnis will only cancel the method execution when the thread ends the critical block.  If the flag is cleared, then either the**asynchronous call id** is invalid, or the method has finished.  After successfully cancelling a method call, Omnisstill sends the $asynccomplete message, but with an error text parameter that indicates that the call was cancelled.
**
Note
**
You can only call **Cancel async method** when running in the normal foreground thread.
Example
*******

.. code-block:: omnis
	:linenos:	;  iCallId was returned by Do async methodCancel async method {iCallId}
