﻿Send field
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |NO |NO |Windows |

Syntax
******
**Send field** *field-name* {*server-data-item-name*}
Description
***********
DDE command, Omnis as client. This command sends the value of an Omnis field to thecurrent DDE channel. An error occurs if the channel is not open. The command takes theOmnis field name and the server data item name as parameters. The data item name cancontain square bracket notation. If the data item name is not specified, the Omnis fieldname is used.

The flag is set if the server program accepts the value.
Example
*******

.. code-block:: omnis
	:linenos:	Set DDE channel number {2}Open DDE channel {Omnis|DDE2}Calculate lString as '[TakeControl]'Send command {[lString]}If flag false    OK message  {Error sending: [lString]}End IfSend field iClient {sName}Send field iTotal {sTotals}
