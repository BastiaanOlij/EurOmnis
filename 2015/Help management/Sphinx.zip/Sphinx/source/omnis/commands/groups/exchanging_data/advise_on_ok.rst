﻿Advise on OK
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Advise on OK** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command determines when Omnis is permitted to sendrequested Advise messages to the client program. When Advise** **requests have beenreceived from a client, the `Setserver mode <../../groups/exchanging_data/set_server_mode.html>`_
 command determines when Omnis is permitted to send field values thathave changed. In addition to the `Set server mode <../../groups/exchanging_data/set_server_mode.html>`_
options, the three commands *`Advise onFind/next/previous <advise_on_find_next_previous.html>`_
, ***Advise on OK***,* and *`Advise on Redraw <advise_on_redraw.html>`_
* let you toggle individual options onor off. The **Advise on OK** command lets you control this particular optionwithout affecting the other two.
Example
*******

.. code-block:: omnis
	:linenos:	Advise on OK (Accept)     ;; enable advise on OKAdvise on OK     ;; disable advise on OK
