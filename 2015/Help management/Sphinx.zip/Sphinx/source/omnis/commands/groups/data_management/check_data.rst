﻿Check data
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Check data** ([*Perform repairs*][,*Check data file structure*][,*Check records*][,*Check indexes*]) {*list-of-files* (F1,F2,..,Fn) (leave empty to select all)}

Options
*******|Perform repairs |If selected,repairs to the data file are automatically carried out |
|Check data file structure |If specified,the command checks the overall structure of the data file |
|Check records |If specified,the command checks the records in the specified files |
|Check indexes |If specified,the command checks the indexes in the specified files |

Description
***********
This command checks the data for the specified file or list of files, and works onlywhen one user is logged onto the data file. If you omit a file name or list of files, *all*the files with slots in the current data file are checked. If the specified file name doesnot include a data file name as part of the notation, the default data file for that fileis assumed. If the file is closed or memory-only, the command does not execute and returnswith the flag false.

There are **Check data file structure**, **Check records**, and **Checkindexes** checkbox options. If none of these is specified, the command does nothing; ifonly **Check data file structure** is specified, the list of files is ignored. If **Performrepairs** is specified, any repairs required are automatically carried out, otherwisethe results of the check are added to the check data log. The check data log is not openedby this command but is updated if already open.

If you are not running in single user mode, this command automatically checks that onlyone user is using the data file (the command fails with flag false if this is not true),and further users are prevented from logging onto the data until the command completes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute andit is not possible to cancel execution even if a working message with cancel box is open.

The command sets the flag if it completes successfully and clears the flag otherwise.It is not reversible.
Example
*******

.. code-block:: omnis
	:linenos:	Check data (Check records) {fOrders}If flag true    Yes/No message  {View Log?}    If flag true        Open check data log    End IfElse    OK message Error (Icon) {The check data file command could not be carried out//Please make sure that only one user is logged on to the datafile}End If
