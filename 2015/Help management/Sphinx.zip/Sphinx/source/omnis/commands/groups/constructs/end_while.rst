﻿End While
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**End While**
Description
***********
This command marks the end of a *`While <while_calculation.html>`_
* loop.When the condition specified at the start of the loop is not fulfilled (testing the flagor calculation) the command after the **End While** command is executed. Eachloop that begins with a *`While <while_calculation.html>`_
* command mustterminate with an **End While** command, otherwise an error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lCount as 1While lCount&lt;=3     ;; While loop    Calculate lCount as lCount+1End WhileOK message  {Count=[lCount]}     ;; prints ‚ÄòCount=4‚ÄôCalculate lCount as 1Repeat     ;; Repeat loop    Calculate lCount as lCount+1Until lCount&gt;=3OK message  {Count=[lCount]}     ;; prints ‚ÄòCount=3‚Äô
