﻿Test clipboard
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Clipboard <../clipboard.html>`_  |YES |NO |NO |All |

Syntax
******
**Test clipboard** *field-name*
Description
***********
This command tests whether the data on the clipboard is suitable for pasting into thespecified field or current selection. The command sets the flag to true if and only ifthere is data on the clipboard &quot;suitable&quot; for pasting into the specified orcurrent field. &quot;Suitability&quot; here is defined by the standard type conversionbuilt into Omnis, that is, a text field has to be presented with some text, and a picturefield with something that can be handled as a picture, for example, a bitmap, metafile,PICT, OLE object, and so on.
Example
*******

.. code-block:: omnis
	:linenos:	Test clipboard iPictureIf flag true    Paste from clipboard iPicture (Redraw field)End If
