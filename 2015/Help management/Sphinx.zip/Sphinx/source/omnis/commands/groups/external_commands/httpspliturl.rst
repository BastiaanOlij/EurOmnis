﻿HTTPSplitURL
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPSplitURL** (*url*,*hostname*,*uri*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPSplitURL** is a server and client function which splits a fullURL into a hostname and a path (that is, a URI). Useful for following HREF links on pages.
*
URL* is an Omnis Character field containing a standard Web page URL of the formhttp://host.mydomain.com/path/webpage.html
*
Hostname* is an Omnis character field that receives the hostname parsed out of theURL argument. For example, given the URL, above, the hostname portion would behost.mydomain.com
*
URI* is an Omnis Character field that receives URI parsed out of the URL. Forexample, given the URL, above, the URI would be /path/webpage.html.

The command returns an integer *status*, which is less than zero if an erroroccurs. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Split lUrl into lHostname and lUriCalculate lUrl as 'http://www.omnis.net/news/index.html'HTTPSplitURL (lUrl,lHostName,lUri) Returns lStatus
