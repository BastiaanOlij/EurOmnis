﻿HTTPParse
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPParse** (*message*,*headerlist*,*method*,*httpver*[,*uri*,*cgilist*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPParse** is a server command to parse HTTP header informationfrom an incoming request message.
*
Message* is an Omnis Character or Binary field containing the full text of an HTTPrequest message.
*
HeaderList* is an Omnis list with two character columns. The list receives theheaders extracted from the request message, one line per header.

For example, after the call, the list might contain entries such as:
|**Attribute** |**Value** |
|Date |The current GMT date and time in HTTP header |
|User-Agent |NCSA Mosaic for the X Window System/2.4 libwww/2.12 modified |
|Accept |/ |
|Content-type |Application/x-www-form-urlencoded |
|Content-length |1234 |
**
Note:** **HTTPParse** automatically strips the colons after theattribute names.
*
Method* is an Omnis character field that receives the type of HTTP method beingrequested, for example, GET, POST, or HEAD.
*
HTTPVersion* is an Omnis Character field containing the version of HTTP. Forexample, 1.0.
*
URI* is an Omnis Character field that receives the name of the URI to be processed.At a minimum, the URI is a single slash, so every URI returned from **HTTPParse**is of the form /URLName.
**
Note:** Due to the presence of the leading slash, a simple Omnis equality stringcomparison to the name of the URI fails. Use the `pos <../../../functions/groups/string/pos.html>`_
() function or similar parsingmechanism to find the URI name. The trailing question mark of a GET-method CGI, whichseparates the URI path from the CGI arguments, is stripped by **HTTPParse**.
*
CGIList* is an Omnis list field with two character columns. It receives the CGIarguments present in the request, either extracted from the URL, or extracted from contentof type &quot;application/x-www-form-urlencoded&quot;. For example, if the following HTMLform is the submitted from a browser:



.. code-block:: omnis
	:linenos:	Name:City:Are you alive?


and the user types in *John Smith, Podunk* and checks the City field, after **HTTPParse**,*CGIList *contains:
|**Attribute** |**Value** |
|Name |John Smith |
|City |Podunk |
|Alive |Yes |
|Submit |Please |
**
Note: **Before the data is stored in the list, **HTTPParse**automatically decodes any CGI encoding required to pass special characters. There is noneed to call the CGIDecode command.

Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  When a new connection is received call the method $newconnection;  to read and parse the message sent by HTTPPostHTTPServer ('$newconnection',6001) Returns lStatus;  method $newconnectionHTTPRead (iSocket,lBuffer) Returns lCharCountDo lHeaderList.$define(lHeaderName,lHeaderValue)Do lCGIList.$define(lAttribute,lValue)HTTPParse (lBuffer,lHeaderList,lMethod,lHttpVersion,lUri,lCGIList) Returns lStatus
