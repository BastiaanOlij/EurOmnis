﻿Quit all methods
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |NO |All |

Syntax
******
**Quit all methods**
Description
***********
This command quits all methods that are running.  If the command is executedduring a method which has been called, Omnis quits both the current method and the callingmethod.
Example
*******

.. code-block:: omnis
	:linenos:	;  Quit all methods so that OK message never gets shown;  calling methodDo method QuitMethodOK message  {This never never gets shown};  method QuitmethodQuit all methods
