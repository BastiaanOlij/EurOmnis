﻿SEA continue execution
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Error handlers <../error_handlers.html>`_  |NO |NO |NO |All |

Syntax
******
**SEA continue execution**
Description
***********
This command continues method execution at the command following the command whichcalled an error handler; SEA stands for Set Error Action. Using it is, in effect, likesaying &quot;Error is acknowledged. Now, skip over the error line and proceed with thesucceeding good lines.&quot;

Using this command is similar to setting the go point in the debugger at L+1 where L isthe error line. The command is always used within an error handler.
Example
*******

.. code-block:: omnis
	:linenos:	;  error handler to trap break key while waiting for semaphoreIf #ERRCODE=kerrCantlock    OK message  {User cancelled request for record lock}    SEA continue executionEnd If;  NB: The edit method must test the flag to prevent an error on update
