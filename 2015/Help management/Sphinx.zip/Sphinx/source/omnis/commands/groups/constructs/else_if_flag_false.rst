﻿Else If flag false
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Else If flag false**
Description
***********
This command is used after an *`If <../f-j/if_calculation.html>`_
*statement and provides a marker before a series of commands that have to be carried out ifthe flag is false.
Example
*******

.. code-block:: omnis
	:linenos:	;  In the example below, the value of lGender is tested against the condition;  false if cancel if pressed.Prompt for input Please enter your name Returns lName (Cancel button)If flag true    OK message  {Your name is [lName]}Else If flag false     ;; cancel button pressed    OK message  {No name entered}End If
