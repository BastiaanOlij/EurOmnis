﻿Show Omnis minimized
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Show Omnis minimized**
Description
***********
This command minimizes Omnis which subsequently appears as an icon at the bottom of thescreen.
Example
*******

.. code-block:: omnis
	:linenos:	;  Minimize Omnis while processingShow Omnis minimizedFor lCount from 1 to 100000 step 1    ;  delayEnd ForShow Omnis maximized
