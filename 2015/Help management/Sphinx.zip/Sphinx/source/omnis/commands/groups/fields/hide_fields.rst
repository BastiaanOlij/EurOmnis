﻿Hide fields
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |NO |YES |NO |All |

Syntax
******
**Hide fields** {*list-of-field-names* (Name1,Name2,...)}
Description
***********
This command hides the specified field or list of fields. You can display hidden fieldswith *`Show fields <show_fields.html>`_
*.
Example
*******

.. code-block:: omnis
	:linenos:	Yes/No message  {Do you want to hide fields?}If flag true    Begin reversible block        Hide fields {myField1,myField2}    End reversible blockEnd If;  do somethingQuit method ;  now this method ends and the fields are re-shown as they are in a reversible block;  To hide a single field on the current windowDo $cwind.$objs.myField1.$visible.$assign(kFalse);  to hide all fields on the current windowDo $cwind.$objs.$sendall($ref.$visible.$assign(kFalse))
