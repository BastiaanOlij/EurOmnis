﻿Accept advise requests
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Accept advise requests** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command enables or disables responses to a requestAdvise message from a client. With the **Accept** check box selected, Omnis willrespond to an Advise request message specifying a valid field name by repeatedly sendingthe field value to the client at appropriate times. If the **Accept** option isunchecked, all conversations with Advises in force will be terminated unless the commandis part of a reversible block.
Example
*******

.. code-block:: omnis
	:linenos:	Accept advise requests (Accept)
