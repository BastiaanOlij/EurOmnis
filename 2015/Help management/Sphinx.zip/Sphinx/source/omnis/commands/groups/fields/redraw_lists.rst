﻿Redraw lists
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |NO |NO |NO |All |

Syntax
******
**Redraw lists** ([*All windows*][,*All lists*][,*Selection only*])

Options
*******|All windows |If specified,the command applies to all open window instances,rather than just the top open window instance |
|All lists |If specified,the command applies to all lists on the window instance(s),rather than just the current list |
|Selection only |If specified,the command redraws the lists without reloading the data,in order to show changes to the selection state |

Description
***********
This command redraws the current list window field or all list fields. It lets youupdate the display of the current list field after you delete, change, or insert a line,so that the screen list reflects the changes. When Omnis executes* ***Redrawlists**, the selected line is scrolled into view and the visible linesrecalculated.

Omnis can execute a **Redraw list***s* command for all windowinstances and for all lists using the **All windows**, and **All lists**options. If neither option is selected, only the fields on the top window instance whichdisplay the current list are redrawn.

The **Selection only** option causes the redraw to affect the highlighting of theselected lines, the contents are not redrawn.

Omnis also redraws any fields which are local to the list field so that they willdisplay the new values. It also redraws the grid fields associated with the current list.
Example
*******

.. code-block:: omnis
	:linenos:	Begin reversible block    Set current list iListEnd reversible blockDefine list {iCol1,iCol2}Calculate iCol1 as 42Add line to list {(iCol1,chr(iCol1))}Redraw lists
