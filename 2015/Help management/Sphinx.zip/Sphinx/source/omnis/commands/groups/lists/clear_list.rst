﻿Clear list
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear list** ([*Hash lists*])

Options
*******|Hash lists |If specified,the command clears #L1-#L8,rather than the current list. When this option is specified,the command is not reversible |

Description
***********
This command clears all the lines in the current list and frees the memory they occupy.It does not alter the definition of the list. If you use **Clear list** aspart of a reversible block, the list lines will be reloaded when the method containing thereversible block finishes. The list is only reloaded if it occupies 50,000 bytes ofstorage or less.  Executing **Clear list** for a smart list sets $smartlist to `kFalse <../../../notation/root/constants/boolean_values.html>`_
, meaning that it is no longer a smart list.

The **All Lists** option only clears the hash variable lists #L1 to #L8: all otherlists including task, class, instance and local variable lists, are *not* cleared bythis command.

The following method builds a list of data formats depending on the type of graphselected by the user. Before the method is built the list is cleared using the **Clearlist** command; this ensures the list is initialized and completely empty of data.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iMyListClear list;  or you can do it like thisDo iMyList.$clear()
