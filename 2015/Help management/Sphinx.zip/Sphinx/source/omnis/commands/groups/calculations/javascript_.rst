﻿JavaScript:
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |NO |NO |`JavaScript (not server) <../../command_index.html#client commands>`_  |All |

Syntax
******
**JavaScript: ***javascript-code*****
Description
***********
Use this command to insert raw JavaScript into the method in the client methods JavaScript file.
