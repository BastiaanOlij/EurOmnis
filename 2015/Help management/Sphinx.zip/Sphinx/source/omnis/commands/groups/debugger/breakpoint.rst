﻿Breakpoint
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Breakpoint** {*message*}
Description
***********
This command places a breakpoint at a command line in a method where you want to stopexecution, to check your coding for example. You can include a message with the commandwhich is displayed in the debug window when the break occurs. The command does nothing atruntime.

When Omnis encounters a breakpoint the debugger is opened with the current methodloaded and the **Breakpoint** command line highlighted. You can examine thevalue of fields and variables by right button/Ctrl-clicking on the field or variable name.

Following a breakpoint you can continue method execution by clicking the Go button orby using Step or Trace mode.
Example
*******

.. code-block:: omnis
	:linenos:	;  hit breakpoint when line 5 is processed so we can check the values of lMyList columnsFor lMyList.$line from 1 to lMyList.$linecount step 1    If lMyList.$line=5        Do lMyList.$loadcols()        Breakpoint {check lMyList columns}    End ForEnd If
