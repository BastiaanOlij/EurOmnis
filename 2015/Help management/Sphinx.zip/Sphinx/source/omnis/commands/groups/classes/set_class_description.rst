﻿Set class description
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Set class description** {*class-name*/*description*}
Description
***********
This command sets the description text for the specified library class. When a class iscreated, you must specify a class name and also an optional description of up to 255characters. This command lets you set the description string for the specified libraryclass. The original description for the specified class is cleared if the descriptionparameter is left blank (or evaluates to an empty string). The flag is set if thedescription is changed.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lString as 'My Class Description';  set the class desciption to the contents of the local variable lStringSet class description {sMySearch/[lString]};  show the new contents of the class descriptionOK message  {[$clib.$classes.sMySearch.$desc]}
