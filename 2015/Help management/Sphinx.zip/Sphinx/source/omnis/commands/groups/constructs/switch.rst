﻿Switch
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Switch ***expression*****
Description
***********
This command initiates a Switch method construct. You use a **Switch**statement to select a course of action from a set of options based on the value of avariable, expression or calculation. It is similar to an *`If <if_calculation.html>`_
&#150;`Else If <else_if_calculation.html>`_
* construct although the performance of aSwitch construct tends to be faster.

The first line of the construction contains the **Switch** command. Thisdefines the variable, expression or calculation on which the choice of action will depend.Following the **Switch** command, the *`Case <case.html>`_
*commands provide values which, if matched with the expression supplied in the Switch line,cause the methods between case lines to be executed.

You can nest multiple Switch statements, and embed other conditional statements such as*`If <if_calculation.html>`_
&#150;`Else </else_if_calculation.html>`_
*constructs.
Example
*******

.. code-block:: omnis
	:linenos:	;  next button - only allow user to proceed to next page of a paged pane if the required information has been enteredCalculate lPage as $cwind.$objs.PagedPane.$currentpageSwitch lPage    Case 1        If len(iSerialNumber)=0            Calculate lErrorMsg as 'Please enter a serial number'        End If    Case 2        If len(iUserName)=0            Calculate lErrorMsg as 'Please enter your username'        End If    Case 3        If iAgreeFlag=kFalse            Calculate lErrorMsg as 'You may not proceed until you agree to the license agreement'        End IfEnd SwitchIf len(lErrorMsg)    OK message  {[lErrorMsg]}Else    Do $cwind.$objs.PagedPane.$currentpage.$assign(lPage+1)     ;; go to next pageEnd If
