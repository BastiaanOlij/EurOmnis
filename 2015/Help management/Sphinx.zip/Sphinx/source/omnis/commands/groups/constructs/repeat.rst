﻿Repeat
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Repeat**
Description
***********
This* *command repeats a command or series of commands that are contained in aloop closed by an `Until <until_calculation.html>`_
 command. Each time thecommand is repeated, Omnis tests the condition attached to the `Until <until_calculation.html>`_
 command to ensure that the condition istrue. If the condition is true, the commands in the loop are not executed and the commandafter the *`Until <until_calculation.html>`_
 *is executed. However, if thecondition is false, Omnis jumps back to the first command following the* Repeat*command. An error will result if there is a **Repeat** command without amatching `Until <until_calculation.html>`_
 command. Repeat loops alwaysexecute at least once. The **Repeat***&#150;`Until <until_calculation.html>`_
*logic test is carried out at the *end* of the loop, after the commands in the loopare executed, whereas the *`While <while_calculation.html>`_
&#150;`End While <end_while.html>`_
* logic test is carried out at the beginning of theloop.
Example
*******

.. code-block:: omnis
	:linenos:	Repeat    Yes/No message  {Press Yes to exit loop}Until flag trueRepeat    No/Yes message  {Press No to exit loop}Until flag falseRepeat    Prompt for input Enter a value greater than 10 to exit loop Returns lValueUntil lValue&gt;10
