﻿AND selected and saved
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**AND selected and saved** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command performs a logical AND of the Saved selection with the Current selection.You can specify a particular line in the list by entering either a number or acalculation. The **All lines** option performs the AND for all lines of the currentlist.

To allow sophisticated manipulation of data via lists, a list can store two selectionstates for each line; the &quot;Current&quot; and the &quot;Saved&quot; selection. TheCurrent and Saved selections have nothing to do with saving data on the disk; they are nomore than labels for two sets of selections. The lists may be held in memory and neversaved to disk: they will still have a Current and Saved selection state for each line butthey will be lost if not saved. When a list is stored in the data file, both sets ofselections are stored.

The list data structure contains the column definitions, the field values for each lineof the list, the current selected status and saved selected status for each line, *LIST.$line*,*LIST.$linecount* and *LIST.linemax*.

The **AND selected and saved** command performs a logical AND on the savedand current state, and puts the result into the Current selection. Hence, for a particularline, if both the Current and Saved states are selected, the Current state remainsselected, but if either or both states are deselected, the resulting Current state willbecome deselected.
|**Saved State** |**Current State** |**Resulting Current State** |
|Selected |Selected |Selected |
|Deselected |Selected |Deselected |
|Selected |Deselected |Deselected |
|Deselected |Deselected |Deselected |
Example
*******

.. code-block:: omnis
	:linenos:	;  Line 3 remains selected as it is the only line selected;  when both the 'Save selection for line(s)' and;  'AND selected and saved' commands are usedSet current list lMyListDefine list {lCol1}For lCol1 from 1 to 6 step 1    Add line to list {lCol1}End ForSelect list line(s) (All lines)Save selection for line(s) (All lines)Deselect list line(s) (All lines)Select list line(s) {3}AND selected and saved (All lines)
