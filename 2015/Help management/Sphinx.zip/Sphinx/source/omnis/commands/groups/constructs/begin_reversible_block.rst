﻿Begin reversible block
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |NO |All |

Syntax
******
**Begin reversible block**
Description
***********
This command begins a reversible block of commands. All reversible commands enclosedwithin the commands **Begin reversible block***/*`End reversible block <end_reversible_block.html>`_
* *are reversed when themethod containing this block finishes*. *However, a reversible block in the$construct() method of a window class reverses when the window is closed not when themethod is terminated as is normally the case. Omnis always steps backwards through areversible block of commands, thus the first command is reversed last.

Reversible blocks let you create subroutines that restore the values of variables, thecurrent record buffer, and so on, to their previous state when the method terminates. Mostcommands are reversible: those that are not usually involve an irreversible action such aschanging the data in an Omnis data file or running another program. Methods called fromwithin a reversible block are not reversed.
Example
*******

.. code-block:: omnis
	:linenos:	;  A method can contain more than one block of reversible commands. In this case,;  commands contained within all the blocks are reversed when the method terminates.;  All the commands in the following example are reversed when the method containing;  the block is finishedBegin reversible block    Disable menu line mMyMenu/5    Set current list iMyList    Build open window list (Clear list)    Calculate iVar as 0    Open window instance wMyWindowEnd reversible block;  When this block is reversed:;  The window instance wMyWindow is closed;  iVar returns to its former value;  iMyList is restored to its former contents and definition;  The current list is set to the former value;  Menu line 5 is enabled;  The following method hides fields Entry1 and Entry2 and installs the menu mCustomersBegin reversible block    Hide fields {Entry1,Entry2}    Install menu mCustomersEnd reversible blockOK message  (Icon) {MCUSTOMERS is now visible};  When this method ends, first MCUSTOMERS is removed, then the fields are shown.;  In the following example, the current list is iMyListBegin reversible block    Set current list iMyList2    Define list {fAccounts.Code,fAccounts.Surname,fAccounts.Balance}    Set main file {fAccounts}    Build list  from select table     Enter data End reversible block;  When this method terminates and the command block is reversed, the Main file is reset,;  the former list definition is restored and the current list is restored to iMyList.
