﻿Do not flush data
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Do not flush data**
Description
***********
This command causes all data file operations to be carried out without writing thechanged data to disk at each *`Update files <../../../commands/groups/changing_data/update_files.html>`_
* or *`Delete <../../../commands/groups/changing_data/delete.html>`_
*. The command isdesigned to speed up data file operations when the user is prepared to take the extra riskof data loss.

The command operates best when there is a single user logged into the data file. It isunlikely to cause speed increase if the data is on a network volume (that is, shared byseveral users).

If you use *`Test for only oneuser <../../../commands/groups/changing_data/test_for_only_one_user.html>`_
* at the beginning of the method, further users are prevented from opening thedata file until the method terminates.

The command sets the flag if the state of the 'Do not flush data' mode is changed. Whenplaced in a reversible block, the command restores the previous state of the 'Do notflush' flag upon the termination of the method.
Example
*******

.. code-block:: omnis
	:linenos:	;  fast importTest for only one userIf flag true    Do not flush data    Drop indexesEnd IfPrompt for import filePrepare for import from file {Delimited(tabs)}Import data lImportListEnd importClose import fileFor each line in list from 1 to lImportList.$linecount step 1    Prepare for insert     ;; transfer list to file    Load from list    Update filesEnd ForFlush data now     ;; writes the data immediately to diskBuild indexes     ;; rebuild indexesFlush data     ;; Changes mode back to 'Flush data'Repeat
