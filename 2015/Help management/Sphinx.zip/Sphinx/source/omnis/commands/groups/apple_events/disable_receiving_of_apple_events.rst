﻿Disable receiving of Apple events
#################################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |NO |YES |NO |MacOSX |

Syntax
******
**Disable receiving of Apple events** ([*Disable compulsory events*])

Options
*******|Disable compulsory events |If specified,the command disables the compulsory events (Open application,Quit application,Open documents,Print documents) in addition to other Apple events |

Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Disable receiving of Apple eventsPrepare for editEnter data Update files if flag set
