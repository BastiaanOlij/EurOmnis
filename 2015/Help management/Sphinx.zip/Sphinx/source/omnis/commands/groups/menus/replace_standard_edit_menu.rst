﻿Replace standard Edit menu
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Replace standard Edit menu** {*class-name*[/*instance-name*] [(*parameters*)]}
Description
***********
This command removes the standard built-in **Edit** menu from the menu bar andreplaces it with a custom menu. You can assign an instance name for the replacement menu.The default instance name of the replacement menu is the menu class name. If noreplacement menu name is specified, the **Edit** menu is reinstated.

The replacement menu will remain enabled even when commands such as *`Disable all menus <disable_all_menus_and_toolbars.html>`_
* are issued, or modaluser-defined windows are opened. The only time the replacement menu will not remainenabled is when a report is printed to screen with *`Send to screen <../../../commands/groups/report_destinations/send_to_screen.html>`_
*,and the check box option **Do not wait for user** is not checked (that is, Omnis isawaiting user input).

You can disable the **Edit** menu or its replacement menu by using *`Disable menu line <disable_menu_line.html>`_
*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Replace the standard edit menu with the user;  defined menu mMyEdit while in enter data;  $construct of windowReplace standard Edit menu {mMyEdit}Enter data Replace standard Edit menu     ;; put system Edit menu back
