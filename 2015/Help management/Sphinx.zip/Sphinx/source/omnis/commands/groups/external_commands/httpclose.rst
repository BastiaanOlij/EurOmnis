﻿HTTPClose
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPClose** (*socket*[,*option* {Default zero for complete;1 for partial;2 for abort}]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPClose** closes, and depending on the *Option*, releases a *Socket*.When the socket is connected, this will result in the closure of the connection to theremote application. All new sockets returned by all Web commands, must eventually bereleased using **HTTPClose**, to avoid resource leakage.

The most brutal form of **HTTPClose** is an abortive close. In this case,no consideration is given to the state of the connection, or exchanges with the remoteapplication, and the socket is closed and released immediately. This form of **HTTPClose**is recommended for use in error handling situations.

The mildest form of **HTTPClose** is a partial close. In this case, thesocket is not released, and you will need to call **HTTPClose** again torelease the socket. A partial close initiates a disconnect of the TCP/IP connection, bysending a TCP/IP packet with the finish flag set. This means that you can no longer senddata to the remote application, but you can continue to receive data. The remoteapplication will be informed of the partial close, when it receives zero bytes.

The remaining form of **HTTPClose** is a complete close. In this form, **HTTPClose**initiates a close of the connection if necessary, receives data on the connection until nomore is available (to flush the connection), and releases the socket. 
*
Socket* is an Omnis Long Integer field containing a number representing a previouslyopened socket.
*
Option *is an optional Omnis Integer field, which has the value zero for a completeclose, 1 for a partial close, and 2 for an abortive close. If omitted, it defaults to acomplete close.
*
Status* is an Omnis Long Integer field which receives the value zero for success, oran error code &lt; 0 for failure. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Connect to the server IP address iHostName on port iPort, send;  the message iMessage and then close the socketCalculate iHostName as '0.0.0.0'Calculate iPort as 6000Calculate lMessage as 'Hello remote application'HTTPOpen (iHostName,iPort) Returns iSocketIf iSocket&gt;0    ;  connected    HTTPSend (iSocket,lMessage) Returns lCharCountEnd IfHTTPClose (iSocket) 
