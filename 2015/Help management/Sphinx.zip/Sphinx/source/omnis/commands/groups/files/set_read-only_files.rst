﻿Set read-only files
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |YES |YES |NO |All |

Syntax
******
**Set read-only files** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command sets the file mode of the specified file(s) to read-only. You can read butnot write to a read-only file. *Set read-only files* does not cancel the Prepare forupdate mode.

If you use this command in a reversible block, the file reverts to its original modewhen the method containing the command block terminates.

In multi-user systems, you use *Set read-only files* to prevent Omnis from lockingcertain files. When you make files read/write, they are locked and re-read. In multi-usersystems, records such as invoice numbers and totals, accessed by a number of users, shouldbe made read-only to prevent delays caused by record locking. You must return the file toread/write status momentarily while it is updated.

In the method editor, a list of files is displayed. You can Ctrl/Cmnd-click on the filenames to select multiple names.
Example
*******

.. code-block:: omnis
	:linenos:	;  Data from fAccounts may be read, but not changedSet read-only files {fAccounts}Set main file {fInvoices}Prepare for insertEnter data Update files if flag set
