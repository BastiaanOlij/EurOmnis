﻿Copy to clipboard
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Clipboard <../clipboard.html>`_  |YES |NO |NO |All |

Syntax
******
**Copy to clipboard** *field-name*
Description
***********
This command copies the contents of the specified field or current selection and placesit on the clipboard. In the case of a null selection when the cursor is merely flashing ina field and no characters are selected, the **Copy to clipboard **commandwill literally copy &quot;nothing&quot;.
Example
*******

.. code-block:: omnis
	:linenos:	;  Copy one field to another then clear the first fieldCopy to clipboard iNamePaste from clipboard iDeliveryName (Redraw field)Clear data iName (Redraw field)
