﻿Logon to host
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Logon to host** (*Omnis character set*|*Native API character set*)

Types
*****|Omnis character set |The DAM and Omnis exchange data using the Omnis character set |
|Native API character set |The DAM and Omnis exchange data using the native API character set for the currently executing platform |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.