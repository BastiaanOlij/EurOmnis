﻿Send advises now
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Send advises now**
Description
***********
DDE command, Omnis as server. This command advises the client applications of all thefield values for all the fields for which Advise requests have been received. The valuesare taken from the CRB.
Example
*******

.. code-block:: omnis
	:linenos:	Set main file {fCustomers}Find on fCustomers.CustomerID (Exact match) {iCustID}Send advises now
