﻿Working message
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |NO |NO |NO |All |

Syntax
******
**Working message** *title* ([*Cancel button*][,*Repeat count*]) {*message*}

Options
*******|Cancel button |If specified,the message has a cancel button |
|Repeat count |If specified,the message displays a numeric repeat count (an internal value that increments during method execution) |

Description
***********
This command displays a window, usually to indicate that Omnis is working or waitingfor input. The window displays an alternating icon to indicate that Omnis is activelyworking. A working message automatically closes when the method quits, and control returnsto the user.

The **Title** parameter contains a title for the working message window, togetherwith parameters that configure the behavior and appearance of the window. The methodeditor has a Configure button that you can use to easily set these parameters. The **Title******parameter has the following syntax:

&lt;**Title text**&gt;/&lt;**start id**&gt;,&lt;**end id**&gt;;&lt;**speed**&gt;;&lt;**progressbar range**&gt;;&lt;**display delay**&gt;
**
****start id** and **end id** specify a range of icon ids, which identifythe icons drawn in the alternating sequence on the working message window. These areusually negative numbers, as each id is the sum of the icon id and the value of theconstant `k16x16 <../../../notation/root/constants/icons.html>`_
, `k32x32 <../../../notation/root/constants/icons.html>`_
 or `k48x48 <../../../notation/root/constants/icons.html>`_
, to indicate the size of the icon. These icons can comefrom #ICONS for the library, or OmnisPic or UserPic.
**
****speed**** **indicates the time, in 1/60<sup>th</sup> second units, thatan icon in the alternating sequence is displayed.
**
****progress bar range** specifies the range of a progress bar. If you specify anon-zero value, then the working message window displays a progress bar, and each call tothe Working message command increases the length of the bar until it reaches the range.
**
****display delay**** **specifies the time in 1/60<sup>th</sup> second units,that must elapse before the working message window becomes visible. This allows you to usethe Working message command in situations where the processing is sometimes very rapid,and in that case avoid the message displaying and disappearing almost immediately.

If a working message is placed in a loop with a **Cancel button**, pressingCtrl-break/Ctrl-C/Cmnd-period or clicking on Cancel quits all methods. However, if youfirst execute *`Disable canceltest at loops <../../../commands/groups/constructs/disable_cancel_test_at_loops.html>`_
*, you can implement an orderly exit. If *`Disable canceltest at loops <../../../commands/groups/constructs/disable_cancel_test_at_loops.html>`_
* is executed before the loop, the cancel is detected only onexecuting the *Working message*.

A **Repeat count** option is available with **Working message**, anddisplays the value of an internal counter which indicates the number of times a particular**Working message** has been encountered. If the command is in a *`Repeat <../../../commands/groups/constructs/repeat.html>`_
* loop, the counterincrements at each pass of the loop.
Example
*******

.. code-block:: omnis
	:linenos:	;  Working message with orderly exitBegin reversible block    Disable cancel test at loopsEnd reversible blockWorking message  (Cancel button) {Processing Record [lCount]}For lCount from 1 to 20000 step 1    Redraw working message    If canceled        Break to end of loop    End IfEnd ForOK message  {All done}
