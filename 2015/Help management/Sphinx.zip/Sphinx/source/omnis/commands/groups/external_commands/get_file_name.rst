﻿Get file name
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Get file name** (*path* [,*dialog*-*title*] [,*file*-*type...*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command opens the standard Open file dialog for the current Operating System, inorder to obtain the path of a file selected by the user. You would typically use thiscommand to prompt the user for the path of an existing file. If you want to prompt theuser to enter the path of a new file, use the *`Put file name 
`_
*command instead.

You can specify a *dialog-title* for the Open dialog.

The optional *file-type* parameter limits the choice of file types available.
*
Get file name* returns the full pathname of the file the user selects in *path*,or *path* remains empty if no file is selected (that is, the Cancel button wasclicked). The selected file is not opened.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
**File types
==========**
You can specify one or more extensions (using wildcard patternslike those used in many DOS and shell commands) separated by semicolons. For example,&quot;*.TXT&quot; would specify text files only.
Example
*******

.. code-block:: omnis
	:linenos:	;  open the Get File dialog and show only omnis librariesGet file name (lFilePath,'Select the library to open','*.lbs') Returns lErrCode;  open the Get File dialog and show only text filesGet file name (lFilePath,'Select the library to open','*.txt;*.doc') Returns lErrCode
