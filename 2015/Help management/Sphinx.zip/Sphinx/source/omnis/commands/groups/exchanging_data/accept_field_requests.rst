﻿Accept field requests
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Accept field requests** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command enables or disables responses to a requestfor field values issued by a client application. With the **Accept** option selected,Omnis will respond to a Request message specifying a valid field name by sending the fieldvalue to the client program. Values are taken from the current record buffer. Values areonly sent when Omnis is in enter data mode or when no methods are running.
Example
*******

.. code-block:: omnis
	:linenos:	Accept advise requests (Accept)Accept commands (Accept)Accept field requests (Accept)
