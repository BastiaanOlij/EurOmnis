﻿Delete selected lines
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Delete selected lines**
Description
***********
This command deletes all the selected lines from the current list. This is carried outin memory and has no effect on the lists stored in the data file unless a *`Prepare for Insert <../../../commands/groups/changing_data/prepare_for_insert.html>`_
/`Edit <../../../commands/groups/changing_data/prepare_for_edit.html>`_
* command isperformed. *LIST.$line* is unaffected unless it is left at a value beyond the end ofthe list, in which case it is set to *LIST.$linecount*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list and delete all lines except line 3Set current list lMyListDefine list {lCol1}For lCount from 1 to 10 step 1    Add line to list {(lCount)}End ForSelect list line(s) (All lines)Invert selection for line(s) {3}Delete selected lines
