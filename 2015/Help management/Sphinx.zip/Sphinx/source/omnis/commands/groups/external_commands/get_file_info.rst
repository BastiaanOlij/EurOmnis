﻿Get file info
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Get file info** (*path*, *type*, *creator*, *log*-*size*, *phy*-*size*, *creat*-*date*, *creat*-*time*, *mod*-*date*, *mod*-*time*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command returns information about the file specified in *path*.

A file may occupy more physical disk space than is necessary, because disk space isusually allocated in blocks of some fixed size. This is why the logical and physical sizescan be different.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  return the file info for the omnis executableCalculate lFileName as con(sys(115),'omnis.exe')Get file info (lFileName,lFileType,lFileCreator,lFileLogicalSize,lFilePhysicalSize,lFileCreationDate,lFileCreationTime,lFileModifiedDate,lFileModifiedTime) Returns lErrCode
