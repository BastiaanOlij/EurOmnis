﻿TCPAccept
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPAccept** (*socket*) **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

You use **TCPAccept** to accept an incoming connection request fromanother application.

The *Socket *parameter is a socket which is listening for incoming connections ona particular port. You must create this socket using *`TCPSocket <tcpsocket.html>`_
*,bind a port (and implicitly the local machine&#146;s IP address) to it using *`TCPBind <tcpbind.html>`_
*, and start listening for connections by calling *`TCPListen <tcplisten.html>`_
*, before you can call *TCPAccept* to acceptincoming connections using the socket.
*
***TCPAccept** is affected by the blocking state of the *Socket*parameter. If the *Socket* parameter is blocking, **TCPAccept** waitsuntil an incoming connection arrives, and then returns a new *Socket* for theconnection to the remote application. If the *Socket* parameter is non-blocking, **TCPAccept**will return a new *Socket* if an incoming connection request is already queued on thelistening socket; otherwise, it will return the error status &#150;10035, which means thatthe call would block.
*
***TCPAccept** returns a long integer, which is either a new socket forthe accepted connection, or an error code less than zero. The new socket has the sameblocking mode as the listening socket. The listening socket continues to listen forfurther incoming connection requests.
Example
*******

.. code-block:: omnis
	:linenos:	;  Accept incoming connections on port iPortCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPListen (iSocket) Returns lStatusIf lStatus=0    Repeat        TCPAccept (iSocket) Returns lConnectedSocket    Until lConnectedSocket&gt;=0    ;  client connected, get the whole message sentEnd IfTCPClose (iSocket) Returns lStatus
