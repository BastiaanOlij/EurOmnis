﻿If flag false
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**If flag false**
Description
***********
This command lets you implement a branch or change of processing order within a methoddepending on the result of the previous command. It tests the flag and if it is false, thecommands following the** If flag false **are executed. However, if the flagis true, control branches to the next *`Else <else.html>`_
*, *`Else If <else_if_calculation.html>`_
* or *`End If <end_if.html>`_
*in the method.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open the window wMyWindow if it is not already openTest for window open {wMyWindow}If flag false    Open window instance wMyWindowEnd If
