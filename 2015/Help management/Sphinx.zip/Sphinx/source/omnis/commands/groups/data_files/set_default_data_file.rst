﻿Set default data file
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |NO |YES |NO |All |

Syntax
******
**Set default data file** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command sets the default data file to be the current data file. Normally, fileclasses are associated with whatever the current data file is, at the time of execution.You use `Set current data file <set_current_data_file.html>`_
 to change theidentity of the current data file. As the current data file changes, the file classes areassociated with the changed current data file.
*
***Set default data file** sets the data file, for the specified fileclass or list of file classes, to be fixed at whatever is the current data file at thetime when the command executes. In other words, it creates an association between a listof file classes and the particular data file that was current. For these file classes, thedata file becomes fixed (that is, the &quot;default&quot; data file) and does not changewhenever the current data file changes. You can break the association with either a new **Setdefault data file** or a `Floatingdefault data file <floating_default_data_file.html>`_
 command.

When you close the default data file for a file, that file reverts to a floating state.This means that the default data file for that file reverts to the current data file andchanges when the current data file changes.
*
***Set default data file** does not change the flag but is reversible,that is, when the command is reversed, the previous default data files are restored. Aruntime error occurs if there are no data files open when the command is executed.
Example
*******

.. code-block:: omnis
	:linenos:	Open data file {myDataFile}     ;; open first datafileOpen data file (Do not close other data) {myOtherDataFile}     ;; open second datafileSet default data file {fCustomers,fOrders}Set current data file {myDataFile}Set main file {fCustomers};  This now refers to the myOtherDataFile NOT myDataFile which is the current data file
