﻿FTPCwd
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPCwd** (*socket*,*newdir*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPCwd** changes the working directory for the specified FTPconnection.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
NewDir* is an Omnis Character field containing the new working directory. Thecontents of this string are system-dependent. **FTPCwd** accepts anything forthis argument, but the remote FTP server may not. Most FTP servers accept Linux-style pathand file specifications with path and file separated by slashes, such as

/drive/user/subdirectory/filename.extension

Most FTP servers accept the Linux conventions for abbreviations for special directoryspecifications, that is, &quot;..&quot; for the next higher sub-directory, and&quot;~userid&quot; for the home directory of a particular user ID.

Some FTP servers also accept system-specific directory path formats, that is, Macintoshcolon-separated as in Macintosh HD:My Folder:My File or VMS-style path and filespecifications, as in SOME$DISK:[USER.SUBDIRECTORY]FILENAME.EXTENSION;1.

Consult the documentation for the server to determine the authoritative acceptabledirectory path specifications. When in doubt, try the Linux style.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lNewDirectory as '../testFolder'FTPCwd (iFTPSocket,lNewDirectory) Returns lErrCodeIf lErrCode    OK message FTP Error {[con(&quot;Error setting FTP directory&quot;,kCr,&quot;Error code : &quot;,lErrCode)]}End If
