﻿FTPDelete
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPDelete** (*socket*,*filename*[,*directory* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPDelete** deletes a file or directory on the connected FTP server.

*Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.

*Filename* is an Omnis Character field containing the pathname of the remote file or directory todelete.

*Directory* is an optional Boolean (that defaults to `kFalse <../../../notation/root/constants/boolean_values.html>`_
) which you pass as `kTrue <../../../notation/root/constants/boolean_values.html>`_
 if *Filename* is the pathname of a directory rather than a file.  Note that a directorymay need to be empty before you can delete it.

*Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lFileName as 'myFileToDelete'FTPDelete (iFTPSocket,lFileName) Returns lErrCodeIf lErrCode    OK message FTP Error {[con(&quot;Error deleting &quot;,lFileName,kCr,&quot;Status code: &quot;,lErrCode)]}End If
