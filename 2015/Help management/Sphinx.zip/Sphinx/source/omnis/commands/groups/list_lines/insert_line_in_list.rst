﻿Insert line in list
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Insert line in list** {*line-number* (*values*) {default is current line}}
Description
***********
This command takes the current field values and inserts them at a particular line inthe list. The new line is inserted before the specified line and all the lines below thespecified line are moved down one place.

If a set of comma-separated values is included as a parameter, these values are read(in order) into the columns of the new line. In this case, the field names for the columnsare not used to specify the data for the new line.

You can specify the line number using a calculation. However, if the parameter for thecommand is empty or evaluates to zero, the current line is used, that is, the field valuesare inserted at the current line and all other lines are moved down one place.

If there is no current line (*LIST.$line* = 0), the field values are added at theend of the list. If the line is beyond the current end of the list (for example, theLIST.$line given is greater than *LIST.$linecount*), *Insert line in list* isequivalent to *Add line to list*. The flag is cleared if the list is already at itsmaximum size (*LIST.$linemax*).
Example
*******

.. code-block:: omnis
	:linenos:	;  Insert 10 lines in between the 2 exisiting linesSet current list lMyListDefine list {lName,lAge}Insert line in list {('Fred',10)}Insert line in list {('George',20)}For lCount from 1 to 10 step 1    Insert line in list {2 ('Harry',22)}End For;  Alternatively, you can use the $addbefore() and $addafter() methods to add lines to a listDo lMyList.$addbefore(1,'Harry',22)Do lMyList.$addafter(2,'William',31)
