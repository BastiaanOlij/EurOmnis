﻿Copy list definition
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |NO |NO |All |

Syntax
******
**Copy list definition** *list-or-row-name* ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and removes its column definitions,before executing |

Description
***********
This command redefines the column headings of the current list by copying the columnsand data structure from the specified list. If the current list contains data and you donot clear the list, no change is made to the internal structure of the list; in this case,columns are neither added nor removed, merely renamed and the command is similar to** ***`Redefine list <redefine_list.html>`_
*.

When the current list is empty or the **Clear list** option chosen, the command isthe equivalent to 'Define the list so that it matches the specified list'.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iList1Define list {iCol1Date,iCol2Num,iCol3Char}Add line to listSet current list iList2Define list {iCol4Date,iCol5Num,iCol6Char}Add line to list;  now change the definition of iList2 to match iList1Copy list definition iList1 (Clear list);  or you can do it like thisDo iList2.$copydefinition(iList1)
