﻿TCPSend
#######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPSend** (*socket*,*buffer*) **Returns** *sent-byte-count*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

*Socket* is a long integer field containing the socket number of a connectedsocket.

*Buffer* is a character or binary field containing the data to send on thesocket. If you pass a character field, then **TCPSend** will convert the data to UTF-8, and then send the UTF-8.

**TCPSend** returns the numberof bytes it sent to *sent-byte-count, *a long Integer field.

If the socket is in blocking mode, **TCPSend**always sends all of the data, unless an error occurs.

If the socket is in non-blocking mode, **TCPSend**sends as much data as it can without blocking.

If an error occurs, **TCPSend** returns a negative error code

**Notes**

If the connection is secure (see *`TCPConnect <tcpconnect.html>`_
*) then the send will always be blocking, evenif the socket is marked as non-blocking.

Non-blocking sockets return an error code of -10035 if the socket cannotaccept the data to send immediately. Some implementations of socket libraries mayhave limits on the number of bytes you can send at one time. Consult thedocumentation for your installed sockets libraries. You may have to send a message inmultiple chunks in order to send a very long message. Always check *sent-byte-count* to determine how much of the buffer has actually been sent; if thevalue is less than the buffer size, you need to call **TCPSend** again, to send the rest of thebuffer.

It does not make sense to send a character field on a non-blockingsocket, because the *sent-byte-count* corresponds to the sent UTF-8 bytes.
Example
*******

.. code-block:: omnis
	:linenos:	;  Connect to the server IP address iHostName on port iPort and send;  the message iMessageCalculate iHostName as '0.0.0.0'Calculate iPort as 6000Calculate lMessage as 'Hello remote application'TCPConnect (iHostName,iPort) Returns iSocketIf iSocket&gt;0    ;  connected    TCPSend (iSocket,lMessage) Returns lByteCountEnd If
