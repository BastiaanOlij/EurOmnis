﻿Redefine list
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |NO |NO |NO |All |

Syntax
******
**Redefine list** {*list-of-field-or-file-names*  (F1,F2..F3,F4)}
Description
***********
This command redefines the columns of the current list. No change is made to the datacurrently stored in the list, or to the data type of each column; the command only changesthe field name associated with each column. If you pass more field names to **Redefinelist** than the current number of columns, the extra names are ignored. List boxeson windows will no longer display the data in the list unless you change their$calculation property to include the new variable or field name(s).
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iList1Define list {iCol1Date,iCol2Num,iCol3Char}Add line to list;  redefine the 3rd column in the list to hold boolean valuesRedefine list {iCol1Date,iCol2Num,iCol4Boolean};  the boolean field value is converted into a character field format 'YES' etc and then add to the listAdd line to list;  or do it like thisDo ilist.$redefine(iCol1Date,iCol2Num,iCol4Boolean)
