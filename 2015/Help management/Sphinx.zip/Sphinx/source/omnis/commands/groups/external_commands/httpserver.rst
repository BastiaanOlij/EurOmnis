﻿HTTPServer
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPServer** (*webproc*,*port*[,*workingmessage* {Default non-zero for visible; zero for invisible}]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPServer** invokes a listening socket on a specified port, toreceive incoming HTTP requests. This command optionally shows an Omnis working message with thecount of accepted connections. *HTTPServer* calls a user-specified Omnis method eachtime a new connection arrives. The user function receives the socket number for the newHTTP connection.
*
WebProc* is an Omnis Character field containing the name of the Omnis method to becalled when a connection arrives. The method receives one parameter, the number of thesocket for the new HTTP connection. For example, MYLIBRARY.MYCODE/MYPROC.

You may read and write to the parameter socket with *`HTTPRead <httpread.html>`_
*,*`HTTPSend <httpsend.html>`_
*, or *`HTTPHeader <httpheader.html>`_
*commands or a TCP equivalent ( *`TCPSend <tcpsend.html>`_
*; for example).
*
Port* is an Omnis Integer field that is optionally used to indicate the port numberon which *HTTPServer* listens for connections. If omitted, the port number defaultsto 80.
**
Caution: **You must close the socket with *`HTTPClose <httpclose.html>`_
*before quitting the Omnis method.

The command returns an integer *status*, which is less than zero if an erroroccurs. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
**
Stopping HTTPServer
**
Once started, **HTTPServer** runs indefinitely until it is stopped. Thereare three ways to stop **HTTPServer**:
<blockquote>  
1. Press the Cancel button on the working message displayed by the command.
	
2. Press the break key sequence (Ctrl-Break/Ctrl-C/Cmnd-period).
  
3. Set the Omnis flag to false before returning from the WebProc method. Obviously, you  need to make sure the flag is true before returning, if you wish to process further  connections
</blockquote>Example
*******

.. code-block:: omnis
	:linenos:	;  Listen for incoming http requests on port 6001, call the;  method $newconnection in the current instance when a;  connection arrives.HTTPServer ('$newconnection',6001) Returns lStatus
