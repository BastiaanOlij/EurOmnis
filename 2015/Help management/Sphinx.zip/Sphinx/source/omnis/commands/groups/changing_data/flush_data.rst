﻿Flush data
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Flush data**
Description
***********
This command reverses *`Do not flush data <do_not_flush_data.html>`_
* andreverts to the default mode where the changed data is immediately written to disk aftereach *`Update files <update_files.html>`_
* or *`Delete <delete.html>`_
*command.

The command sets the flag if the state of the 'Do not flush data' mode is changed andis reversible, restoring the previous state of the 'Do not flush' flag when reversed. Ifthe previous mode was 'Do not flush data', `Flush data <flush_data.html>`_
will cause any modified data which has not been written to disk, to be written on the next*`Update files <update_files.html>`_
* or *`Delete <delete.html>`_
*.
<blockquote>  
 
</blockquote>Example
*******

.. code-block:: omnis
	:linenos:	;  fast importTest for only one userIf flag true    Do not flush data    Drop indexesEnd IfPrompt for import filePrepare for import from file {Delimited(tabs)}Import data lImportListEnd importClose import fileFor each line in list from 1 to lImportList.$linecount step 1    Prepare for insert     ;; transfer list to file    Load from list    Update filesEnd ForFlush data now     ;; writes the data immediately to diskBuild indexes     ;; rebuild indexesFlush data     ;; Changes mode back to 'Flush data'
