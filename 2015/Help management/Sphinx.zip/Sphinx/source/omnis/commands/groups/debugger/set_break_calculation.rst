﻿Set break calculation
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |NO |All |

Syntax
******
**Set break calculation** **on ***field-name***** {*calculation*}
Description
***********
This command stops method execution when the specified calculation evaluates to true;all values except zero are considered true. You use **Set break calculation**after a *`Variable menu command: Set break oncalculation {field-name} <variable_menu_command.html>`_
* command. The field used in the command does not have tofeature in the calculation but is used to &quot;label&quot; the break within Omnis.

At breakpoints, a method design window is opened with the current method loaded and thebreakpoint command highlighted. You can examine field values by right button/Ctrl-clicking on the field or step through the remaining method.

Setting up calculated breakpoints slows down method execution considerably so youshould use them sparingly. In runtime the command does nothing.
Example
*******

.. code-block:: omnis
	:linenos:	;  pause method execution when lMyBoolean=kTrueCalculate lMyBoolean as kFalseVariable menu command: Set Break On Calculation {lMyBoolean}Set break calculation on lMyBoolean {lMyBoolean=kTrue}For lCount from 1 to 10 step 1    If lCount=5        Calculate lMyBoolean as kTrue    End IfEnd For
