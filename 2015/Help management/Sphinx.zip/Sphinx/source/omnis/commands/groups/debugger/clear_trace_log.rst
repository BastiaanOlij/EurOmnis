﻿Clear trace log
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |NO |All |

Syntax
******
**Clear trace log**
Description
***********