﻿Set final line number
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Set final line number** {*line-number* (*calculation*)}
Description
***********
This command explicitly sets the value of LIST.$linecount by specifying a line numberor a calculation. Omnis expands or contracts any list as necessary and maintains the valueof the LIST.$linecount property as the last line number. If the number of lines in thelist is less than the number set for LIST.$linecount, Omnis adds empty lines to the end.If the number of lines is greater than LIST.$linecount, Omnis shortens the list andreduces the memory needed by the list.

You can use **Set final line number** to speed up list handling by settingthe final line number to shorten lists, for example. The list is effectively cleared ofdata when the line number parameter is left blank (or evaluates to zero).
Example
*******

.. code-block:: omnis
	:linenos:	;  Reduce the number of lines in the list;  from 100 to 50Set current list lMyListDefine list {lCol1}For lCol1 from 1 to 100 step 1    Add line to list {lCol1}End ForOK message  {List has [lMyList.$linecount] lines}Set final line number {50}OK message  {List now has [lMyList.$linecount] lines}
