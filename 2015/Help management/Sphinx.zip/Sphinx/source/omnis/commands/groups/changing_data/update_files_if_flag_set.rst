﻿Update files if flag set
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Update files if flag set** ([*Do not cancel pfu*])

Options
*******|Do not cancel pfu |If specified,Omnis remains in prepare for update mode after the command finishes,meaning that multi-user locks remain in place,and you can perform further updates |

Description
***********
This command writes the current values in the current record buffer to disk if the flagis set, that is, true. This is a variation on the *`Updatefiles <update_files.html>`_
* command and is equivalent to:

When the command follows *`Enter data <../../../commands/groups/enter_data/enter_data.html>`_
*, the Preparefor update mode is canceled, and the record is stored on disk if the user clicks OK orpresses the Return/Enter key.
Example
*******

.. code-block:: omnis
	:linenos:	If flag true    Update filesEnd If
