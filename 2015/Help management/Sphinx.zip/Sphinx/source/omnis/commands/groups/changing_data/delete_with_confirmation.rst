﻿Delete with confirmation
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Delete with confirmation** {*message*}
Description
***********
This command displays a message asking the user to confirm or cancel the deletion and,if confirmation is granted, deletes the current record in the main file. An error isreported if there is no main file.

If a message is not specified, Omnis uses a default message. The message can containsquare-bracket notation which is evaluated when the command is executed. If the currentrecord is deleted, the flag is set, otherwise it is cleared. If the *`Do not waitfor semaphores <../../../commands/groups/changing_data/do_not_wait_for_semaphores.html>`_
* option is on, the flag is cleared if the record is locked.
Example
*******

.. code-block:: omnis
	:linenos:	;  This example allows selected records in the main file to be deleted:Set main file {fAccounts}Set search as calculation {fAccounts.Balance&lt;0}Find first on fAccounts.Code (Use search)While flag true    Delete with confirmation {Delete [fAccounts.Surname]'s record?}    Next  (Use search)End While
