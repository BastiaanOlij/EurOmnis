﻿Build indexes
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Build indexes** {*file-name*}
Description
***********
This command rebuilds all the indexes for the specified file which have been droppedwith the `Drop indexes <drop_indexes.html>`_
 command. `Drop indexes <drop_indexes.html>`_
 deletes all the indexes for the specifiedfile apart from the sequence number index. **Build indexes** checks that allthe indexes defined in the file class actually exist in the data file and builds thosewhich are not there. This command does not build any indexes which already exist even ifthey are in a damaged state.

If the specified file name does not include a data file name as part of the notation,the default data file for that file is assumed. If the file is closed or memory-only, thecommand does not execute and returns flag false.

If you are not running in single user mode, this command automatically tests that onlyone user is using the data file (the command fails with the flag false if this is nottrue), and further users are prevented from logging onto the data until the commandcompletes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute, andit is not possible to cancel execution even if a working message with cancel box is open.

The flag is set if at least one index is successfully rebuilt. Note that the command isnot reversible.
Example
*******

.. code-block:: omnis
	:linenos:	Do not flush dataDrop indexes {fCustomers}Repeat    Working message  {Building indexes...}    Build indexes {fCustomers}Until flag true
