﻿XOR selected and saved
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**XOR selected and saved** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command performs a logical XOR of the Saved selection with the Current selection.To allow sophisticated manipulation of data via lists, a list can store two selectionstates for each line; the &quot;Current&quot; and the &quot;Saved&quot; selection. TheCurrent and Saved selections have nothing to do with saving data on the disk; they are nomore than labels for two sets of selections. The lists may be held in memory and neversaved to disk: they will still have a Current and Saved selection state for each line butthey will be lost if not saved. When a list is stored in the data file, both sets ofselections are stored.

You can specify a particular line in the list by entering either a number or acalculation.

The **XOR selected and saved** command performs a logical XOR (exclusiveOR) on the Saved and Current state and puts the result into the Current selection. Hence,if either of the Current and Saved states is selected, the Current state becomes selected,but if both states are equal, the resulting Current state will become deselected.
**
Logic Table (S=selected, D=deselected)
**|**Saved** |**Current** |**Resulting Current State** |
|S |S |D |
|D |S |S |
|S |D |S |
|D |D |D |

The **All lines** option performs the XOR for all lines of the current list. Theflag is set by this command. The following example selects the middle line of the list:
Example
*******

.. code-block:: omnis
	:linenos:	;  Leave line 3 selectedSet current list lMyListDefine list {lCol1}For lCol1 from 1 to 6 step 1    Add line to list {lCol1}End ForSelect list line(s) (All lines)Save selection for line(s) (All lines)Invert selection for line(s) {3}XOR selected and saved (All lines)
