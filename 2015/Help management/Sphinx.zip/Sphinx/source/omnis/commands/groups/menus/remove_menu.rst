﻿Remove menu
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |YES |NO |All |

Syntax
******
**Remove menu** *menu-instance-name*
Description
***********
This command removes the specified menu instance from the menu bar and sets the flag.You can choose the menu name from a list containing any custom and standard built-inmenus, such as ***File**, ***Edit**, and so on.

If you use this command to remove a menu instance which has previously been installedin place of the standard **File** or **Edit** menu (using the `Replace standard File menu <replace_standard_file_menu.html>`_
 or *`Replace standard Edit menu <replace_standard_edit_menu.html>`_
 *command) thepreviously replaced standard **File** or **Edit** menu is restored.

If you use **Remove menu** in a reversible block, the specified menuinstance is reinstalled when the method containing the reversible block terminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  If the menu mView is installed remove itTest for menu installed {mView}If flag true    Remove menu mViewEnd If;  Alternatively, you can remove a menu using $closeDo $imenus.mView.$close()
