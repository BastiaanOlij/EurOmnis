﻿Set SQL blob preferences
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |NO |YES |NO |All |

Syntax
******
**Set SQL blob preferences** (*Default*|*Load all*|*Segment*|*Threshold*) {*chunk-size*/*threshold*}

Types
*****|Default |Use this if you want the DAM to deal with splitting BLOBs |
|Load all |Use this if you want to pass each BLOB as a single chunk; note that certain DAMs may not be able to handle BLOBs over a certain size in this way |
|Segment |Use this to specify the chunk size for splitting BLOBs |
|Threshold |Use this to specify the threshold and chunk size for splitting BLOBs |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.