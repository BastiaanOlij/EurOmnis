﻿Prompted find
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Prompted find** ([*Exact match*])

Options
*******|Exact match |If specified,the index value of the field in suitable records must equal the current value |

Description
***********
This command prompts the user to enter a value in an indexed field on the currentwindow and locates the record which most closely matches that value. The user can use theTab key to select an indexed field. The Find field is the current field for the windowwhen the user clicks on the OK button.

Once the user enters a value in the Find field and clicks OK, Omnis locates the recordmost closely matching this value, the main and connected files are read into the currentrecord buffer and the flag is set. If the indexed field is in a connected file, the findcontinues until a record connected to a valid main file record is located. The currentindex, as used by *`Next <next.html>`_
* and *`Previous 
`_
*,is set to the Find field.

If the exact field value cannot be matched, the next highest value in the index islocated. You use the **Exact match**** **option if you want only the exact match.
Example
*******

.. code-block:: omnis
	:linenos:	;  Find the record for an indexed value entered into;  the current window instancePrompted findIf flag true    Do $cinst.$redraw()End If
