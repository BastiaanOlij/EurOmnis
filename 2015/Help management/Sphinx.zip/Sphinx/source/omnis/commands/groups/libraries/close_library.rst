﻿Close library
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Libraries <../libraries.html>`_  |YES |NO |NO |All |

Syntax
******
**Close library** {*internal-name* (leave empty to close all)}
Description
***********
This command closes the open library file with the specified internal name, or closesall the open library files if no name is specified. It sets the flag if at least onelibrary file is closed. It clears the flag and does nothing if the specified internal namedoes not correspond to an open library.

Note that the internal name for a library defaults to its physical file name from whichthe path and DOS extension has been removed. The *`Openlibrary <open_library.html>`_
* command also lets you specify the internal name (see the example below).

Closing a library closes all windows, reports, and menus belonging to that librarywhich are open or installed. It also disposes of the CRBs for the file classes and classvariables belonging to that library, closes all lookup files opened by that library, andif there is a running method from that library on the stack, clears the method stack. Ifthe method stack is cleared, the command following the current executing command will notexecute, and it is not possible to test the flag value returned from the command.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open and close the library mylib.lbs from the root;  of your omnis studio treeCalculate lLibPath as con(sys(115),'mylib.lbs')Open library (Do not close others) {[lLibPath],MYLIB}If flag true    Yes/No message  {Close Library ?}    If flag true        Close library {MYLIB}    End IfEnd If
