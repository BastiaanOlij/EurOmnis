﻿Reset cursor(s)
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Reset cursor(s)** (*Current*|*Session*|*All*)

Types
*****|Current |Clears the SQL buffer, error status and select table for the current cursor |
|Session |Clears the SQL buffer, error status and select table for all cursors in the session containing the current cursor |
|All |Clears the SQL buffer, error status and select table for all cursors |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.