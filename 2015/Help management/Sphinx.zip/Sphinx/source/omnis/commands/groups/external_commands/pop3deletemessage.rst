﻿POP3DeleteMessage
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3DeleteMessage** (*socket*,*messagenumber*[,*stsproc*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3DeleteMessage** marks a message stored on a POP3 server fordeletion. The POP3 server deletes messages marked for deletion when you call *POP3Disconnect.*Before calling *`POP3Disconnect 
`_
*<u>,</u> you cancall *`POP3UndoDeletes 
`_
*, to remove the deletion markfrom all messages.
*
Socket* is an Omnis Long Integer field containing a socket opened to a POP3 serverusing `POP3Connect 
`_
.
*
MessageNumber* is an Omnis Long Integer field which identifies the message to bemarked for deletion. Message numbers are assigned by the POP3 server, after you call *`POP3Connect 
`_
, *starting with 1 for the first message, 2 forthe second, and so on.
*
StsProc* is an optional parameter containing the name of an Omnis method that **POP3DeleteMessage**calls with status messages. **POP3DeleteMessage** calls the method with noparameters, and the status information in the variable #S1. The status information logsprotocol messages exchanged on the connection to the server.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Delete the first message for user lUsername from the POP3;  server lServerCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocketPOP3DeleteMessage (iSocket,1) POP3Disconnect (iSocket)      ;; message is not deleted until disconnect
