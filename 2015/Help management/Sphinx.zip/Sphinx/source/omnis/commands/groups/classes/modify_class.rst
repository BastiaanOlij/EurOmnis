﻿Modify class
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Modify class** {*class-name*}
Description
***********
This command opens a library class in design mode. Method execution continues and doesnot wait for the design window to be closed. **Modify class** lets usersmodify new search and report classes created with the *`New class <new_class.html>`_
*command. Opening a class in design mode when one of its methods is running causes a *`Quit all methods <../../../commands/groups/methods/quit_all_methods.html>`_
* tobe carried out before the design window opens. If the class does not exist, the commandclears the flag.
Example
*******

.. code-block:: omnis
	:linenos:	New class {Search Class/sOverDrawn}Modify class {sOverDrawn};  now you canSet search name sOverDrawnPrint report (Use search)
