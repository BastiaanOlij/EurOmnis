﻿Update files
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Update files** ([*Do not cancel pfu*])

Options
*******|Do not cancel pfu |If specified,Omnis remains in prepare for update mode after the command finishes,meaning that multi-user locks remain in place,and you can perform further updates |

Description
***********
This command writes the records in the current record buffer to disk and cancels thePrepare for... mode. You must execute the command when Omnis is in a Prepare for updatemode otherwise an error occurs.

If a warning error code *kerrUnqindex* or *kerrNonull* is returned during theexecution of this command, the Prepare for update mode is *not *canceled. This meansthat you can check for these errors and recover without losing the data the user hasalready typed in. In fact, if you issue a new *Prepare for...* command, Omnis willreread records, and any data that is already in the CRB will be lost.

The** ****Do not cancel pfu** option prevents the command from cancelingPrepare for update mode. Thus, you can make more changes to the data, the multi-user locksremain in place, and another **Update files** can be executed.

The **Update files** command causes the indexes in the files to bere-sorted. Thus, in multi-user mode, the files are locked while **Update files**is executing. You can control this file locking by running *`Do not wait for semaphores <do_not_wait_for_semaphores.html>`_
*. When *`Do not wait for semaphores <do_not_wait_for_semaphores.html>`_
* is active, **Updatefiles** returns flag false and does nothing if the file is locked.
Example
*******

.. code-block:: omnis
	:linenos:	;  The following example inserts an invoice in the parent file and a list of related invoice;  items in the child file.  The Do not cancel pfu option ensures that the parent record;  remains locked until complete.Set main file {fInvoice}Prepare for insertEnter data Update files (Do not cancel pfu)Set main file {fItems}For lInvoiceItems.$line from 1 to lInvoiceItems.$linecount step 1    Prepare for insert    Load from list    Update files (Do not cancel pfu)End ForUpdate files;  In multi-user mode you can control file locking using Do not wait for semaphores, for exampleWait for semaphoresPrepare for editEnter data Do not wait for semaphoresIf flag true    Repeat        Working message  {Waiting for file locks}        Update files    Until flag trueEnd If
