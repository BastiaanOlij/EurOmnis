﻿Prepare for import from file
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Prepare for import from file** {*export-format*}

Export Formats
**************|Delimited (commas) | |
|Delimited (tabs) | |
|One field per line | |
|Omnis data transfer | |
|Delimited (user delimiter) | |

Description
***********
This command prepares Omnis for a series of *`Import data <import_data.html>`_
*commands. You must specify the format for the import data as the parameter, otherwise anerror will occur. The parameter can contain square bracket notation but must evaluate to avalid import format name. You should use the `Setimport file name <set_import_file_name.html>`_
 command to specify the name of the file to be read in.

If the data matches the specified import format, the flag is set. However, if the datadoes not match the import format, the flag is cleared.

When data is imported via a method rather than the **Utilities** menu, you must opena window which defines the fields in which the incoming data must be placed. The examplebelow shows a typical import data method.

You can use a $control() method in conjunction with the *Import data* command.

If there are too few fields on the window, imported fields will be lost. If there aretoo many, the extra fields are cleared. You can use the *`Do not flush <../../groups/changing_data/do_not_flush_data.html>`_
* command tospeed up the import when there is only one user logged into the data file.
Example
*******

.. code-block:: omnis
	:linenos:	;  import from a csv file called myImport.txt in the root of your omnis treeCalculate lImportPath as con(sys(115),'myImport.txt')Set import file name {[lImportPath]}Prepare for import from file {Delimited (commas)}Import data lImportListEnd importClose import file
