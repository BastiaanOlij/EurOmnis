﻿TCPName2Addr
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPName2Addr** (*hostname*[,*ipv6* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *address*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPName2Addr** is a domain name service command that returns the IPaddress for a given *Hostname*.
*
Hostname *is an Omnis Character field containing a hostname to convert to an IPaddress. The hostname is of the form machine[.*domainame.dom*]
*
Address *is an Omnis Character field which receives the IP Address corresponding tothe given hostname. The IP address is of the form 255.255.255.254
**
Note: **This command fails if the address of a Domain Name Server has not beendefined in your computer. Not all host IP Addresses may be known to the Domain NameServer. If the Domain Name Server is busy or unavailable, the command times out andreturns an error. Defining often-used servers to a local host&#146;s file or using acaching Domain Name Server increases performance of this command.
Example
*******

.. code-block:: omnis
	:linenos:	;  Return the IP address for pHostNameTCPName2Addr (pHostName) Returns lIPAddressQuit method lIPAddress
