﻿Write entire file
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Write entire file ** (*path*, *binary*-*variable*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command writes an entire file from a binary field, previously populated by usingRead entire file. It returns an error code (See `Error Codes <fileops_error_codes.html>`_
),or zero if no error occurs. The Binary value is in the following format: <ol>  <li>12 byte header containing the Type (4 bytes), Creator (4 bytes), and File length (4    bytes).</li>  <li>File data.</li></ol>Example
*******

.. code-block:: omnis
	:linenos:	;  read and then write the binary contents of mypicture.jpgCalculate lPathname as con(sys(115),'mypicture.png')Read entire file  (lPathname,lBinfld) Returns lErrCodeWrite entire file  (lPathname,lBinfld) Returns lErrCode
