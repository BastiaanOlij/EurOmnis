﻿Build externals list
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Externals <../externals.html>`_  |YES |YES |NO |All |

Syntax
******
**Build externals list** ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |

Description
***********
This command builds a list of the external routines in the external** **folder. Thelist is placed in the current list for which you must define the following columns
|**Col 1 (Character)** |**Col 2 (Character)** |**Col 3 (Number)** |**Col 4 (Character)** |
|File name |Routine name |Routine index or ID |Routine type |

The *Clear list* option clears the current list. The command becomes reversiblewith this option.
Example
*******

.. code-block:: omnis
	:linenos:	Begin reversible block    Set current list iExtListEnd reversible blockDefine list {iExtName,iExtRoutine,iExtRoutineIndex,iExtRoutineType}Build externals list
