﻿HTTPSplitHTML
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPSplitHTML** (*message*,*tagtextlist*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPSplitHTML** is a client function to parse the HTML from a Webpage into an Omnis list. The HTML tags are parsed out of the text, so that it easier towrite a program that grabs the Web page content or interprets the tags from a form.
*
Message* is an Omnis Character or Binary field containing the text of the contentportion of a Web page, including HTML tags.
*
TagtextList* is an Omnis list defined to have three columns, all character. Column 1contains the opening HTML tag, column 2 the actual page text, and column 3 the closingHTML tag.

The command returns an integer *status*, which is less than zero if an erroroccurs. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Parse the html from lURL into the list lHtmlTagListCalculate lUrl as 'http://www.omnis.net/news/index.html'HTTPPage (lUrl) Returns lHtmlPageDo lHtmlTagList.$define(lOpeningHtmlTag,lHtmlText,lClosingHtmlTag)HTTPSplitHTML (lHtmlPage,lHtmlTagList) 
