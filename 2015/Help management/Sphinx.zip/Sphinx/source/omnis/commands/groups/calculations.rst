﻿Calculations
############
`Command Index <../command_index.html>`_


`Commands
******** <calculations#commands>`_
|`Calculate <calculations/calculate.html>`_  |`Do <calculations/do.html>`_  |`Do default <calculations/do_default.html>`_  |`Do inherited <calculations/do_inherited.html>`_  |
|`Do redirect <calculations/do_redirect.html>`_  |`JavaScript: <calculations/javascript_.html>`_  |`Set reference <calculations/set_reference.html>`_  |`Test for valid calculation <calculations/test_for_valid_calculation.html>`_  |

