﻿CGIEncode
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**CGIEncode** (*stream*[,*mapplustohex* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *encoded-stream*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

When a client uses HTTP to invoke a script on a WEB server, it uses the CGI encodedformat to pass the arguments to the server. This avoids any ambiguity between thecharacters in the argument names and values, and the characters used to delimit URLs, andthe argument names and values.

You use **CGIEncode** to map text into the CGI encoded format.

*Stream* is an Omnis Character or Binary field containing the information to encode.

*MapPlusToHex* is an optional Boolean parameter which when true indicates that plus characters in the input *stream* are to be URL encoded as hex.

*EncodedStream* is an Omnis Character or Binary field that receives the resultingCGI-encoded representation of the *stream* argument.
**
Note: **The **`HTTPHeader <httpheader.html>`_
**, **`HTTPParse <httpparse.html>`_
** and **`HTTPPost <httppost.html>`_
**commands automatically perform CGI encoding or decoding, as appropriate.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lStream as 'Name: Charlie Malone,Company: TigerLogic'CGIEncode (lStream) Returns lEncodedStream
