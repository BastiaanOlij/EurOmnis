﻿Close all designs
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Close all designs**
Description
***********
This command closes all the design windows currently open, including all instances ofthe method editor.
Example
*******

.. code-block:: omnis
	:linenos:	Close all designs
