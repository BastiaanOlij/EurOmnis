﻿Build file list
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |YES |YES |NO |All |

Syntax
******
**Build file list** ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |

Description
***********
This command builds a list containing the name of each file class in the currentlibrary. The list is built in the current list for which you must specify the followingcolumns.
|**Column 1 (Character)** |**Column 2 (Character)** |
|File name |Description for file (if you have entered one) |

When you use the **Clear list** option you get column 1 only defined as #S5. Withthis option the command becomes reversible, that is, the original contents of the list arerestored. The flag is cleared if the number of lines in the list exceeds *LIST.$linemax*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list of file classes in the current librarySet current list lFileListBuild file list (Clear list);  alternatively $makelist can be usedDo $files.$makelist($ref.$name) Returns lFileList
