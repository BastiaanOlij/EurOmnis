﻿Lists
#####
`Command Index <../command_index.html>`_


`Commands
******** <lists#commands>`_
|`Build list columns list <lists/build_list_columns_list.html>`_  |`Build list from file <lists/build_list_from_file.html>`_  |`Clear list <lists/clear_list.html>`_  |`Copy list definition <lists/copy_list_definition.html>`_  |
|`Define list <lists/define_list.html>`_  |`Define list from SQL class <lists/define_list_from_sql_class.html>`_  |`Merge list <lists/merge_list.html>`_  |`Redefine list <lists/redefine_list.html>`_  |
|`Search list <lists/search_list.html>`_  |`Set current list <lists/set_current_list.html>`_  |`Sort list <lists/sort_list.html>`_  |`Swap lists <lists/swap_lists.html>`_  |

