﻿Set closed files
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |YES |YES |NO |All |

Syntax
******
**Set closed files** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command sets the file mode of the specified file(s), other than a main file, toclosed. Closing a file prevents any data from being read or changed in that file.

If you attempt to close the main file an error occurs. If you use *Set closed files*in a reversible block, the file mode is reset when the method terminates. **Setclosed files** does not cancel the Prepare for update mode. In multi-userlibraries, closing a file prevents Omnis from locking it.

Closing a parent file when editing a child has the effect of protecting the connectionsfrom child to parent from change and saves time when locating child records because theparent record is not loaded.

In the method editor, a list of files is displayed. You can Ctrl/Cmnd-click on the filenames to select multiple names.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prevent data from being read or changed in the files;  fAccounts and fInvoicesSet closed files {fAccounts,fInvoices}
