﻿Paste from clipboard
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Clipboard <../clipboard.html>`_  |YES |NO |NO |All |

Syntax
******
**Paste from clipboard** *field-name* ([*Redraw field*][,*All windows*])

Options
*******|Redraw field |If specified,the command reloads affected window fields with the new value of the data field,after it has performed the operation; note that this takes the 'All windows' option into account |
|All windows |If specified,the command applies to all open window instances,rather than just the top open window instance |

Description
***********
This command pastes the contents of the clipboard into the specified field, currentselection or at the insertion point. When the **field-name** parameter is specified, **Pastefrom clipboard** pastes the contents of the clipboard into the field replacing thecontents of the whole field. However, when the **field-name** parameter is notspecified the command will paste the contents of the clipboard at the current selection (arange of selected characters) or the insertion point within the current field.
Example
*******

.. code-block:: omnis
	:linenos:	;  Copy one field to another then clear the first fieldCopy to clipboard iNamePaste from clipboard iDeliveryName (Redraw field)Clear data iName (Redraw field)
