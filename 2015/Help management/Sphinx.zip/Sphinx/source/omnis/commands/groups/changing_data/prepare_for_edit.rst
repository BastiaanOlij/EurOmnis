﻿Prepare for edit
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Prepare for edit**
Description
***********
This command prepares Omnis for editing data. It brings records into memory ready forupdating and rereads the current records when in multi-user mode in case another user hasmade a change to a record since it was read in. Your method can then alter the values ofthe records. The contents of the current record buffer are not written back to disk until *`Update files <update_files.html>`_
* is encountered.

If there is a window open and you require data to be entered via that window, *`Enter data <../../../commands/groups/enter_data/enter_data.html>`_
* is requiredafter the *`Prepare for edit 
`_
*.

Prepare for edit/insert mode is cleared only by a *`Cancel prepare for update <cancel_prepare_for_update.html>`_
, Update files *or *`Quit all methods <../../../commands/groups/methods/quit_all_methods.html>`_
*** **command.You can build lists, print reports and change the main file in the middle of an updatewithout canceling the Prepare for...* *mode.

**Multi-user considerations**

Records in the current record buffer from Read/write files will be locked when *`Prepare for edit 
`_
 *is executed, so as to preventsimultaneous editing of a record. The lock is removed by *`Updatefiles <update_files.html>`_
* or any command which cancels the Prepare for mode.

If *`Wait for semaphores <wait_for_semaphores.html>`_
* is active, a *`Prepare for edit 
`_
* will wait for a record to becomeavailable if another workstation has locked it. If the user pressesCtrl-Break/Ctrl-C/Cmnd-period while waiting for access, the command fails and processinghalts. With *`Do not wait for semaphores <do_not_wait_for_semaphores.html>`_
*active, a record lock returns control to the method with the flag false.

In the following method, the Edit mode is used to process the whole of a file. *`Enter data <../../../commands/groups/enter_data/enter_data.html>`_
* is not usedas no user intervention is required. *`Update files <update_files.html>`_
*writes data to the disk and clears the Prepare for.. mode and record locks.
Example
*******

.. code-block:: omnis
	:linenos:	;  The following example is equivalent to the 'edit record' on the commands menu which can be;  installed using 'Install menu *Commands'Prepare for editEnter data If flag true    Update filesElse    Clear main &amp; connected    Redraw {wMyWindow}End If;  In the following method, the Edit mode is used to process the whole of a file. Enter data;  is not used as no user intervention is required.  Update files writes data to the disk and;  clears the Prepare for.. mode and record locks.;  In ‚ÄòWait for semaphores‚Äô mode:Set main file {fAccounts}Find first on fAccounts.CodeWhile flag true    Prepare for edit    Calculate fAccounts.Balance as fAccounts.Balance-10    Update files    Next End While;  In ‚ÄòDo not wait for semaphores‚Äô mode:Set main file {fAccounts}Find first on fAccounts.CodeWhile flag true    Repeat        Prepare for edit    Until flag true    Calculate fAccounts.Balance as fAccounts.Balance-10    Repeat        Update files    Until flag true    Next End While;  In the next Edit example, the Enter data command is included in the method so that the user;  can edit the record from the keyboard.  Again, the command Update files cancels the Prepare;  for update mode and writes data to the disk.Prepare for editEnter data Update files if flag set;  The next example has been written to control record locking by preventing Omnis from waiting;  for a record lock.  It takes the form of general purpose 'prepare for edit' which you can;  call with a number which tells it how many times to try for a lock if the record is locked by;  another user.;  general Prepare for edit;  declare Parameter lTries (Number Long Integer)Do not wait for semaphoresCalculate lCount as 1Repeat    Prepare for edit    Calculate lCount as lCount+1Until #F|(lCount&gt;lTries);  Keeps trying until flag true OR counter&gt;TRIESWait for semaphores
