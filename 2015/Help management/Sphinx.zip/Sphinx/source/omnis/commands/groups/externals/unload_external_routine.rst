﻿Unload external routine
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Externals <../externals.html>`_  |YES |NO |NO |All |

Syntax
******
**Unload external routine** *routine-name* or *library-name*/*routine-name* (*parameters*)
Description
***********
This command unloads the specified external code from memory. If it is not alreadyloaded or is not found, the flag is cleared and no action takes place. If no external isspecified, all externals are unloaded. All loaded external routines are unloaded when thelibrary is closed or when the program quits. See *`Loadexternal routine <load_external_routine.html>`_
* for more information on external routines.
Example
*******

.. code-block:: omnis
	:linenos:	Unload external routine MathsLib/sqroot
