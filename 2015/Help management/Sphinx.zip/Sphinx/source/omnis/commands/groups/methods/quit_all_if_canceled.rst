﻿Quit all if canceled
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |NO |All |

Syntax
******
**Quit all if canceled**
Description
***********
This command quits all methods that are running when the user clicks on a Cancel buttoninside a working message dialog box. The keyboard equivalent to the Cancel pushbutton isthe Escape key under Windows and Linux, or Cmnd-period under MacOSX. Note that the test forcancel is carried out in *`Working message <../../../commands/groups/message_boxes/working_message.html>`_
*only if *`Disablecancel test at loops <../../../commands/groups/constructs/disable_cancel_test_at_loops.html>`_
* has first been executed.
Example
*******

.. code-block:: omnis
	:linenos:	;  Quit the current and all other methods currently running;  if the cancel button is pressed on the working messageBegin reversible block    Disable cancel test at loopsEnd reversible blockRepeat    Working message  (Cancel button,Repeat count)    Quit all if canceled    Calculate iMyVar as iMyVar+1Until iMyVar=500000
