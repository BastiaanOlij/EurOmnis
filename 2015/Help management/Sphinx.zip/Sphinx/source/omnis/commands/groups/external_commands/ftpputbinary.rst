﻿FTPPutBinary
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPPutBinary** (*socket*,*binfield*,*remotefile*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPPutBinary** uploads the contents of an Omnis binary variable to aremote file on the FTP server. The data is transferred using binary transfer mode.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
BinField* is an Omnis Binary or Character field containing the data to transfer.
*
RemoteFile* is an Omnis Character field containing the pathname of the destinationfile on the FTP server.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  upload a binary file to a FTP server;  set file transfer mode to binaryFTPType (iFTPSocket,1) Returns lErrCodeIf not(lErrCode)    ;  select the binary file to upload    Do FileOps.$getfilename(lDirName,'Select the binary file to upload','*.*',sys(115))    Do lFileOps.$openfile(lDirName)    ;  read contents into an Omnis binary variable    Do lFileOps.$readfile(lBinField)    Calculate lRemoteFile as '/Test/upload/myUploadedFile'    FTPPutBinary (iFTPSocket,lBinField,lRemoteFile) Returns lErrCode    If lErrCode        FTPGetLastStatus (iServerReplyText) Returns lErrCode        OK message FTP Error {[con(&quot;Error uploading binary&quot;,upp(lDirName),&quot; to &quot;,upp(lRemoteFile),kCr,&quot;Details follow: &quot;,kCr,iServerReplyText)]}    End IfEnd If
