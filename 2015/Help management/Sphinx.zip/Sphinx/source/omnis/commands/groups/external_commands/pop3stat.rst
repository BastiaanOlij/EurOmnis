﻿POP3Stat
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3Stat** (*server*,*user*,*pass*[,*stsproc*,*secure* {Default zero insecure;1 secure;2 use STARTTLS},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *waiting-messages*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3Stat** retrieves the number of Internet e-mail messages waitingfor a particular user on a specified POP3 server. If an error occurs, the command returnsa value less than zero to *WaitingMessages*. The socket opened to the POP3 server isalways closed before the command returns. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
*
Server* is an Omnis Character field containing the IP address or hostname of a POP3server that will serve e-mail to the client running Omnis. For example: pop3.mydomain.comor 255.255.255.254. If the server is not using the default POP3 port (110, or 995 for a secure connection), you can optionally append the port number on which the server is listening, using the syntax server:port, for example pop3.mydomain.com:1234.
*
User* is an Omnis Character field containing the account that receives the mail onthe designated server (usually an account user name, for example, Webmaster).
*
Pass* is an Omnis character field containing the password for the account specifiedin the *User* parameter, for example, Secret.
*
StsProc* is an optional parameter containing the name of an Omnis method that *POP3Stat*calls with status messages. *POP3Stat* calls the method with no parameters, and thestatus information in the variable #S1. The status information logs protocol messagesexchanged on the connection to the server.

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

**POP3Stat** also supports an alternative secure option, If you pass secure with the value 2, the connection is initially not secure, but after the initial exchange with the server, **POP3Stat** issues the STLS POP3 command to make the connection secure if the server supports it (see RFC 2595 for details). Authentication occurs after a successful STLS command.

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.
*
WaitingMessages* is an Omnis Long Integer field which receives an error status, orthe number of e-mail messages waiting to be collected on the specified server for thespecified account.
Example
*******

.. code-block:: omnis
	:linenos:	;  Check to see if there is any e-mail waiting to be received for lUserNameCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Stat (lServer,lUserName,lPassword) Returns lWaitingMessagesIf lWaitingMessages&gt;0    ;  receive mailEnd If
