﻿Floating default data file
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |NO |YES |NO |All |

Syntax
******
**Floating default data file** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command sets the default data file as the current data file and changes wheneverthe current data file changes. You use **Floating default data file** inlibraries which open more than one data file at once. The default behavior in Omnis isthat, as each new data file is opened, it becomes the &quot;current&quot; data file. Theconcept of a current data file is important when your commands refer to file classeswithout specifying a data file. 

The **Floating default data file** command sets the default data file, forthe specified list of files, to be equal to the current data file and allows it to change(float) whenever the current data file changes.

The command does not change the flag but is reversible, that is, the previous defaultdata files are restored when the method containing the command in a reversible blockterminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  To specify the data file, you can use Set Default Data File to associate a file class with the;  current data file.  In this example we associate fCustomers with Data.df1Set current data file {Data1}Set default data file {fCustomers};  References to fCustomers are now equivalent to references to Data1.fCustomers.;  The association between fCustomers and Data1 remains in effect even if the current data file;  is set to a different data file.  To return to the default state where the default data file &quot;floats&quot;;  to whatever the current data file is, you can use:Floating default data file {fCustomers}
