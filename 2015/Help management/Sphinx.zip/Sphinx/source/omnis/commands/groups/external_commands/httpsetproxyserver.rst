﻿HTTPSetProxyServer
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPSetProxyServer** ([*hostname*,*service*|*port*,*secure* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**HTTPSetProxyServer** sets the server to which the HTTPGet, HTTPPage and HTTPPost commands connect; the proxy serverthen requests the URI from the original server (either directly, or via another proxy server).  Before **HTTPSetProxyServer** has been called, the commands connect directly to the server for the URI.  After setting a proxy server, you can revert to direct connections, by calling **HTTPSetProxyServer** with empty parameters.

**Note: **There is only a single proxy server setting for the Omnis environment, meaning that it is shared by all threads in the multi-threaded server.

*Hostname* is a Character field containing the hostname or IP address of the HTTP proxyserver. For example:

www.myhost.com or 255.255.255.254

*Service|Port *is an optional parameter that specifies the service name or portnumber of the proxy server. If you specify a service name, the lookup for the port number occurslocally. If you omit this argument, it defaults to 80 or 443, the default port for HTTP or HTTPS respectively(depending on the value of *Secure*).

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.

The command returns an integer *status*, which is less than zero if an erroroccurs. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  All requests to HTTPGet, HTTPPost and HTTPPage connect to this proxy serverCalculate lHostName as &quot;my.proxy.com&quot;Calculate lPort as &quot;8080&quot;HTTPSetProxyServer (lHostName,lPort) ;  Clear the proxy server settings, so HTTPGet, HTTPPost and HTTPPage connect directly to the server for the requested URIHTTPSetProxyServer  
