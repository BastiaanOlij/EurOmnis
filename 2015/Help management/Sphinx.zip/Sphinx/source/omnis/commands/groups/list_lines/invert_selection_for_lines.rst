﻿Invert selection for line(s)
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Invert selection for line(s)** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command inverts the selection state of a line, that is, from selected todeselected or vice-versa. You can specify a particular line in the list by entering eithera number or a calculation. You can show the selection state on the window by invoking the *`Redraw lists <../../../commands/groups/fields/redraw_lists.html>`_
 (Selection only)*command.

The **All lines** option inverts the selection states of all lines of the currentlist. If no line number is given, the current line selection is inverted. When a list issaved in the data file, the selection state of each line is stored. The following exampleselects all but the middle line of the list:
Example
*******

.. code-block:: omnis
	:linenos:	;  Select list lines 2 and 4 and then invert the selection;  so list lines 1,3 and 5 are selectedSet current list lMyListDefine list {lName,lAge}Add line to list {('Fred',10)}Add line to list {('George',20)}Add line to list {('Harry',22)}Add line to list {('William',31)}Add line to list {('David',62)}Select list line(s) {2}Select list line(s) {4}Invert selection for line(s) (All lines)
