﻿Break to end of switch
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Break to end of switch**
Description
***********
This command causes Omnis to jump out of the current *`Case <case.html>`_
*statement (i.e. terminate the Case before the end of Case is reached), and resume methodexecution after the *`End Switch <end_switch.html>`_
* command. You use it inconjunction with the *`Switch <switch.html>`_
* and *`Case <case.html>`_
*commands.
Example
*******

.. code-block:: omnis
	:linenos:	;  If lCount equals 1 or 2 the ok message following the Break to end of switch never gets shownSwitch lCount    Case 1        OK message  {lCount equals 1}        Break to end of switch        OK message  {I never run}    Case 2        OK message  {lCount equals 2}        Break to end of switch        OK message  {I never run}    Default        OK message  {lCount not equal to 1 or 2}End Switch
