﻿Write file as character
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Write file as character** (*refnum*, *character*-*variable* [,*start*-*position*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command writes the contents of the specified *character-variable* to a file.You specify the file reference number returned by *`Open file <open_file.html>`_
*in *refnum*.

If you specify the *start-position*, writing begins at that absolute characterposition (0 is the first character in the file, 1 is the second character, and so on),otherwise it begins at the current position (the first character when the file is firstopened).

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  write the contents of the character variable 'lCharVar' to a text file;  named 'charfile.txt' in the root of the omnis treeCalculate lPathname as con(sys(115),'charfile.txt')Create file (lPathname) Returns lErrCodeOpen file (lPathname,lRefNum) Calculate lCharVar as 'The contents of this file was written using the command Write file as character'Write file as character (lRefNum,lCharVar) Returns lErrCodeClose file (lRefNum) 
