﻿Accept field values
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Accept field values** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command determines whether Omnis is able to receivedata from a client via a DDE POKE message. With the **Accept** option selected, Omniswill respond to a Poke message specifying a valid field or variable name, by setting thevalue of that field to the value transmitted by the client program. Values are stored inthe current record buffer and, if the relevant field is on the top window, that window isredrawn.

Field values are only accepted when Omnis is in enter data mode, Prompted find, or whenno methods are running. All conversations are terminated when you close your Omnislibrary.
Example
*******

.. code-block:: omnis
	:linenos:	Accept advise requests (Accept)Accept field values (Accept)
