﻿WebDevSetConfig
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**WebDevSetConfig** ([*errorproc*,*commstimeout*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***WebDevSetConfig** allows you to set some configuration options forthe WEB commands. The WEB commands are the commands with names prefixed by CGI, FTP, HTTP,POP3, TCP, and UU, and the MailSplit and SMTPSend commands.
*
ErrorProc* is the WebDevError** **method. WebDevError is an Omnis method whichALL of the other WEB commands call when an error occurs. WEB command execution is asfollows: <ul>  <li>Attempt to execute command</li>  <li>If no error occurs, return successful status.</li>  <li>If an error occurs, and there is no WebDevError method, return the error code.</li>  <li>If an error occurs, and there is a WebDevError method, call the WebDevError method, and    then return the error code.</li></ul>*
ErrorProc *is an Omnis Character field containing the name of the WebDevErrormethod, for example MYLIBRARY.MYCODE/MYPROC.

When a WEB command calls the WebDevError method, it passes it three parameters: <ol>  <li>A character parameter containing an error message.</li>  <li>A long integer containing the error code.</li>  <li>A character parameter containing the WEB command name.</li></ol>
To clear the WebDevError method, either pass no parameters, or an empty firstparameter, to **WebDevSetConfig**.

You can also optionally pass *CommsTimeout* to this command. *CommsTimeout *isa long integer, which specifies the number of seconds that WEB commands will wait to connect, or wait to receive data, before deciding that the remote application is not going to respond. **Note:**this time-out does not apply to TCPReceive. **WebDevSetConfig** multipliesthis value by 60, to generate a value in 1/60<sup>th</sup> second ticks, and stores theresulting unsigned long integer. If you pass zero, this willset the time-out to the default value of 60 seconds. If you do not pass a *CommsTimeout *parameter,the time-out remains unchanged. A negative value will also cause the command toignore server Blocking errors; in this case, the timeout will be the negated value of the parameter.

The **WebDevSetConfig** command returns a long integer *Status. *Zerofor success, or less than zero if an error occurs. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  call method $error in the current window instance a web error occurs;  $constructWebDevSetConfig (con($cinst().$name,'.$error')) ;  $error methodOK message Error executing [pCommand] {[pErrorCode] : [pErrorMsg]};  $event of push button - force error so $error gets calledFTPConnect ('ftp.unknownserver.net','Username','Password') Returns lFTPSocket
