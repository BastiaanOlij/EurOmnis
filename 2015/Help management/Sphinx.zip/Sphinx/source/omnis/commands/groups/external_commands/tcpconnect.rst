﻿TCPConnect
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPConnect** (*hostname*,*service*|*port*[,*secure* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPConnect** establishes a TCP/IP connection to a remoteapplication, and returns a new socket representing that connection.
*
Hostname* is an Omnis Character field containing the hostname or IP address of thesystem on which the remote application is running.
*
Service/Port* is either an Omnis integer field containing the number of the port onwhich the remote application is listening for new connections, or an Omnis character fieldcontaining the name of a service which will be resolved to a port number by a locallookup.
*
Socket* is an Omnis Long Integer field that receives either the number of the newsocket, or an error code &lt; 0. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.

**Notes:**

This differs from the more standard implementation of the sockets connectcall. Instead of creating a socket with one command (such as *`TCPSocket <tcpsocket.html>`_
*),then passing the socket to a connect command, **TCPConnect** creates thesocket and returns the socket number in one step.

When using a secure connection all calls to *`TCPSend <tcpsend.html>`_
* are blocking.
Example
*******

.. code-block:: omnis
	:linenos:	;  Connect to the server IP address iHostName on port iPort ready for;  sending a messageCalculate iHostName as '0.0.0.0'Calculate iPort as 6000TCPConnect (iHostName,iPort) Returns iSocketIf iSocket&gt;0    ;  connectedEnd If
