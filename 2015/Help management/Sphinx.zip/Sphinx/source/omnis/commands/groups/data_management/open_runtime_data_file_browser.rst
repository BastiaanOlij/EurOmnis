﻿Open runtime data file browser
##############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |NO |NO |NO |All |

Syntax
******
**Open runtime data file browser**
Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Open data file {Salaries.df1}Set current data file {Salaries}Open runtime data file browser
