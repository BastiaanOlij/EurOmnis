﻿Prompt for library
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Libraries <../libraries.html>`_  |YES |NO |NO |All |

Syntax
******
**Prompt for library** ([*Do not close others*][,*Enable conversion by runtime*][,*Do not open startup task*][,*Convert without user prompts*]) {*internal-name* (*startup-parameters*)}

Options
*******|Do not close others |If specified,the command does not close all open libraries before opening the specified library |
|Enable conversion by runtime |The development version of Omnis offers to convert libraries created by an earlier version of Omnis. If this option is specified,the runtime version of Omnis will also offer to convert such libraries |
|Do not open startup task |If specified,the command does not construct an instance of the startup task when it opens the library |
|Convert without user prompts |If specified,and conversion is allowed, Omnis will immediately perform the conversion without giving the user any prompts that require a response; also, the user cannot cancel the conversion |

Description
***********
This command prompts the user for a library file. You can specify the internal name andstartup task construct parameters of the library to be opened, together with the **Donot close others**, **Do not open startup task**, and **Enable conversion byruntime** options.

If the internal name of an opened library is specified, a check is made to ensure theinternal name is unique among the open libraries; a runtime error occurs if this is notthe case. If no internal name is specified, the default internal name is the disk name ofthe file with the path name and suffix removed. For example, the internal name for'hd:myfiles:testlib.lbs' is 'testlib'.

If an attempt is made to open a library which is already open, that library is closedand reopened. Refer to *`Close Library <close_library.html>`_
* for theconsequences of closing a library. If the user cancels the Select Library dialog, the flagis cleared and no libraries are closed.
**
Do not close others
**
The **Do not close others** option lets you keep open all other libraries. If the **Donot close others** option is not selected, then all other open libraries are closedwhen the user opens a new library, including the one containing the currently executingmethod.

**Passwords**

If the library does not need a master password, it is opened at the master level,otherwise the usual prompt for password dialog is opened. The library is closed and a flagfalse returned if this dialog is closed without a password being entered.
**
**Startup task**
**
If the **Do not open startup task** option is specified, the startup taskconstruct for the opened library is not called and there is no startup task instance.Otherwise, the startup task $construct() method is called and the parameters for it arepassed.
**
Enable conversion by runtime
**
If you select the **Enable conversion by runtime**** **option, and the librarywas created with a previous version of Omnis, then the runtime version of Omnis canconvert the library if the user allows. The default is that an Omnis runtime will not askthe user if they want to convert the library.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a library path and open the selected;  libraryPrompt for library (Do not close others)If flag true    OK message  {Library Opened!}End If
