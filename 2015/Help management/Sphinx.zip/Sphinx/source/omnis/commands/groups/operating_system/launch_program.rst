﻿Launch program
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |All |

Syntax
******
**Launch program ***program-name* or *program-name*,*document-name*** Returns ***return-value***** ([*Do not quit Omnis*])

Options
*******|Do not quit Omnis |This option is ignored on platforms other than MacOSX. When running on MacOSX,specify this option to prevent Omnis from closing after launching the program |

Description
***********
This command launches the specified program.

On Windows and Linux, this command behaves just like the command *`Start program normal <start_program_normal.html>`_
*, except that you canalso wait for the output from the program (see below). The**Do not quit Omnis** option is ignored.

On Windows and Linux,you can run a command line program, and receive the output from the program via the Returns clauseof the command. If a variable is specified in the Returns clause, Omnis Studio waits for the executable to terminate before continuing,and returns the output from the command in the variable.

On Windows,you can omit the *program name*, and supply just the *document name* prefixed by a comma. This will open the documentin the application associated with its file extension.

The rest of this command description applies only to the Macintosh. If you include afile name, the application is launched with the file name as a document. If the specifiedfile name represents a document which the program cannot understand, it will be ignored.You must specify pathnames for the program and document, as shown in the example below.

You can reference either the application (with the.app suffix) or the executable in the bundle. For example, to launch iTunes you can specify either :

OSX:Applications:iTunes.app
or
OSX:Applications:iTunes.app:Contents:MacOS:iTunes

replacing OSX with the name of your volume.

The default action is to quit Omnis, but the **Do not quit Omnis** option lets youkeep Omnis open. If you choose this option, Omnis will continue to run in the background,concurrently with the new program. A new program launched by Omnis will always be openedon top, even if Omnis is already in the background. The flag is set false if an error isdetected, for example, if a program or file name cannot be found. When you execute **Launchprogram**, control passes from your application to the operating system and thereis no automatic way of returning to Omnis.
Example
*******

.. code-block:: omnis
	:linenos:	;  Launch the specified programLaunch program c:\program files\windows nt\accessories\wordpad.exeIf flag false    OK message  (Icon,Sound bell) {Couldn't find wordpad.exe}End If
