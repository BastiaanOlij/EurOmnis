﻿TCPListen
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPListen** (*socket*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPListen** puts a socket created with *`TCPSocket <tcpsocket.html>`_
*into listening mode. When a socket is in listening mode, it will acknowledge incomingconnection requests addressed to the port bound to the socket, and place them in a queue,ready to be accepted using *`TCPAccept <tcpaccept.html>`_
*.
*
Socket *is an Omnis Long Integer field containing the number of a socket that hasbeen bound to a port.
*
Status* is an Omnis Long Integer field which receives the value zero for success, oran error code &lt; 0 for failure. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Listen for a incoming connections on port iPortCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPListen (iSocket) Returns lStatusIf lStatus=0    Repeat        TCPAccept (iSocket) Returns lConnectedSocket    Until lConnectedSocket&gt;=0    ;  client connectedEnd IfTCPClose (iSocket) Returns lStatus
