﻿Prepare for import from client
##############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |Windows |

Syntax
******
**Prepare for import from client** {*export-format*}

Export Formats
**************|Delimited (commas) | |
|Delimited (tabs) | |
|One field per line | |
|Omnis data transfer | |
|Delimited (user delimiter) | |

Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Prepare for import from client {Delimited (commas)}If flag true    Import data lImportListEnd IfEnd import
