﻿Export data
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |NO |NO |NO |All |

Syntax
******
**Export data** *list-or-row-name*
Description
***********
This command exports data from an Omnis list or row variable.
Example
*******

.. code-block:: omnis
	:linenos:	;  export to a file called myExport.txt in the root of your omnis treeCalculate lExportPath as con(sys(115),'myExport.txt')Set print or export file name {[lExportPath]}Prepare for export to file {Delimited (commas)}Export data lExportListEnd exportClose print or export file
