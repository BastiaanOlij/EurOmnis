﻿Enable receiving of Apple events
################################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |YES |NO |MacOSX |

Syntax
******
**Enable receiving of Apple events**
Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Yes/No message Question {Do you want to accept Apple events?}If flag true    Enable receiving of Apple eventsEnd If
