﻿While flag false
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**While flag false**
Description
***********
This command starts a **While***&#150;`End While <end_while.html>`_
*loop that continues while the flag is false. While the condition is false, a command or aseries of commands is executed until the condition becomes true, at which time the firstcommand after the closing *`End While <end_while.html>`_
* is executed. A loopthat begins with a *While* command must terminate with an *`EndWhile <end_while.html>`_
*, otherwise an error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  loop until 'Yes' is pressedCalculate #F as kFalse     ;; set falg as TrueWhile flag false    No/Yes message  {Do you wish to stop looping}End While
