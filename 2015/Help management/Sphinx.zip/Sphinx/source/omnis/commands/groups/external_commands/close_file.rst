﻿Close file
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Close file** (*refnum*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command closes a file previously opened by the **`Openfile <open_file.html>`_
** command. You specify the file reference number returned by **`Open file <open_file.html>`_
** in *refnum*. You should call **Closefile** for each files you open with **`Open file <open_file.html>`_
**,when you have finished using the file.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), orzero if no error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  read a text file then close itCalculate lPathname as con(sys(115),'html',sys(9),'serverusagetask.htm')Open file (lPathname,lRefNum) Returns lErrCode     ;; opens the fileRead file as character (lRefNum,lFile) Returns lErrCode     ;; reads the file contents into lFileClose file (lRefNum) Returns lErrCode     ;; now close the file
