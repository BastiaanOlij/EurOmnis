﻿TCPAddr2Name
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPAddr2Name** (*address*) **Returns** *hostname*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPAddr2Name** is a domain name service command to resolve thehostname for a given IP address.
*
Address *is an Omnis Character field containing the IP address to convert to ahostname. The IP address is of the form 255.255.255.254
*
Hostname* is an Omnis Character field which receives a hostname which maps to the IPaddress. The hostname is of the form machine[.*domainame.dom*]
**
Note: **This command fails if the address of a Domain Name Server has not beendefined for your computer. Not all host IP Addresses may be known to the Domain NameServer. If the Domain Name Server is busy or unavailable, the command times out andreturns an error. Defining often -used servers in a local host&#146;s file or using acaching Domain Name Server increases performance of this command.
Example
*******

.. code-block:: omnis
	:linenos:	;  Return the Hostname for pIPAddressTCPAddr2Name (pIPAddress) Returns lHostNameQuit method lHostName
