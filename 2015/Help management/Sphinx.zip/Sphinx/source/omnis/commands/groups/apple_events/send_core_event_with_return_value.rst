﻿Send Core event with return value
#################################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |NO |NO |MacOSX |

Syntax
******
**Send core event ***message* (*parameters*)** Returns ***return-value*****

Messages
********|Get Data | |
|Do Script | |

Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Send core event Get Data Returns lStatus;  Get Data sends an event to the current recipient and returns data to the specified field or variable.;  The flag is set if the event is acceptedSend core event Get Data ('Container1') Returns lStatus;  Container1 is the data container in target libIf lStatus    OK message  {It does!}Else    OK message  {Sorry, not today!}End If;  Do Script lets you execute a script in a remote application (eg a macro in a spreadsheet) and;  return a value to Omnis.Use event recipient {Hypercard}     ;; previously prompted for and taggedSend core event Do Script (iScript) Returns lStatus;  The result of the Hypercard answer script (iScript) is a value Yes/No which is returned to the Omnis;  library in the local field lStatus;  When a script is sent to Omnis, the syntax of the commands is defined by what is shown in the;  method design window.  In freetype entry mode, you can create scripts in Omnis and transfer;  them via the clipboard to your chosen application.;  When sent to another Apple application, such as Hypercard, a script must of course use the;  syntax of that application.
