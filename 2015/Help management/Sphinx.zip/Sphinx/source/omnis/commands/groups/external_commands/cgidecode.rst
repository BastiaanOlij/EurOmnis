﻿CGIDecode
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**CGIDecode** (*stream*[,*mapplustospace* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *decoded-stream*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

You use **CGIDecode** to turn CGI-encoded text back into its originalform. It is the inverse of **`CGIEncode <cgiencode.html>`_
**.

When a client uses HTTP to invoke a script on a WEB server, it uses the CGI encodedformat to pass the arguments to the server. This avoids any ambiguity between thecharacters in the argument names and values, and the characters used to delimit URLs, andthe argument names and values.
*
stream* is an Omnis Character or Binary field containing the information to decode.
*
MapPlusToSpace* is a Boolean value. When `kTrue <../../../notation/root/constants/boolean_values.html>`_
, in addition to performing a standardCGI decode operation, the command maps all instances of the &#145;+&#146; character in theinput stream, to the space character.
*
DecodedStream *is an Omnis Character or Binary field that receives the resultingCGI-decoded representation of the *stream* argument.
**
Note: **The **`HTTPHeader <httpheader.html>`_
**, **`HTTPParse <httpparse.html>`_
** and **`HTTPPost <httppost.html>`_
**commands automatically perform CGI encoding or decoding, as appropriate.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lStream as 'Name: Charlie Malone,Company: TigerLogic'CGIEncode (lStream) Returns lEncodedStreamCGIDecode (lEncodedStream) Returns lDecodedStream;  lDecodedStream now contains the following:;  Name: Charlie Malone,Company: TigerLogicCalculate lStream as 'Name: Charlie Malone+Friend,Company: TigerLogic'CGIEncode (lStream) Returns lEncodedStreamCGIDecode (lEncodedStream,kFalse) Returns lDecodedStream;  lDecodedStream now contains the following:;  Name: Charlie Malone+Friend,Company: TigerLogicCGIDecode (lEncodedStream) Returns lDecodedStream;  lDecodedStream now contains the following:;  Name: Charlie Malone Friend,Company: TigerLogic;  Note the + has been turned into a space character
