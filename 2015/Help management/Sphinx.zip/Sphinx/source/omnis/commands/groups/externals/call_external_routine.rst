﻿Call external routine
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Externals <../externals.html>`_  |NO |NO |NO |All |

Syntax
******
**Call external routine ***routine-name* or *library-name*/*routine-name* (*parameters*)** Returns ***return-value*****
Description
***********
This command calls an external routine with mode ext_call and returns a value from theexternal in the specified *return-field*. The return value is placed in the specifiedfield by the external code using the predefined field reference Ref_returnval with thefunctions SetFldVal or SetFldNval. The flag is set if the external routine is found andthe call is made but this does not necessarily mean that the external code has executedcorrectly. The flag is cleared if the routine is not found. Note that the routine cannotuse the flag to pass information back to the method.

You can pass parameters to the external code by enclosing a comma-separated list offields and calculations. If you pass a field name, for example, **Call externalroutine*** Maths1 (Num1,Num2), *the external can directly alter the fieldvalue. Enclosing the field in brackets, for example, **Call external routine***Maths1 ((Num1),(Num2)),* converts the field to a value and protects the field fromalteration.

In the routine itself, the parameters are read using the usual GetFldVal or GetFldNvalwith the predefined references Ref_parm1, Ref_parm2, and so on, Ref_parmcnt gives thenumber of parameters passed. If the field name is passed as a parameter, you can useSetFldVal or SetFldNval with Ref_parm1, and so on, to change the field's value.
Example
*******

.. code-block:: omnis
	:linenos:	Call external routine MathsLib/sqroot (iNumber) Returns iNumber2
