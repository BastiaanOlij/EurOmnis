﻿Set main file
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |NO |YES |NO |All |

Syntax
******
**Set main file** {*file-name*}
Description
***********
This command selects the &quot;main file&quot; class. **Set main file** isan essential command which you must execute before manipulating any data. You can insertor delete data *only* in the file designated as the main file. The designated filecannot be memory-only or closed.

The main file setting also determines which connected files are located when findingrecords with Find/Next/Previous, and which connections are updated. As each main filerecord is read, the connected records are automatically read in and made available forediting. When the main file is edited or inserted, all connections to its parent files areupdated, unless the parent file is closed.

If Omnis attempts to execute a command which requires a main file before the main fileis set, an error occurs. If the data file is not opened when the main file is set, Omniswill try to open the default data file and, if this is unsuccessful, will display theChange data file dialog box so that the user can select or create a data file.

Changing the main file after a *Prepare for*... command does not cancel Preparefor mode. When an update is encountered, the main file set at the time of the last Preparefor is used. (See *`Preparefor edit <../../../commands/groups/changing_data/prepare_for_edit.html>`_
, `Preparefor insert <../../../commands/groups/changing_data/prepare_for_insert.html>`_
*.)

If you use **Set main file** in a reversible block, the main file is resetto its previous value when the method containing the reversible block finishes.

**Multiple open data files**

If more than one data file is open, there is only one main file setting shared by allopen data files. If you do not qualify a file class name with a data file, the currentdata file is assumed unless you have created an association between the file class andanother data file using the *`Set default data file <../../../commands/groups/data_files/set_default_datafile.html>`_
*command.
Example
*******

.. code-block:: omnis
	:linenos:	;  Set the main file in a reversible block so it returns to;  it's former setting once this method terminatesBegin reversible block    Set main file {fAccounts}End reversible blockPrepare for insertCalculate fAccounts.Code as 'AC01'Calculate fAccounts.Surname as 'Smith'Calculate fAccounts.Balance as 100Update files
