﻿Enclose exported text in quotes
###############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |NO |NO |NO |All |

Syntax
******
**Enclose exported text in quotes** ([*Enable*])

Options
*******|Enable |If specified,all text exported in tab,comma and user delimited format,is enclosed in quotes;executing the command without this option specified will cause text to be exported without quotes |

Description
***********Example
*******

.. code-block:: omnis
	:linenos:	Set report name rMyReportSend to filePrompt for print or export fileEnclose exported text in quotes (Enable)Print report;  or disable the option with the notationDo $clib.$prefs.$exportedquotes.$assign(kFalse)
