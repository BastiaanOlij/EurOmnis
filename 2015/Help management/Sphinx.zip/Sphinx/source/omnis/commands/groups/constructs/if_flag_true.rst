﻿If flag true
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**If flag true**
Description
***********
This command lets you implement a branch or change of processing order within a methoddepending on the result of the previous command. It tests the flag and if it is true, thecommands following the **If flag true** are executed. However, if the flag isfalse, control branches to the next *`Else <else.html>`_
*, *`Else If <else_if_calculation.html>`_
* or *`End If <end_if.html>`_
*in the method.
Example
*******

.. code-block:: omnis
	:linenos:	;  Test if list line selected sets the flag to true if the line is selectedSet current list iMyListTest if list line selected {2}If flag true    ;  If the list line is selected, processing continues here.    OK message  {The list line is selected}End If
