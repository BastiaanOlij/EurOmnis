﻿Quick check
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Quick check** ([*Perform repairs*])

Options
*******|Perform repairs |If selected,repairs to the data file are automatically carried out |

Description
***********
This command performs a quick check on the current data file. It examines the status ofthe current data file by reading only the internal tables in which records of anyinconsistencies are stored. These records indicate corruption caused by either hardware orsoftware failure. No attempt is made to systematically check the entire data file forproblems (you use the *`Check data <check_data.html>`_
* command for thispurpose).

The command is not reversible: it sets the flag if it completes successfully and clearsit otherwise.

If the **Perform repairs** option is specified, any repairs required areautomatically carried out, otherwise the results of the check are added to the check datalog. The check data log is not opened by this command but is updated if it is alreadyopen. If the **Perform repairs** option is specified, the following applies:

If you are not running in single user mode, Omnis automatically tests that only oneuser is logged onto the data file (the command fails with flag false if not), and furtherusers are prevented from logging onto the data until the command completes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute andit is not possible to cancel execution even if a working message with cancel box is open.
Example
*******

.. code-block:: omnis
	:linenos:	Quick checkYes/No message  {View the Quick Check log?}If flag true    Open check data logEnd If
