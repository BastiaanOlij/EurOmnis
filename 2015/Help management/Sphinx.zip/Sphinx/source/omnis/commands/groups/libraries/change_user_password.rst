﻿Change user password
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Libraries <../libraries.html>`_  |NO |NO |NO |All |

Syntax
******
**Change user password**
Description
***********
This command opens the Password dialog in which the user can change the currentpassword. The menus are redrawn and lists and variable values (apart from #UL) areunaffected.

If the current user is the master user, passwords in the #PASSWORDS class can bechanged. In addition, the command gives the user the choice of using another password tore-enter the current library at a different user level, thus gaining access to differentareas of the library. If a user re-enters at a different level, the value of  #ULwill change (within the range 0&#150;8) to reflect that new user level.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a password as specified in #PASSWORDS;  and display the current user levelChange user passwordOK message  {The current user level is [#UL]}
