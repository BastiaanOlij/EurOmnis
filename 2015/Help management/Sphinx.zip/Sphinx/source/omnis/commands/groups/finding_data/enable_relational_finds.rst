﻿Enable relational finds
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |NO |YES |NO |All |

Syntax
******
**Enable relational finds** ([*Use connections*]) {*list-of-files* (F1,F2,..,Fn)}

Options
*******|Use connections |If specified,all connections between the joined files are made when building the table |

Description
***********
This command causes all find tables to be built relationally, ignoring the main file.The file list is a list of files to be joined and, if **Use connections** is checked,all connections between the joined files are made when building the table. In effect, theconnections provide the relational joins, that is, &quot;sequence number = sequencenumber&quot;. 

When relational finds are enabled, the index field specified for find and build listcommands is ignored. It is necessary to use a sort to determine the order of the table.

The *`Disable relational finds <disable_relational_finds.html>`_
* commandcauses a reversion to the default situation where the main file and its connected parentfiles are joined using the connections. The **Enable relational finds** and *`Disable relational finds <disable_relational_finds.html>`_
* commands are bothreversible and do not affect the flag.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list lMyListDefine list {fChild,fParent,fGrandParent};  Build a relational child/parent/grandparent list using omnis connectionsEnable relational finds (Use connections) {fChild,fParent,fGrandparent}Build list from file ;  Build a relational list of records ignoring omnis connections from fParent;  and fChild of parents with children less than 4 years oldSet search as calculation {fParent.ID=fChild.Parent_ID&amp;fChild.Age&lt;4}Enable relational finds {fParent,fChild}Build list from file  (Use search)
