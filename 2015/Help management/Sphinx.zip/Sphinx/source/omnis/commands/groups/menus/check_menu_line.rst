﻿Check menu line
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Check menu line** *line* or *instance-name*/*line*
Description
***********
This command places a check mark on the specified line of a menu instance to show thatthe option has been selected. You specify the menu instance name and the number of themenu line you want to check.

You can remove the check mark with `Uncheck menu line <uncheck_menu_line.html>`_
.If you use this command in a reversible block, the check mark is removed when the methodterminates. Nothing happens if the menu instance is not installed on the menu bar.
Example
*******

.. code-block:: omnis
	:linenos:	;  Test whether a line in the menu instance is checked and;  either check or uncheck it accordingly.Install menu mViewTest for menu line checked mView/LargeIf flag true    Uncheck menu line mView/LargeElse    Check menu line mView/LargeEnd If;  Alternatively, you change the $checked property of a line;  in the menu instance using notationDo $imenus.mView.$objs.Large.$checked.$assign(kTrue)
