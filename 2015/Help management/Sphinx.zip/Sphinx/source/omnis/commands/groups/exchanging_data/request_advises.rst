﻿Request advises
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |YES |NO |Windows |

Syntax
******
**Request advises** *field-name* {*server-data-item-name*}
Description
***********
DDE command, Omnis as client. This command sends a request to the server asking to beadvised of any changes made to a specified data item. An error occurs if the channel isnot open. The command takes the Omnis field name and the server data item name asparameters. The data item name can contain square bracket notation.

Whenever Omnis is advised of a change in field value, that value is changed providingyour library is in enter data mode.

The flag is set if the command is successful.

You can use a control method to detect the arrival of data from the server usingevSent.
Example
*******

.. code-block:: omnis
	:linenos:	Request advises iCompany {iCompany}Request advises iAddress {iAddress}Prepare for insertEnter data Update files if flag set
