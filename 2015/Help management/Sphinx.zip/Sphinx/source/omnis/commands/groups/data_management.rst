﻿Data management
###############
`Command Index <../command_index.html>`_


`Commands
******** <data_management#commands>`_
|`Build indexes <data_management/build_indexes.html>`_  |`Check data <data_management/check_data.html>`_  |`Clear check data log <data_management/clear_check_data_log.html>`_  |`Close check data log <data_management/close_check_data_log.html>`_  |
|`Delete data <data_management/delete_data.html>`_  |`Drop indexes <data_management/drop_indexes.html>`_  |`Open check data log <data_management/open_check_data_log.html>`_  |`Open runtime data file browser <data_management/open_runtime_data_file_browser.html>`_  |
|`Print check data log <data_management/print_check_data_log.html>`_  |`Quick check <data_management/quick_check.html>`_  |`Rename data <data_management/rename_data.html>`_  |`Reorganize data <data_management/reorganize_data.html>`_  |
|`Test check data log <data_management/test_check_data_log.html>`_  |`Update data dictionary <data_management/update_data_dictionary.html>`_  |

