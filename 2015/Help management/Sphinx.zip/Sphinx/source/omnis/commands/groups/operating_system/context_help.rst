﻿Context help
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |All |

Syntax
******
**Context help** {*command* (*parameters*)}
Description
***********
This command provides context help to the user. You specify a command mode option, anddepending on the mode you can specify the help file name and context id. The command modeoptions are constants listed in the Catalog.
**
****kHelpContextMode**
initiates context help mode, showing a &#145;?&#146; cursor.
**
****kHelpContext** ****(&#146;helpfile name&#146;, context id)
opens a general help window for the topic specified.
**
****kHelpContextPopup** (&#146;helpfile name&#146;, context id)
opens a popup help window for the topic specified.
**
****kHelpContents** (&#146;helpfile name&#146;)
opens the help file at the contents page.
**
****kHelpQuit** (&#146;helpfile name&#146;)
closes window mode help.

Some options do not work on all platforms.

To implement context help for an object or area, you set the help id as a decimal valuein the $helpid property of a class or object, including windows, menus, and toolbars. Youcan make your custom help file which must be placed in the Help folder and the nameentered in the library preference property $clib.$prefs.$helpfilename.

When the user clicks on an object with the help cursor or presses the F1/Help key,Omnis looks for the help id. If it finds none for a window object, menu line, or toolbarcontrol, it then looks in the next higher containing object.
Example
*******

.. code-block:: omnis
	:linenos:	;  Show the file index.htm from the omnis help folder;  in the standard help windowContext help {kHelpContext ('omnis','index')};  Show ? cursor and awaits click, when user clicks, shows a popup;  window with topic $cobj.$helpid  from $clib.$prefs.$helpfilename;  located in the Help folderContext help {kHelpContextMode}
