﻿Else If calculation
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Else If ***calculation*****
Description
***********
This command is used after an *`If <if_calculation.html>`_
* command tomark the beginning of some commands that are carried out if the condition in the preceding*`If <if_calculation.html>`_
* command is false, or the calculation in the **ElseIf*** *command is true.
