﻿Clipboard
#########
`Command Index <../command_index.html>`_


`Commands
******** <clipboard#commands>`_
|`Clear data <clipboard/clear_data.html>`_  |`Copy to clipboard <clipboard/copy_to_clipboard.html>`_  |`Cut to clipboard <clipboard/cut_to_clipboard.html>`_  |`Paste from clipboard <clipboard/paste_from_clipboard.html>`_  |
|`Test clipboard <clipboard/test_clipboard.html>`_  |

