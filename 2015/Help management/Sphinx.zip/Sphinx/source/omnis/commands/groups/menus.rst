﻿Menus
#####
`Command Index <../command_index.html>`_


`Commands
******** <menus#commands>`_
|`Build installed menu list <menus/build_installed_menu_list.html>`_  |`Build menu list <menus/build_menu_list.html>`_  |`Check menu line <menus/check_menu_line.html>`_  |`Disable all menus and toolbars <menus/disable_all_menus_and_toolbars.html>`_  |
|`Disable menu line <menus/disable_menu_line.html>`_  |`Enable all menus and toolbars <menus/enable_all_menus_and_toolbars.html>`_  |`Enable menu line <menus/enable_menu_line.html>`_  |`Install menu <menus/install_menu.html>`_  |
|`Popup menu <menus/popup_menu.html>`_  |`Popup menu from list <menus/popup_menu_from_list.html>`_  |`Redraw menus <menus/redraw_menus.html>`_  |`Remove all menus <menus/remove_all_menus.html>`_  |
|`Remove final menu <menus/remove_final_menu.html>`_  |`Remove menu <menus/remove_menu.html>`_  |`Replace standard Edit menu <menus/replace_standard_edit_menu.html>`_  |`Replace standard File menu <menus/replace_standard_file_menu.html>`_  |
|`Standard menu command <menus/standard_menu_command.html>`_  |`Test for menu installed <menus/test_for_menu_installed.html>`_  |`Test for menu line checked <menus/test_for_menu_line_checked.html>`_  |`Test for menu line enabled <menus/test_for_menu_line_enabled.html>`_  |
|`Uncheck menu line <menus/uncheck_menu_line.html>`_  |

