﻿Create directory
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Create directory** (*path*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command creates the directory named in *path*. Thedirectory must not already exist. **Create directory** does not createintermediate directories. It only creates the last directory name in *path*.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), orzero if no error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lDirName as con(sys(115),'MyNewDirectory');  create the new directory in the root of your omnis treeCreate directory (lDirName) Returns lErrCode
