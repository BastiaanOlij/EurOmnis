﻿IMAPConnect
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**IMAPConnect** (*server*,*username*,*password*[,*stsproc*,*responselist*,*secure* {Default zero insecure;1 secure;2 use STARTTLS},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**IMAPConnect** establishes a connection with an IMAP server. The server must support IMAP4rev1.  See RFC 3501 for details.If **IMAPConnect** succeeds, it returns the socket opened to the IMAP server. You can use this socket withthe other IMAP commands which require a socket argument. If an error occurs, **IMAPConnect**returns an error code, which is less than zero. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

Note that it is essential that you call *`IMAPDisconnect <imapdisconnect.html>`_
*when you have finished using the connection to the IMAP server.

*Server* is an Omnis Character field containing the IP address or hostname of an IMAPserver. For example: imap.mydomain.comor 255.255.255.254. If the server is not using the default IMAP port (143, or 993 for a secure connection), you can optionally append the port number on which the server is listening, using the syntax server:port, for example imap.mydomain.com:1234.

*Username* is an Omnis Character field containing the user name that will be used to log in to the IMAP server.  The command usesCRAM-MD5 authentication if possible; if CRAM-MD5 is not supported by the server, or fails to authenticate for some reason, the command uses the plain text LOGIN command if the server allows it.

*Password* is an Omnis character field containing the password for the user specified by the *username* parameter.

*Stsproc* is an optional parameter containing the name of an Omnis method that this commandcalls with status messages. This command calls the method with no parameters,and the status information in the variable #S1. The status information logs protocolmessages exchanged on the connection to the server.

*Responselist* is an optional parameter into which this command places response lines received from the IMAP server.  Before callingthis command, define the *responselist* to have a single Character column.  When the command returns successfully, the response listcontains the untagged and tagged responses received from the IMAP server as a result of executing this command.  These sometimes include unsolicited information, for example, anupdate on the current number of messages in the selected mailbox. Each line in the response list is a response line received from the server.See RFC 3501 for more details, if you need to handle this sort of information.

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

**IMAPConnect** also supports an alternative *secure* option,  If you pass *secure* with the value 2, theconnection is initially not secure, but after the initial exchange with the server, **IMAPConnect** issues a STARTTLSIMAP command to make the connection secure if the server supports it (see RFC 3501 for details).  Authentication occurs after asuccessful STARTTLS command.

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.
Example
*******

.. code-block:: omnis
	:linenos:	;  Establish a connection to the IMAP server lServer for user;  lUsername using the password lPasswordCalculate lServer as 'my.imap.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'IMAPConnect (lServer,lUserName,lPassword) Returns iIMAPSocketIf iIMAPSocket&lt;0    ;  Connection failedEnd If
