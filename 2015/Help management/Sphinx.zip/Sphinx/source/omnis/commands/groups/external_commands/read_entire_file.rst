﻿Read entire file
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Read entire file ** (*path*, *binary*-*variable* [,*'r'*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command reads an entire file into a binary field. If you specify 'r' as the third parameter, it opensthe file in read-only mode.  It returns an error code, or zero if no error occurs. The returned binaryvalue has the following format: <ol>  <li>12 byte header containing the Type (4 bytes), Creator (4 bytes), and file length (4    bytes).</li>  <li>File data.</li></ol>
The Type is always &#145;TEXT&#146;, and the Creator is always&#145;mdos&#146;.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a file and read it's entire contents into the;  binary variable lBinFldDo FileOps.$putfilename(lPathname,'Select a file','') Returns lReturnFlagIf lReturnFlag    Read entire file  (lPathname,lBinfld) Returns lErrCodeEnd If
