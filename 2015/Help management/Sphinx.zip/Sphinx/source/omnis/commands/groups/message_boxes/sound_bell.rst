﻿Sound bell
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Sound bell**
Description
***********
This command sounds the system beep. You can sound the bell at any point in a method todraw attention to a particular method, field, message, error, and so on.
Example
*******

.. code-block:: omnis
	:linenos:	;  Sound the bell and open the window 'wMyErrorDialog'Sound bellOpen window instance wMyErrorDialog
