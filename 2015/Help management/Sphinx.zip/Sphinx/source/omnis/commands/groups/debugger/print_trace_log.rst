﻿Print trace log
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |NO |All |

Syntax
******
**Print trace log**
Description
***********
This command prints the contents of the trace log to the current print destination.
