﻿Write file as binary
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Write file as binary** (*refnum*, *binary*-*variable* [,*start*-*position*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command writes the contents of the specified *binary-variable* to a file. Youspecify the file reference number returned by *`Open file <open_file.html>`_
*in *refnum*.

If you specify the *start-position*, writing begins at that byte (0 is the firstbyte in the file, 1 is the second byte, and so on), otherwise it begins at the currentposition (the first byte when the file is first opened).

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  write the binary class data of the window class 'MyWindow' to a file named;  'binfile' in the root of the omnis treeCalculate lPathname as con(sys(115),'binfile')Create file (lPathname) Returns lErrCodeOpen file (lPathname,lRefNum) Calculate lBinfld as $clib.$windows.MyWindow.$classdataWrite file as binary (lRefNum,lBinfld) Returns lErrCodeClose file (lRefNum) 
