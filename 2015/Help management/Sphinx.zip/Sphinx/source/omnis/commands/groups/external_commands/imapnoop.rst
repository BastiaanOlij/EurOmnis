﻿IMAPNoOp
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**IMAPNoOp** (*socket*[,*stsproc*,*responselist*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**IMAPNoOp** sends a NOOP command to the IMAP server.  The command itself does nothing, but clients can usethe NOOP command to poll the server to get status updates via untagged responses (which will be placed in the *responselist*parameter if it is present).  See RFC 3501 for details.  Note that the*`IMAPListMessages <imaplistmessages.html>`_
* command automatically sends a NOOP command before fetching the listof messages; this ensures that new messages are returned in the list.

*Socket* is an Omnis Long Integer field containing a socket opened to an IMAP serverusing *`IMAPConnect <imapconnect.html>`_
*.

*Stsproc* is an optional parameter containing the name of an Omnis method that this commandcalls with status messages. This command calls the method with no parameters,and the status information in the variable #S1. The status information logs protocolmessages exchanged on the connection to the server.

*Responselist* is an optional parameter into which this command places response lines received from the IMAP server.  Before callingthis command, define the *responselist* to have a single Character column.  When the command returns successfully, the response listcontains the untagged and tagged responses received from the IMAP server as a result of executing this command.  These sometimes include unsolicited information, for example, anupdate on the current number of messages in the selected mailbox. Each line in the response list is a response line received from the server.See RFC 3501 for more details, if you need to handle this sort of information.

This command returns an integer, which is less than zero if an error occurred.  Possible error codes arelisted in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Issue a NOOP command to poll the serverDo iResponseList.$define(iResponse)IMAPNoOp (iIMAPSocket,&quot;&quot;,iResponseList) Returns lStatusIf lStatus&lt;0    ;  NOOP command failedEnd If
