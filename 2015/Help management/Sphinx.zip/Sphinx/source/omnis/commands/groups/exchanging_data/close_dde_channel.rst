﻿Close DDE channel
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Close DDE channel** ([*All channels*])

Options
*******|All channels |If specified,the command applies to all DDE channels,rather than just the current channel |

Description
***********
DDE command, Omnis as client. This command closes the current channel. If you use the **Allchannels** option, all open DDE channels are closed. No error occurs if the currentchannel is not open.
Example
*******

.. code-block:: omnis
	:linenos:	Set DDE channel number {2}Open DDE channel {Omnis|Country}If flag false    OK message  {The Country library is not running}Else    Do method TransferData    Close DDE channel    OK message  {Update finished}End If
