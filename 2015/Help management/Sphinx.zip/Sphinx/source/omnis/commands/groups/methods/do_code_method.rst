﻿Do code method
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |NO |All |

Syntax
******
**Do code method ***code-class*/*method-name* (*parameters*)** Returns ***return-value*****
Description
***********
This command runs the specified code class method, and accepts a value back from thecalled method. The specified *method-name* must be in the code class *code-class*.The command accepts a value back from the called method if you specify a *return-value*.The return field can be a variable of any type.

When a code class method is executed using this command, control is passed to thecalled method but the value of $cinst is unchanged, therefore the code in the code classmethod can refer to $cinst. When the code class method has executed, control passes backto the original executing method. The current task is not affected by execution moving tothe code class.
**
Passing Parameters
**
You can include a list of parameters with the **Do code method** commandwhich are passed to the called method. If the called method has fewer parameters thanvalues passed to it, the extra values are ignored. 

Note that where the return field is an item reference, the command sets the referencebut does not assign to it: you must do this with *`Calculate <../../../commands/groups/calculations/calculate.html>`_
* or *`Do <../../../commands/groups/calculations/do.html>`_
* Itemref.$assign(value).*
***Example
*******

.. code-block:: omnis
	:linenos:	;  Call the method myMethod in the code class;  myCodeClass on a click event and pass the;  value of iMyVar as a parameterOn evClick    Calculate iMyVar as 100    Do code method myCodeClass/myMethod (iMyVar)
