﻿Clear find table
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |NO |NO |NO |All |

Syntax
******
**Clear find table**
Description
***********
This command clears the find table for the current main file and releases the memory itused.

When a *`Find <find.html>`_
*, `Next <next.html>`_
 or` Previous 
`_
 command is encountered, Omnis uses the Index,Search and Sort field parameters to create a table of records (similar to a SQL Selecttable). This may simply be an existing index in which case no further processing takesplace or, if there is a search and/or sort condition, a file may be scanned and aselection of records sorted in memory. If a `Next <next.html>`_
 or *`Previous 
`_
* returns an unexpected record or no record, this isprobably because there is still a find table in existence from another Find operation.

For a large file, a substantial amount of RAM may be used.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear the find table after the fist overdrawn account is foundSet main file {fAccounts}Set search as calculation {fAccounts.Balance&lt;0}Find first on fAccounts.Code (Use search)Clear find table
