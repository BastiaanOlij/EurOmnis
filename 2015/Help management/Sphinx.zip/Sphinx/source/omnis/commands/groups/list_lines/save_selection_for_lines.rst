﻿Save selection for line(s)
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Save selection for line(s)** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command saves the selection state of the specified line(s) in memory and sets theflag. To allow sophisticated manipulation of data via lists, a list can store twoselection states for each line; the &quot;Current&quot; and the &quot;Saved&quot;selection. The Current and Saved selections have nothing to do with saving data on thedisk; they are no more than labels for two sets of selections. The lists may be held inmemory and never saved to disk: they will still have a Current and Saved selection statefor each line but they will be lost if not saved. When a list is stored in the data file,both sets of selections are stored.
*
***Save selection for line(s)** allows the selection state of thespecified line (or All lines) to be copied into the Saved set. You can specify aparticular line in the list by entering either a number or a calculation. If the linenumber is not specified, the current line selection is saved. The **All lines**option saves the selection for all lines of the current list. This example selects themiddle line of the list:
Example
*******

.. code-block:: omnis
	:linenos:	;  Save and restore the selection after all;  an invertSet current list lMyListDefine list {lCol1}For lCol1 from 1 to 6 step 1    Add line to list {lCol1}End ForSelect list line(s) {3}Select list line(s) {5}Save selection for line(s) (All lines)Invert selection for line(s) (All lines)Restore selection for line(s) (All lines)
