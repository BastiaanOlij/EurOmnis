﻿Open check data log
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |NO |YES |NO |All |

Syntax
******
**Open check data log** ([*Do not wait for user*])

Options
*******|Do not wait for user |Unless this option is specified,the user must close the window before method execution continues,and before doing anything else |

Description
***********
This command opens the check data log. If the **Do not wait for user** option isspecified, execution continues with the next command, otherwise execution stops until theuser has closed the log. You use the check data log to manage the problems encountered ina data file after the *`Check data <check_data.html>`_
* command is run. Thedata log window lets you repair any problems listed in the window, print the contents ofthe log, or clear the log.
Example
*******

.. code-block:: omnis
	:linenos:	Check data (Check indexes)Open check data log
