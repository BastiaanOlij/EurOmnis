﻿Clear class variables
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Parameters and variables <../parameters_and_variables.html>`_  |NO |NO |NO |All |

Syntax
******
**Clear class variables**
Description
***********
This command clears any class variables used within the class and clears the memoryused for the class variables. **Clear class variables** is placed in a methodwithin the class where you want to clear variables.

A class variable is initialized to empty or its initial value the first time it isreferenced. It remains allocated until the class variables for its class are cleared. Theclass variables for all classes are cleared when the library file is closed.
Example
*******

.. code-block:: omnis
	:linenos:	;  Transfer values from class variables to instance;  variables and clear the class variablesCalculate cVar1 as 'my class Var1'Calculate cVar2 as 'my class Var2'Calculate cVar3 as 'my class Var3'Calculate iVar1 as cVar1Calculate iVar2 as cVar2Calculate iVar3 as cVar3Clear class variables     ;; all class variables are now empty
