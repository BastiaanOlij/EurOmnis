﻿Prepare for export to file
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Prepare for export to file** {*export-format*}

Export Formats
**************|Delimited (commas) | |
|Delimited (tabs) | |
|One field per line | |
|Omnis data transfer | |
|Delimited (user delimiter) | |

Description
***********
This command prepares to export records to a file in one of the specified data formats.The file must previously have been set using `Set print orexport file name <../../groups/report_destinations/set_print_or_export_file_name.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  export to a file called myExport.txt in the root of your omnis treeCalculate lExportPath as con(sys(115),'myExport.txt')Set print or export file name {[lExportPath]}Prepare for export to file {Delimited (commas)}Export data lExportListEnd exportClose print or export file
