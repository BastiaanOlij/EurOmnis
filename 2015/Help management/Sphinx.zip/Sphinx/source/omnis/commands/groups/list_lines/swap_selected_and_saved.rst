﻿Swap selected and saved
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Swap selected and saved** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command swaps the Saved selection state and the Current selection state and setsthe flag. To allow sophisticated manipulation of data via lists, a list can store twoselection states for each line; the &quot;Current&quot; and the &quot;Saved&quot;selection. The Current and Saved selections have nothing to do with saving data on thedisk; they are no more than labels for two sets of selections. The lists may be held inmemory and never saved to disk: they will still have a Current and Saved selection statefor each line but they will be lost if not saved. When a list is stored in the data file,both sets of selections are stored.
*
***Swap selected and saved** allows the Saved selection state of thespecified line (or All lines) to be swapped with the Current set. You can specify aparticular line in the list by entering either a number or a calculation. The **Alllines** option swaps the selection status for all lines of the current list. Thefollowing example selects the middle line of the list:
Example
*******

.. code-block:: omnis
	:linenos:	;  Select all lines, save the selection, deselect all;  lines and then swap the selected and saved lines;  so all lines are selectedSet current list lMyListDefine list {lCol1}For lCol1 from 1 to 6 step 1    Add line to list {lCol1}End ForSelect list line(s) (All lines)Save selection for line(s) (All lines)Deselect list line(s) (All lines)Swap selected and saved (All lines)
