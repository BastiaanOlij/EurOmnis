﻿Request field
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |NO |NO |Windows |

Syntax
******
**Request field** *field-name* {*server-data-item-name*}
Description
***********
DDE command, Omnis as client. This command requests a data item from the DDE channel.An error occurs if the channel is not open. The command takes the Omnis field name and theserver data item name as parameters. The data item name can contain square bracketnotation. If the data item name is not specified, the Omnis field name is used. The flagis set if the command is successful.
Example
*******

.. code-block:: omnis
	:linenos:	Set DDE channel number {1}Calculate lAttempts as 1;  keeps trying until conversation opened or number of attempts &gt; 10Repeat    Open DDE channel {Omnis|DDE2}    Calculate lAttempts as lAttempts+1Until #F|lAttempts&gt;10Calculate iCommand as '[TakeControl]'Send command {[iCommand]}If flag false    OK message  {Error: [iCommand], Open Attempts = [lAttempts]}End IfRequest field iCompany {iCompany}Request field iAddress {iAddress}Prepare for insert with current valuesEnter data Update files if flag set
