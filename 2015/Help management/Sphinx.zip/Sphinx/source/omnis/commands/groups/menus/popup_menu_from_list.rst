﻿Popup menu from list
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |NO |NO |All |

Syntax
******
**Popup menu from list ***list-name*** at ***x-coordinate*, *y-coordinate*****
Description
***********
This command installs the specified list as a popup menu at the specified *x,y*screen location. Under Windows, the coordinate 0,0 is the point directly under the menubar within the application area. Under Linux and MacOSX, 0,0 is literally the top leftcorner of the screen. If you omit the x,y coordinate from this command the menu pops up atthe current mouse position.
*
***Popup menu from list** behaves much like *`Popupmenu 
`_
* except the source of the menu is a list. The specified list can contain anynumber of rows but only the first column and a limited number of rows are displayed in thepopup menu.

This command clears the flag if the user does not select a list line and *LIST.$line*is unaffected. After the command has executed you can use *`lst() <../../../functions/groups/list/lst.html>`_
* to return the line selected.

The *`mouseover() <../../../functions/groups/mouse/mouseover.html>`_
*function returns the mouse position relative to the open window and not the Omnisapplication window. Using this function to specify the x and y position of the popup menumay not produce the effect you want.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prevent the default context menu appearing and;  open a menu containing the lines defined in the list;  lMenuLines;  $event of object on window classOn evRMouseDown     ;; requires the property $rmouseevents set to kTure    Process event and continue (Discard event)    Do lMenuLines.$define(lMenuLine)    Do lMenuLines.$add('Option 1')    Do lMenuLines.$add('Option 2')    Do lMenuLines.$add('Option 3')        Popup menu from list lMenuLines at 
