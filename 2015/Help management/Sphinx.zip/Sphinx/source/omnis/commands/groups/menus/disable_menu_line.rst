﻿Disable menu line
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Disable menu line** *line* or *instance-name*/*line*
Description
***********
This command disables the specified line of a menu instance, that is, the menu linebecomes grayed out and cannot be selected. You specify the *menu-instance-name* andthe number of the menu line you want to disable. You can disable a complete menu instanceby disabling line zero, that is the menu title.

You can reverse **Disable menu line** with the *`Enable menu line <enable_menu_line.html>`_
* command or, you can use it in areversible block. Nothing happens if the specified menu instance is not installed on themenu bar.
Example
*******

.. code-block:: omnis
	:linenos:	;  Install the menu mView and disable a menu line,;  the reversible block causes the menu line to be;  re-enabled when the method has finishedInstall menu mViewBegin reversible block    Disable menu line mView/LargeEnd reversible block;  Alternatively, you can set the $enabled property of a;  menu line using notationDo $menus.mView.$obj.Large.$enabled(kFalse)
