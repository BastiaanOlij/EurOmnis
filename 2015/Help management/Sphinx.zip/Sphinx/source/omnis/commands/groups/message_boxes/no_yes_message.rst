﻿No/Yes message
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |YES |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**No/Yes message** *title* ([*Icon*][,*Sound bell*][,*Cancel button*]) {*message*}

Options
*******|Icon |If specified,the message displays an operating system specific icon |
|Sound bell |If specified,the system bell sounds when the command displays the message |
|Cancel button |If specified,the message has a cancel button |

Description
***********
This command displays a message box containing the specified message and provides a **No**and a **Yes** pushbutton. You can include a **Cancel** button by checkingthe **Cancel button** option. When the message box is displayed method execution ishalted temporarily; it remains open until the user clicks on one of the buttons beforecontinuing. The **No** button is the default button and can therefore be selected bypressing the Return key.

The number of lines displayed in the message box depends on your operating system,fonts and screen size. In the message text you can force a break between lines (acarriage return) by using the notation &quot;//&quot;or the `kCr <../../../notation/root/constants/special_characters.html>`_
 constantenclosed in square brackets, e.g. 'First line[`kCr <../../../notation/root/constants/special_characters.html>`_
]Second line'. Also you can add a short *title* forthe message box.

For greater emphasis, you can select an **Icon** for the message box (the default&quot;info&quot; icon for the current operating system), and you can force the system bellto sound by checking the **Sound bell** check box. Under Windows XP, youhave to specify a system sound for a 'Question' in the Control Panel for theSound Bell option to work.

You can insert a **No/Yes message** at any appropriate point in a method.If the user clicks the No button, the flag is cleared; otherwise, a Yes sets the flag. Youcan use the *`msgcancelled() <../../../functions/groups/general/msgcancelled.html>`_
*function to detect if the user pressed the Cancel button.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open a No/Yes dialog and display the option selectedNo/Yes message My Editor (Icon,Cancel button) {Do you wish to save the changes you have made ?}If msgcancelled()    OK message My Editor {Cancel button pressed}Else    If flag true        OK message My Editor {OK button pressed}    Else        OK message My Editor {Cancel button pressed}    End IfEnd If
