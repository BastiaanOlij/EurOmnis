﻿Default
#######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Default**
Description
***********
This command marks the block of commands to be run when there is no matching case in a *`Switch <../p-t/switch.html>`_
* statement. When a *Switch&#150;Case*construct is used, the **Default** command marks the start of a block ofcommands that are executed if none of the preceding *`Case <case.html>`_
*statements are executed.
Example
*******

.. code-block:: omnis
	:linenos:	;  Sound the bell if lName is not equal to Fred or JimSwitch lName    Case 'Fred'        OK message  {Fred}    Case 'Jim'        OK message  {Jim}    Default        OK message  (Sound bell) {Neither Fred nor Jim}End Switch
