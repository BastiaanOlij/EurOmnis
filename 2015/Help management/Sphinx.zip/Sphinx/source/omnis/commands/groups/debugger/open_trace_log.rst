﻿Open trace log
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Open trace log** ([*Clear trace log*])

Options
*******|Clear trace log |If specified,the command clears the trace log |

Description
***********
This command opens the trace log. The trace log can also be opened via the Tools menu.
Example
*******

.. code-block:: omnis
	:linenos:	;  open the trace log and clear any existing messagesOpen trace log (Clear trace log)
