﻿Trace on
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Trace on** ([*Clear trace log*])

Options
*******|Clear trace log |If specified,the command clears the trace log |

Description
***********
This command sends all subsequent commands to the trace log and displays the currentcommand in the method editor. It lets you turn on trace mode at a point in a method whereyou suspect that there may be a problem, or some code which is difficult to follow. Intrace mode, the topmost method design window is continually changed to show the commandbeing executed. Also when in trace mode, a trace log is maintained; this contains theclass name and method name in the Item column and the command line text in the Datacolumn, for all methods which are executed in trace mode or single-stepped. Errormessages, breakpoints, and so on, which occur in trace mode are also entered in the tracelog. The **Clear trace log** option deletes all existing entries before new lines areadded to the log.

The trace log window is opened and brought to top either via the Tools  menu or bythe *`Open trace log <open_trace_log.html>`_
* command. This window allows thetrace log to be viewed, cleared or printed, and lets you alter the maximum number of linesin the log. Double-clicking on a line in the trace log causes a method design window to beopened or brought to the top with the appropriate command displayed. If Shift is pressedwhen double-clicking, a new method design window is opened in preference to changing theidentity of the class displayed in the existing method design window.

If the double-clicked line in the log is a field value line, the value window for thatfield is opened. The trace log is not adjusted when methods are modified. This means thattrace log lines may point to the wrong command or no command if the class containing thatmethod has been modified.
Example
*******

.. code-block:: omnis
	:linenos:	Open trace log;  the following lines are sent to the trace log ...Trace on (Clear trace log)For lCount from 1 to 5 step 1    OK message  {Sent to trace log}End ForTrace off;  ...and the following line is notOK message  {Not sent to trace log}
