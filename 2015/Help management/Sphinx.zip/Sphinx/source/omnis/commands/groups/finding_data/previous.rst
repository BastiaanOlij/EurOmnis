﻿Previous
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Previous** **on ***field-name***** ([*Exact match*][,*Use search*])

Options
*******|Exact match |If specified,the index value of the field in suitable records must equal the current value |
|Use search |If specified,the command uses the current search to select data |

Description
***********
This command locates the previous record using the current find table. The **Previous**command works in the same way as the corresponding option on the **Commands** menubut with no redraw, allowing you to work through a file. It is usually used after a *`Find <find.html>`_
* command which creates a find table of records.

If the **Index field**, **Exact match** and/or **Search option** used inthe* `Next <next.html>`_
 *is incompatible with the preceding* `Find <find.html>`_
, *a new table is built. Normally, the parameters in thiscommand are left blank so that the current find table is used.

If the **Previous **command does not follow a *Find*, a find table isbuilt for the current main file before doing the **Previous**.

If an indexed field is specified, **Previous on*** SU_NAME *forexample, the find table is just the index order for the field. The **Use search**option creates a table for the current main file in which the search specification isimplicitly stored. Thus, changes to the search do not affect the find table once it iscreated.

Once the previous record is located, the main and connected files are read into thecurrent record buffer and the flag is set, otherwise, the flag is cleared. An error occurswhenever **Previous on*** FIELD* is performed on a non-indexed field.

If the **Exact match** option is chosen, the previous record with the same indexvalue is found, or the flag is cleared if no previous records exist with the same indexvalue.

If you use **Previous** with a search, it finds the previous record listedon the index table which meets the search criteria.
Example
*******

.. code-block:: omnis
	:linenos:	;  Find records in descending orderFind last on fAccounts.CodeWhile flag true    OK message  {Found account [fAccounts.Code]}    Update files    Previous End While
