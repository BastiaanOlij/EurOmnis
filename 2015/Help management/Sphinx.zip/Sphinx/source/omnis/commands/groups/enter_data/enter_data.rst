﻿Enter data
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Enter data <../enter_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Enter data** ** until ***termination-condition* (leave blank to terminate on OK or Cancel)****
Description
***********
This command puts Omnis into enter data mode which allows data to be entered via thecurrent window. An error is generated if there is no open window. It initiates an internalcontrol loop which does the following: <ol>  <li>Places the cursor in the first entry field,</li>  <li>lets the user enter data from the keyboard,</li>  <li>Detects the use of Tab, Shift-Tab and other cursor movements such as click and moves the    cursor to the appropriate field,</li>  <li>Waits for an OK, setting flag true before allowing control to pass to the command    following *Enter data* in the method,</li>  <li>Detects a Cancel which aborts data entry with a false flag.</li></ol>
By default, the **Enter data** command waits for an evOK or evCancelevent. When these events are triggered enter data mode is terminated (assuming the windowis not in modeless enter data mode). However you can include a termination condition with **Enterdata** which causes enter data mode to continue until the expression becomes true. 
Example
*******

.. code-block:: omnis
	:linenos:	;  $construct of window classEnter data      ;; ;  waits for a evOK or evCancel eventIf flag true    OK message  {User has pressed Return}Else    OK message  {User has canceled}End If;  or;  $construct of window classCalculate iValue as 0Enter data  until iValue&gt;10     ;; waits for the user to enter a value greater than 10 into a entry field
