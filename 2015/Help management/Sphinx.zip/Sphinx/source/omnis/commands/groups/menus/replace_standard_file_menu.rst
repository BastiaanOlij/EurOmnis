﻿Replace standard File menu
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Replace standard File menu** {*class-name*[/*instance-name*] [(*parameters*)]}
Description
***********
This command removes the standard built-in **File** menu from the menu bar andreplaces it with a custom menu. You can assign an instance name for the replacement menu.The default instance name of the replacement menu is the menu class name. If noreplacement menu name is specified, the **File** menu is reinstated.

The replacement menu will remain enabled even when commands such as *`Disable all menus <disable_all_menus_and_toolbars.html>`_
* are issued, or modaluser-defined windows are opened. The only time the replacement menu will not remainenabled is when a report is printed to screen with the *`Send to screen <../../../commands/groups/report_destinations/send_to_screen.html>`_
*command, and the check box option **Do not wait for user** is not checked (that is,Omnis is awaiting user input).

You can disable the **File** menu or its replacement menu by using *`Disable menu line <disable_menu_line.html>`_
*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Replace the standard file menu with the user;  defined menu mMyFile while in enter data;  $construct of windowReplace standard File menu {mMyFile}Enter data Replace standard File menu     ;; put system File menu back
