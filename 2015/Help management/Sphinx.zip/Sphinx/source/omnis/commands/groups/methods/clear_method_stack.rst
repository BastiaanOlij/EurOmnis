﻿Clear method stack
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |NO |All |

Syntax
******
**Clear method stack**
Description
***********
This command cancels all currently executing methods and clears the method stack. A **Clearmethod stack** at the beginning of a method terminates all the methods in the chainwhich called the current method but without quitting the current method. $control()methods are not cleared.

As each method calls another, a return point is stored so that control can pass to thecommand following *`Do method <do_method.html>`_
* or *`Do code method <do_code_method.html>`_
 *as the called method terminates. When thecurrent method terminates, control returns to the method which was running before it wascalled.

The **Clear method stack** command clears all the return points and isused if the method commences a completely new operation. This command followed by a *`Quit method <../../../commands/groups/methods/quit_method.html>`_
* is the same as*`Quit all methods <../../../commands/groups/methods/quit_all_methods.html>`_
*.
**
WARNING** It is unwise to clear the method stack if local variables have been passedas fieldname parameters and you continue executing the current method. This will break alllocal variables on the stack.
Example
*******

.. code-block:: omnis
	:linenos:	;  Calling methodCalculate iMyVar as 1Do method Message;  the following message never gets displayedDo iMyVar+1OK message  {iMyVar=[iMyVar]};  Method MessageClear method stackDo iMyVar+1;  This message prints iMyVar=2OK message  {iMyVAR=[iMyVar]}Quit method 
