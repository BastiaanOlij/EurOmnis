﻿Quit method
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Quit method** *return-value*
Description
***********
This command quits the current method and returns control to the calling method, ifany. If you supply a *return-value*, the command returns this value to the callingmethod.
Example
*******

.. code-block:: omnis
	:linenos:	;  Quit the method myMethod and return the flag;  from the Yes/No message to the calling method;  calling methodDo method myMethod Returns lReturnFlag;  method myMethodYes/No message  {Continue ?}Quit method #F
