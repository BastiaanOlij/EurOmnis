﻿Sort list
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |NO |NO |All |

Syntax
******
**Sort list**
Description
***********
This command sorts the current list in the order specified by the current sort fields.You can use *`Set sort field <../../groups/sort_fields/set_sort_field.html>`_
*to set the sort fields. Note that lists have to be explicitly redrawn before you can viewthe results of a sort.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iMyListDefine list {fCustomers}Set main file {fCustomers}Build list from file  (Use search)Clear sort fieldsSet sort field fCustomers.SurnameSet sort field fCustomers.TownSort list;  or do it like thisDo iMyList.$sort(fCustomers.Surname,kTrue,fCustomers.Town,kTrue)
