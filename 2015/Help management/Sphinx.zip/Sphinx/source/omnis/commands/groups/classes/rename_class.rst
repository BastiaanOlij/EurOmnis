﻿Rename class
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Rename class** ([*Perform find and replace*]) {*class-name*/*new-name*}

Options
*******|Perform find and replace |If specified,and the command is executing in a development version of Omnis,the command opens the find and replace dialog to allow the user to replace the old class name with the new class name |

Description
***********
This command renames the specified library class and can perform a find and replace.Errors, such as attempting to use a name that is already in use, simply clear the flag anddisplay an error message. You can rename a class which is in use.

When renaming a class, you can use the **Perform find and replace** option tosearch through all the classes in the library and replace the references to the old classname with the new name.
Example
*******

.. code-block:: omnis
	:linenos:	New class {Search Class/sMySearch}     ;; create new search classModify class {sMySearch}     ;; let user modify itDelete class {sUser}     ;; delete the seach class sUserRename class {sMySearch/sUser}     ;; rename the new search class to the old searchSet search name sUserPrint report (Use search)
