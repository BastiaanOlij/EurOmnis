﻿Does file exist
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Does file exist** (*file*\*folder*-*name*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command returns **`kTrue <../../../notation/root/constants/boolean_values.html>`_
**if the specified file or folder exists, otherwise it returns **`kFalse <../../../notation/root/constants/boolean_values.html>`_
**. The file orfolder must specify the full path.

See also, the command `Testif file exists <../../groups/operating_system/test_if_file_exists.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lPathname as con(sys(115),'html',sys(9),'serverusagetask.htm')Calculate lNewPath as con(sys(115),'html',sys(9),'serverusagetask2.htm')Copy file (lPathname,lNewPath) Returns lErrCode     ;; copies the file in lPathName to the filename contained in lNewPathDoes file exist (lNewPath) Returns lStatus     ;; see if the file existsIf lStatus    Delete file (lNewPath) Returns lErrCode     ;; delete itEnd If
