﻿While flag true
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**While flag true**
Description
***********
This command starts a **While***&#150;`End While <end_while.html>`_
*loop which continues while the flag is true. While the condition is true, a command or aseries of commands is executed until the condition becomes false, at which time the firstcommand after the closing *`End While <end_while.html>`_
* command isexecuted. A loop that begins with a *While* command must terminate with an *`End While <end_while.html>`_
*, otherwise an error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  loop until 'No' is pressedCalculate #F as kTrue     ;; set falg as TrueWhile flag true    Yes/No message  {Do you wish to contine looping ?}End While
