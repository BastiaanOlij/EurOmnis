﻿Changing data
#############
`Command Index <../command_index.html>`_


`Commands
******** <changing_data#commands>`_
|`Cancel prepare for update <changing_data/cancel_prepare_for_update.html>`_  |`Delete <changing_data/delete.html>`_  |`Delete with confirmation <changing_data/delete_with_confirmation.html>`_  |`Do not flush data <changing_data/do_not_flush_data.html>`_  |
|`Do not wait for semaphores <changing_data/do_not_wait_for_semaphores.html>`_  |`Flush data <changing_data/flush_data.html>`_  |`Flush data now <changing_data/flush_data_now.html>`_  |`Prepare for edit <changing_data/prepare_for_edit.html>`_  |
|`Prepare for insert <changing_data/prepare_for_insert.html>`_  |`Prepare for insert with current values <changing_data/prepare_for_insert_with_current_values.html>`_  |`Test for only one user <changing_data/test_for_only_one_user.html>`_  |`Update files <changing_data/update_files.html>`_  |
|`Update files if flag set <changing_data/update_files_if_flag_set.html>`_  |`Wait for semaphores <changing_data/wait_for_semaphores.html>`_  |

