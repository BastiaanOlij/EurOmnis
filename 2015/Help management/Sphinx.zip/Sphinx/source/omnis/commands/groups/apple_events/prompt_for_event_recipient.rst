﻿Prompt for event recipient
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |NO |NO |MacOSX |

Syntax
******
**Prompt for event recipient** {*recipient-tag*}
Description
***********
This command prompts the user to select the name of an application which will becomethe destination of all subsequent events. The **recipient tag** is entered also.Recipient tags may have a maximum of 31 characters. Several recipients may be promptedfor, each with a different tag, but you can use only one at a time. A complete list ofcurrent recipients is built with the `Buildlist of event recipients <../../../commands/groups/apple_events/build_list_of_event_recipients.html>`_
 command.

If no recipient tag is specified for the application, the tag will be supplied byOmnis. Its name will be capitalized and spaces removed. Once an event recipient has beentagged, you can use the tag as a parameter for the `Use eventrecipient <../../../commands/groups/apple_events/use_event_recipient.html>`_
 command without further prompting, thus allowing recipients to bechanged easily.

Note: this command is not available on MacOSX.
Example
*******

.. code-block:: omnis
	:linenos:	;  this example is a pushbutton method which sets up two recipientsOn evClick    OK message  {Locate the Excel spreadsheet for me}    Prompt for event recipient {Sheet}     ;; tagged as &quot;Sheet&quot;    OK message  {Locate the remote database for me}    Prompt for event recipient {Data}     ;; tagged as &quot;Data&quot;        Begin reversible block        Set current list iList    End reversible block        Build list of event recipients        Set event recipient {[iList(1,1)]}     ;; uses first recipient in the list, that is R1, C1
