﻿;  Comment
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**;  ***message*****
Description
***********Example
*******

.. code-block:: omnis
	:linenos:	;  here are some comments;  variable delay set by lDelay;  adjust Until calculation to increase/decrease delayCalculate lCount as 1Repeat     ;; this is an in-line comment    Calculate lCount as lCount+1Until lCount&gt;=lDelay*10
