﻿Set reference
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Set reference ***field-name*** to ***notation-or-calculation-for-an-item*****
Description
***********
This command sets up and stores a reference to an item in a variable of type Itemreference. It assigns an *alias* for an item of notation that you do not want to typeeach time the item is referenced in the code.

Note - for JavaScript client-executed methods this command is equivalent to `Calculate <../../../commands/groups/calculations/calculate.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  declare local variable lRef of type Item reference in a window class;  set the local item reference variable lRef to a Balance field on a Page PaneSet reference lRef to $cinst.$objs.PagePane.$objs.Balance;  now you can set the text color of the Balance field to red using lRefDo lRef.$textcolor.$assign(kRed)
