﻿Get file read-only attribute
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Get file read-only attribute** (*path*, *read*-*flag*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command returns the current read-only attribute of the file specified in *path*.If the *read-flag* parameter returns `kTrue <../../../notation/root/constants/boolean_values.html>`_
 the file is read-only, otherwise if `kFalse <../../../notation/root/constants/boolean_values.html>`_
is returned the file is read/write.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  returns the read-only attribute of the omnis.exe in the omnis treeCalculate lFileName as con(sys(115),'omnis.exe')Get file read-only attribute (lFileName,lFileAttribute) Returns lErrCode
