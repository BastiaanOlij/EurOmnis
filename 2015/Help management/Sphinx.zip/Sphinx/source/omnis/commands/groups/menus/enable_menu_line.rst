﻿Enable menu line
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Enable menu line** *line* or *instance-name*/*line*
Description
***********
This command enables the specified line of a menu instance. It reverses the *`Disable menu line <disable_menu_line.html>`_
* command. However, you cannot enablea line using this command if you have no access to it, or if there is no current record.You specify the *menu-instance-name* and the number of the menu line you want toenable. The command clears the flag if the menu instance is not installed or if the linecannot be enabled.
Example
*******

.. code-block:: omnis
	:linenos:	;  Install the menu mView and enable the menu line;  'Large' if it is currently disabledInstall menu mViewDisable menu line mView/LargeTest for menu line enabled mView/LargeIf flag false    Enable menu line mView/LargeEnd If
