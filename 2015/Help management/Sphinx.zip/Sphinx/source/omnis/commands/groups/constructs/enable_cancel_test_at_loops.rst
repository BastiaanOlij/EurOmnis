﻿Enable cancel test at loops
###########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |YES |NO |All |

Syntax
******
**Enable cancel test at loops**
Description
***********
This command causes Omnis to test if the user wishes to cancel execution of the method, at the end of each loop and duringlengthy operations such as searching or sorting a large list. The user requests a cancel by either clicking on a working message Cancel button, or by pressing Ctrl-Break under Windows, Ctrl-C under Linux, or Cmnd-period under MacOSX. This command reverses the *`Disable cancel test at loops <disable_cancel_test_at_loops.html>`_
*command. Unless Omnis has executed a *`Disable canceltest at loops <disable_cancel_test_at_loops.html>`_
*, cancel testing is carried out automatically.
Example
*******

.. code-block:: omnis
	:linenos:	;  delete all overdrawn accounts without interruption by the user requesting a cancelSet main file {fAccounts}Set search as calculation {fAccounts.Balance&lt;0}Find on fAccounts.Code (Use search)Disable cancel test at loopsWhile flag true    Working message  (Repeat count) {Deleting Account [fAccounts.Code]}    Delete    Next on fAccounts.Code (Exact match)End WhileEnable cancel test at loops     ;; enable break key for next loop
