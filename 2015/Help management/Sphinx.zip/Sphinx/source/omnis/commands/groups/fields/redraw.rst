﻿Redraw
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |NO |NO |NO |All |

Syntax
******
**Redraw** ([*Refresh now*]) {*list-of-field-or-window-names* (Name1,Name2,...)}

Options
*******|Refresh now |If specified,the redraw occurs before the command finishes executing,rather than occurring at a later indeterminate point |

Description
***********
This command redraws the specified field or window instance (or list of fields orwindow instances). The **Refresh now** option ensures the redraw is completed whenthe command is executed. Without this option the redraw occurs when the method hasfinished executing.
Example
*******

.. code-block:: omnis
	:linenos:	Prepare for editEnter data If flag true    Update filesElse    Clear main &amp; connected    Redraw {wDataEntry}End If;  alternatively you can use the $redraw(setcontents,refresh) method to redraw the contents;  and/or refresh a field or window; setcontents defaults to true, refresh to falseDo $cfield.$redraw()     ;; redraw current fieldDo $cwind.$redraw()     ;; redraw current windowDo $root.$redraw()     ;; redraw all window instances
