﻿Process event and continue
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Process event and continue** ([*Discard event*])

Options
*******|Discard event |If specified,Omnis discards the active event (meaning that no further processing will occur for that event) |

Description
***********
This command causes the current event to be processed immediately allowing the eventhandler method containing the command to continue to execute. Normally, the defaultprocessing for an event takes place when all the event handler methods dealing with theevent have finished executing. It is not possible to have active unprocessed events whenwaiting for user input so the default processing is carried out for any active eventsafter an `Enter data <../../groups/enter_data/enter_data.html>`_
 command has beenexecuted or at a debugger break. Therefore if required, you can use this command tooverride the default behavior and force events to be processed allowing the event handlermethod to continue.

The **Discard event** option lets you discard the active event.
Example
*******

.. code-block:: omnis
	:linenos:	;  This code would cause the OK event to be thrown away before the Enter Data startsOn evOK    Process event and continue (Discard event)    Open window instance wMyWindow    Enter data 
