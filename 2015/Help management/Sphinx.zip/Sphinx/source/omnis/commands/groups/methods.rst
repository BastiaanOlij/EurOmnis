﻿Methods
#######
`Command Index <../command_index.html>`_


`Commands
******** <methods#commands>`_
|`Cancel async method <methods/cancel_async_method.html>`_  |`Clear method stack <methods/clear_method_stack.html>`_  |`Clear timer method <methods/clear_timer_method.html>`_  |`Do async method <methods/do_async_method.html>`_  |
|`Do code method <methods/do_code_method.html>`_  |`Do method <methods/do_method.html>`_  |`Optimize method <methods/optimize_method.html>`_  |`Quit all if canceled <methods/quit_all_if_canceled.html>`_  |
|`Quit all methods <methods/quit_all_methods.html>`_  |`Quit method <methods/quit_method.html>`_  |`Quit Omnis <methods/quit_omnis.html>`_  |`Set timer method <methods/set_timer_method.html>`_  |

