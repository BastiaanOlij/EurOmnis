﻿Unload error handler
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Error handlers <../error_handlers.html>`_  |YES |NO |NO |All |

Syntax
******
**Unload error handler** [*name*/]*name*
Description
***********
This command unloads the specified error handler (a method is taken as its parameter).If there are multiple error handlers at that method, they are all unloaded. The flag isset if an error handler is unloaded. See *`Load errorhandler <load_error_handler.html>`_
* for more information about error handlers.
Example
*******

.. code-block:: omnis
	:linenos:	Unload error handler cMyErrorHandler/ErrorsLoad error handler cMyErrorHandler/Error2Handler
