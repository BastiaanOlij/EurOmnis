﻿Build field names list
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |YES |YES |NO |All |

Syntax
******
**Build field names list** ([*Clear list*][,*Full names*]) {*file-name*}

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |
|Full names |If specified,names in the list are prefixed with their file class name |

Description
***********
This command builds a list of field names for the specified file class in the currentlist. You must specify the following columns in the current list.
|**Column 1 (Character)** |**Column 2 (Character)** |**Column 3 (Character)** |
|Field name |Field type and length |Description; for index fields only |

When you use the **Clear list** option you get column 1 only defined as #S5. Withthis option the command becomes reversible. The flag is cleared if the value of *LIST.$linemax*prevents a complete list from being built.

The **Full names** option creates a list in which the fields are prefixed with thefile class name, for example, PO_DATE becomes FPORDERS.PO_DATE.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list of the field names in the file class fAccountsSet current list lFieldListBuild field names list (Clear list,Full names) {fAccounts};  alternatively $makelist can be usedDo $files.fAccounts.$objs.$makelist($ref.$name) Returns lFieldList
