﻿Clear main file
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear main file**
Description
***********
This command clears the main file record from the current record buffer. The commanddoes not clear the values taken from the other files.

The **Clear main file** command does not redraw the window so remember toinclude an explicit `Redraw <../../../commands/groups/fields/redraw.html>`_
window command if you want the screen to reflect the contents of the buffer.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear the current record buffer of file variables from the main;  file fAccounts and redraw the current window instanceSet main file {fAccounts}Clear main fileDo $cinst.$redraw()
