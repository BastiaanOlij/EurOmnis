﻿Clear data
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Clipboard <../clipboard.html>`_  |YES |NO |NO |All |

Syntax
******
**Clear data** *field-name* ([*Redraw field*][,*All windows*])

Options
*******|Redraw field |If specified,the command reloads affected window fields with the new value of the data field,after it has performed the operation; note that this takes the 'All windows' option into account |
|All windows |If specified,the command applies to all open window instances,rather than just the top open window instance |

Description
***********
This command clears the data from the specified field or current selection. The data islost and is not placed on the clipboard. If you do not specify a field, the currentfield&#146;s data is cleared (assuming there is a selection).

In the case of a null selection when the cursor is merely flashing in a field and nocharacters are selected, **Clear data** will literally clear &quot;nothing&quot;.
Example
*******

.. code-block:: omnis
	:linenos:	;  The following method is placed behind a entry field named 'Price' on a window and;  checks if the value entered is over 5000.   If it is, the value entered into the field;  is cleared and the cursor remains in the field.On evAfter    If iPrice&gt;5000        Yes/No message  {Is this price correct?}        If flag false            Clear data iPrice (Redraw field)            Queue set current field {Price}        End If
