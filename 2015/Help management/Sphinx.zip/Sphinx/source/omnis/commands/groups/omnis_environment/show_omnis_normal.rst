﻿Show Omnis normal
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Show Omnis normal**
Description
***********
This command shows Omnis at its normal size within the application window. Icons forother applications are visible along the bottom of the screen.
Example
*******

.. code-block:: omnis
	:linenos:	;  Return Omnis to it's original size after processingShow Omnis minimizedFor lCount from 1 to 100000 step 1    ;  delayEnd ForShow Omnis normal
