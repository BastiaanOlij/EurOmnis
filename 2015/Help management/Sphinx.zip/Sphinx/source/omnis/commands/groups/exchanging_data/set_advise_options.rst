﻿Set advise options
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Set advise options** ([*Find/next/previous*][,*OK*][,*Redraw*])

Options
*******|Find/next/previous |If specified,Omnis will send DDE advise messages to the client application,when Find/Next/Previous or Clear commands are executed (see command Advise on find/next/previous) |
|OK |If specified,Omnis will send DDE advise messages to the client application,when an evOK event occurs (see command Advise on OK) |
|Redraw |If specified,Omnis will send DDE advise messages to the client application,when a redraw occurs (see command Advise on redraw) |

Description
***********
DDE command, Omnis as server. This command determines when Omnis is permitted to sendrequested Advise messages to the client application. When the **`Accept advise requests <accept_advise_requests.html>`_
** option is active, Omniswill accept Advise requests from the client program. By default, the client program willonly be advised of the values requested from Omnis when **`Sendadvises now <send_advises_now.html>`_
** is executed.

However, **Set advise options** specifies other events which will causethe values to be sent. There are three checkbox options available for this command: **Find/next/previous,OK**, and **Redraw**.

The **Find/next/previous** option sends the requested Advise value whenever aFind/next/previous command or a Clear command is executed. The **OK** option sendsthe requested Advise value whenever an **`Enter Data <../../groups/enter_data/enter_data.html>`_
** or **`Prompted Find <../../groups/finding_data/prompted_find.html>`_
** ends with an OK.The **Redraw** option sends the requested Advise value whenever a Redraw is executed.

Each of these options in **Set advise options** has its command equivalentwithin the *Exchanging Data...* group, whose function is identical. These commandsare listed as **`Advise on Find/next/previous <advise_on_find_next_previous.html>`_
***,***`Advise on OK <advise_on_ok.html>`_
***, *and* ***`Advise on redraw <advise_on_redraw.html>`_
**.
Example
*******

.. code-block:: omnis
	:linenos:	Set server mode (Field requests,Advise requests)Set advise options (Find/next/previous,OK)OK message  {Server mode for DDE enabled}
