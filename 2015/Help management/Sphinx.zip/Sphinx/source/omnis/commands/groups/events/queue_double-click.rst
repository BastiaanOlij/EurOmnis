﻿Queue double-click
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue double-click** ([*Shift*][,*Command/Ctrl*]) {*field-name* (*selection-range*)}

Options
*******|Shift |If specified,the queued event behaves as if the shift key has been pressed |
|Command/Ctrl |If specified,the queued event behaves as if the command/ctrl key has been pressed |

Description
***********
This command queues a &quot;double-click event&quot; on the specified field, that is,it simulates a user-generated double-click event on the field. A double-click event alwaysgenerates an `evClick <../../../notation/root/iwindows/window.html>`_
 before an `evDoubleClick <../../../notation/root/iwindows/window.html>`_
. You must specify thename of the field as a parameter, including the click positions within the field (that is,Start Row, Finish Row for lists and Start Character, Finish Character for text fieldselection).

There are options for including up to three modifier keys (that is, Shift, Ctrl/Cmnd)along with the click.

The field name parameter must be the name of a window field, not the name of the methodassociated with the field or the data name (*$fieldname*, not *$dataname*).
**Queue double-click for edit fields
==================================**
Double-clicks on text within an edit field will select the complete word. If a rangewas specified, all COMPLETE words falling within the start and end positions will behighlighted. 
**Queue double-click for list fields
==================================**
Double-clicks on list fields will generate an `evClick <../../../notation/root/iwindows/window.html>`_
 followed by an `evDoubleClick <../../../notation/root/iwindows/window.html>`_
. The behavior in otherways is the same as described for *`Queue click <queue_click.html>`_
*.
**Queue double-click for other field types
========================================**
Pushbuttons, radio buttons, radio groups and check boxes behave in the same way as described for `Queue click <queue_click.html>`_
. An `evDoubleClick <../../../notation/root/iwindows/window.html>`_
 event is *not*generated.
Example
*******

.. code-block:: omnis
	:linenos:	;  Example for edit fields;  If the text in the field is:;  Good books are the lifeblood of a master spirit;  and the command isQueue double-click {myEditField (7,23)};  The selected text is:;  books are the lifeblood;  Example for pushbutton - opens a new window while in Enter Data mode;  and selects all the text in the field myFieldOn evClick    Open window instance wMyWindow    Queue double-click {myField}    On default    Quit event handler
