﻿Set DDE channel number
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |YES |NO |Windows |

Syntax
******
**Set DDE channel number** {*calculation*}
Description
***********
DDE command, Omnis as client. This command sets the channel number to be used insubsequent DDE commands.. Each channel number identifies a particular conversation.

The channels are numbered from 1 to 8, and the flag is cleared if an invalid channelnumber is used. If you omit the channel number, it defaults to 1. The channel numberselected can be the result of a calculation. All subsequent channel commands function onthe current channel number. To select another channel, you must use a new **Set DDEchannel number** command.
Example
*******

.. code-block:: omnis
	:linenos:	Set DDE channel number {2}Open DDE channel {Omnis|Country}If flag false    OK message  {The Country library is not running}Else    Send command {Do method Invoice}    Do method TransferDataEnd If
