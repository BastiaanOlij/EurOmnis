﻿Delete file
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Delete file** (*path*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command permanently deletes the file specified by *path*.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lPathname as con(sys(115),'html',sys(9),'serverusagetask.htm')Calculate lNewPath as con(sys(115),'html',sys(9),'serverusagetask2.htm')Copy file (lPathname,lNewPath) Returns lErrCode     ;; copies the file in lPathName to the filename contained in lNewPathDoes file exist (lNewPath) Returns lStatus     ;; see if the file existsIf lStatus    Delete file (lNewPath) Returns lErrCode     ;; delete itEnd If
