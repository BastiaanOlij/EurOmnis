﻿Test for field visible
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for field visible** {*field-name*}
Description
***********
This command tests whether a particular field is visible. If the specified field in thetop window instance is visible, that is, $visible is `kTrue <../../../notation/root/constants/boolean_values.html>`_
 and the field has not beenhidden with `Hide fields <hide_fields.html>`_
, the flag is set. A fieldunder another field or beyond the edge of the screen, may be reported as visible and theflag set. The flag is always cleared if there are no window instances open or if the fielddoes not exist.
Example
*******

.. code-block:: omnis
	:linenos:	Test for field visible {myField}If flag true    Hide fields {myField}Else    Show fields {myField}End If;  or do it like thisIf $cwind.$objs.myField.$visible    Do $cwind.$objs.myField.$visible.$assign(kFalse)Else    Do $cwind.$objs.myField.$visible.$assign(kTrue)End If
