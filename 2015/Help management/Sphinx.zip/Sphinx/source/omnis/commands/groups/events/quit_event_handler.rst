﻿Quit event handler
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Quit event handler** ([*Discard event*][,*Pass to next handler*])

Options
*******|Discard event |If specified,Omnis discards the active event (meaning that no further processing will occur for that event) |
|Pass to next handler |If specified,Omnis will pass the event to the next level of handler (the window or task $control() method) |

Description
***********
This command is used to quit out of the currently executing event handling method andis only used to terminate an *On* clause. It is not reversible and does not affectthe flag.

If the **Discard event** option is checked, the event is thrown away and Omnisquits the event handling method.

If the **Pass to next handler** option is checked, the event is passed to the nextlevel of handler such as the window $control() method or task $control() method.
Example
*******

.. code-block:: omnis
	:linenos:	On evAfter    If iName=''        OK message  {You must enter a name}        Queue set current field {myField}        Quit event handler (Discard event)    End If        ;  $event for a window field, to pass all events to the window $control() methodOn default    Quit event handler (Pass to next handler)
