﻿Prompt for input
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |YES |NO |NO |All |

Syntax
******
**Prompt for input ***prompt*/*title*/*icon-id*/*max-chars*** Returns ***return-value***** ([*Sound bell*][,*Cancel button*][,*Upper case only*][,*Password entry*][,*Prompt above entry*])

Options
*******|Sound bell |If specified,the system bell sounds when the command displays the message |
|Cancel button |If specified,the message has a cancel button |
|Upper case only |If specified,all input is converted to upper case at the user interface |
|Password entry |If specified,all input is displayed as '*' or a solid circle at the user interface |
|Prompt above entry |If specified,the prompt is displayed above the entry field,rather than the default,which is to the left of the entry field |

Description
***********
This command opens a message box requesting a value from the user. You can specify thetext for the prompt, title and icon for the message box, and the maximum number ofcharacters for the input. If the user enters a value and presses OK, the command sets theflag and returns the user value. The command is not reversible.

The first parameter for the **Prompt for input** command is the *prompt-text*which is the prompt displayed to the left of the entry field by default; you can place theprompt text above the entry field using the **Prompt above entry** option. You canalso enter a *title* for the message box. The prompt and title default to empty. Notethat if you want to enter an empty title, you need to enter '/ /' to avoid ambiguity withthe newline convention.

You can specify an icon for the message box using the *icon-id* of an icon fromthe OmnisPic or UserPic icon data file. Zero is the default which means no icon. You canuse one of the icon size constants enclosed in square brackets with the icon id to specifya non-default size, for example, [1710+k48x48]. You can specify the maximum number ofcharacters that the user can enter in *max-chars*. This defaults to the maximumlength defined in your return field. The *return-field* can specify an initial valuefor the entry field on the message box, and receives the value entered after the userclicks OK.

The **Sound bell** option causes the system beep to sound when the message boxopens. The **Cancel button** option adds a Cancel button to the message box. The flagreturns false if the user presses the Cancel button. The **Upper case only** optionforces all input to be upper case, while the **Password entry** option hides theinput, by displaying '*' for each character entered.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt for a username and greet the userPrompt for input Please enter your name Returns lUserName (Sound bell,Cancel button,Prompt above entry)If len(lUserName)    OK message  (Icon) {Hello [lUserName]}End If
