﻿Remove all menus
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Remove all menus**
Description
***********
This command removes all menu instances from the menu bar, *excluding* thestandard Omnis menus such as **File**** **and** ****Edit**. If you use **Removeall menus** in a reversible block, the menu instances are reinstalled when themethod containing the block finishes.
Example
*******

.. code-block:: omnis
	:linenos:	;  Remove all user defined menus from the main;  omnis menubarBegin reversible block    Remove all menusEnd reversible blockOK message  {Menus are now removed};  now all menu instances are reinstalled
