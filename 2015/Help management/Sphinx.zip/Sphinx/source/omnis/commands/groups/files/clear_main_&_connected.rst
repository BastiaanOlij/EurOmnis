﻿Clear main &amp; connected
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear main &amp; connected**
Description
***********
This command clears the memory of current records from the main file and any filesconnected to the main file. The windows are not automatically redrawn so you must followit with a *`Redraw <../../../commands/groups/fields/redraw.html>`_
 window-name*command if you want the screen to reflect the current state of the buffer.

You can use **Clear main &amp; connected** to release locked records toother users.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear the current record buffer of file variables from fAccounts;  and any connected file classes if insert is cancelled;  $construct of window classSet main file {fAccounts}Prepare for insertEnter data If flag false    Clear main &amp; connectedEnd If
