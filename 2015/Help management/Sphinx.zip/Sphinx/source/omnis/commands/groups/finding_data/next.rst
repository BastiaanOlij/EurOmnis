﻿Next
####
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Next** **on ***field-name***** ([*Exact match*][,*Use search*])

Options
*******|Exact match |If specified,the index value of the field in suitable records must equal the current value |
|Use search |If specified,the command uses the current search to select data |

Description
***********
This command locates the next record using the current find table.* *The **Next****command works in the same way as the corresponding option on the **Commands**menu but with no redraw, allowing you to work through a file. It is usually used after a*`Find <find.html>`_
 *command which creates a find table of records.

If the **Index field**, **Exact match** and/or **Search** option used inthe* ***Next*** *is incompatible with the preceding* `Find <find.html>`_
, *a new find* *table is built. Normally, the parametersin this command are left blank so that the current find table is used.

If the **Next*** *command does not follow a `Find <find.html>`_
,a find table is built for the current main file before doing the **Next**.

If an indexed field is specified, **Next on*** SU_NAME *for example,the find table is just the index order for the field. The **Use search** optioncreates a find table for the current main file in which the search specification isimplicitly stored. Thus, changes to the search do not affect the find table once it iscreated.

Once the next record is located, the main and connected files are read into the currentrecord buffer.

An error occurs whenever a **Next*** ***on*** FIELD*command is performed on a non-indexed field or if the field is not in the main file or itsconnected files.

If the next record is found, the flag is set; if not, it is cleared.

If the **Exact match** option is chosen, the next record is loaded where the indexvalue of the specified field matches the current value.

If you use **Next** with a search, it builds a find table if necessary andfinds the next record listed on the find table which meets the search criteria.
Example
*******

.. code-block:: omnis
	:linenos:	;  Add 5% to all account balancesFind first on fAccounts.CodeWhile flag true    Calculate fAccounts.Balance as fAccounts.Balance+((fAccounts.Balance/100)*5)    Update files    Next End While
