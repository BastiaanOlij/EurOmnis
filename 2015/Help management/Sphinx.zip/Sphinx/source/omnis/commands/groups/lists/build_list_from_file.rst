﻿Build list from file
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |NO |NO |All |

Syntax
******
**Build list from file** **on ***field-name***** ([*Exact match*][,*Use search*][,*Use sort*])

Options
*******|Exact match |If specified,the index value of the field in suitable records must equal the current value |
|Use search |If specified,the command uses the current search to select data |
|Use sort |If specified,the command uses the current sort field(s) to order the data |

Description
***********
This command builds a list of data from the main file using a specified index field.The records are selected and corresponding field values added to the list in the order ofthe specified index field. You must set the main file before using the command.

If the **Exact match** option is specified, only records matching the currentvalue of the specified field are added to the list. Similarly, if the **Use search**check box is selected, only records matching the current search class are added. In bothcases, an error occurs if neither a field nor a search class is specified.

When large files are involved, that is, those that may require more than the maximumnumber of available lines (the value of *LIST.$linemax*), you can use the flag falsecondition to detect when an incomplete list is built.

Building a list using this command does not affect the current record buffer and doesnot clear &#145;Prepare for update&#146; mode.

The **Use sort** option lets you use the database records in sorted order withoutfirst having to load them into a list. You use `Set sort field <../../groups/sort_fields/set_sort_field.html>`_
 to specify asort field after which **Build list from file*** (Use sort) *creates asorted table of records in memory before loading them into the list. The main advantage ofthis method is that the sort fields do not have to be read into the list at all. The Sortfield order overrides the index field order but if the sort field is non-indexed, theindex is used as the order in which to gather up records before sorting. Multi-level sortsare possible by using repeated `Setsort field <../../groups/sort_fields/set_sort_field.html>`_
 commands to accumulate the required sorting order. Since sort levelsare cumulative you should first clear any existing ones with `Clear sort fields <../../groups/sort_fields/clear_sort_fields.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  This example compiles a list of all records sorted in order of descending fCustomers.Surname;  and within each value, in increasing fCustomers.FirstName orderSet current list iMyListSet main file {fCustomers}Define list {fCustomers.Surname,fCustomers.FirstName}Clear sort fieldsSet sort field fCustomers.Surname (Descending)Set sort field fCustomers.FirstName;  Note fCustomers.CustomerID is not in the listBuild list from file on fCustomers.CustomerID (Use sort)
