﻿Send Finder event
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |NO |NO |NO |MacOSX |

Syntax
******
**Send Finder event** {*message* (*parameters*)}

Messages
********|Show About | |
|Get File Info | |
|Duplicate Files | |
|Make Alias For Files | |
|Open Files | |
|Print Files | |
|Reveal Files | |
|Share Files | |
|Empty Trash | |
|Restart Macintosh | |
|Show Clipboard | |
|Shutdown Macintosh | |
|Sleep Macintosh | |

Description
***********
This command sends one of the Finder events to the standard MacOSX Finder. With theexception of the *Open Files* and *Print Files* messages, events in this groupcan only be sent to the local Finder.

The Finder event suite lets you manipulate files on your hard disk. If the events areaccepted, the flag is set to true.
Example
*******

.. code-block:: omnis
	:linenos:	;  You may be familiar with the following events that act directly on the local Finder,;  since you can find them on the Finder's pull-down menus.Send Finder event {Get File Info}Send Finder event {Make Alias For Files}Send Finder event {Reveal Files}Send Finder event {Share Files}Send Finder event {Duplicate Files};  If run without parameters, they bring up a standard dialog window, allowing one or more;  files or folders to be selected. Pathname parameters can also be entered from the keyboard, using Apple syntax;;  see the appropriate Apple reference manualsSend Finder event {Get File Info ('MyHD:Desktop folder:Microsoft Word')};  The other four events above behave in a similar way;  The following messages are self-explanatory and take no parametersSend Finder event {Empty Trash}     ;; permanently removes deleted filesSend Finder event {Show About}     ;; shows the 'About' information for this computerSend Finder event {Restart Macintosh}Send Finder event {Show Clipboard}Send Finder event {Shutdown Macintosh}Send Finder event {Sleep Macintosh}Send Finder event {Open Files}Send Finder event {Print Files};  you can use these last two events to launch and print files under MacOSX eg:Send Finder event {Open Files ('MyMac:MyHD:Apps:AnApp:Doc2')}Send Finder event {Print Files ('MacNum:MyHD:Apps:AnApp:MyDoc')}
