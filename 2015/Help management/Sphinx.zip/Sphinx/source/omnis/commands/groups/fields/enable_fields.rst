﻿Enable fields
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |NO |NO |NO |All |

Syntax
******
**Enable fields** {*list-of-field-names* (Name1,Name2,...)}
Description
***********
This command enables the specified field or list of fields. You can use it to reversethe *`Disable fields <disable_fields.html>`_
 *command, or turn Display fieldsinto Entry fields temporarily.
Example
*******

.. code-block:: omnis
	:linenos:	;  enable 2 fieldsBegin reversible block    Enable fields {myField1,myField2}End reversible blockPrepare for insertEnter data Update files if flag setQuit method ;  now this method ends and the fields are re-disabled as they are in a reversible block;  to enable a single field on the current windowDo $cwind.$objs.myField1.$enabled.$assign(kTrue);  to enable all fields on the current window like thisDo $cwind.$objs.$sendall($ref.$enabled.$assign(kTrue))
