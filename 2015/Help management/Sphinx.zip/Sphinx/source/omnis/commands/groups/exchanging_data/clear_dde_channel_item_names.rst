﻿Clear DDE channel item names
############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Clear DDE channel item names**
Description
***********
DDE command, Omnis as client. This command clears all server data item names selectedfor use with a print-to-channel report. You use this command when exporting data via a DDEchannel to another Windows application. The channel item names become the item names intowhich the server places the fields printed in the Omnis report.
*
***Clear DDE channel item names** clears all the item names set up with**`Set DDE channel item name <set_dde_channel_item_name.html>`_
**.
Example
*******

.. code-block:: omnis
	:linenos:	Set DDE channel number {2}Open DDE channel {Excel|Sheet1}Send to DDE channelSet report name rMyReportClear DDE channel item namesSend command {[[TakeControl]}     ;; double first [['s so Omnis accepts textIf flag true    Set DDE channel item name {R1,C1}    Set DDE channel item name {R2,C1}    ;  ...    Set DDE channel item name {R50,C1}    Print reportEnd If
