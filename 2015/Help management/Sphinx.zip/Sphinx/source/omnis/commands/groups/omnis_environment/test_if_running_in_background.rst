﻿Test if running in background
#############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |YES |NO |NO |All |

Syntax
******
**Test if running in background**
Description
***********
This command tests if Omnis is running in the background, that is, it sets the flag ifOmnis is *not* the top application window.

The Linux environment, Windows environment and MacOSX all provide multi-taskingfacilities. When another program is running, with Omnis in the background, you cancontinue with tasks such as importing data although the processor's time becomes sharedbetween the current tasks. You can use this test to alter the behavior of the library whenit becomes the background task.
Example
*******

.. code-block:: omnis
	:linenos:	;  Bring Omnis back to the front when another application;  goes to topShow Omnis minimizedCalculate #F as kFalseWhile flag false    Test if running in backgroundEnd WhileShow Omnis normal
