﻿POP3RecvMessage
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3RecvMessage** (*socket*,*messagenumber*,*message*[,*stsproc*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**POP3RecvMessage** reads a message stored on a POP3 server. Themessage must not be marked for deletion.

*Socket* is an Omnis Long Integer field containing a socket opened to a POP3 serverusing *`POP3Connect 
`_
*.

*MessageNumber* is an Omnis Long Integer field which identifies the message to beread. Message numbers are assigned by the POP3 server, after you call *POP3Connect, *startingwith 1 for the first message, 2 for the second, and so on.

*Message *is an Omnis Binary or Character field which receives the message. Note that you canpass the result to *`MailSplit <mailsplit.html>`_
, *in order to parse themessage. For correct results with manyof the encodings supported by *`MailSplit <mailsplit.html>`_
* you must receive into a Binary field.

*StsProc* is an optional parameter containing the name of an Omnis method that **POP3RecvMessage**calls with status messages. **POP3RecvMessage** calls the method with noparameters, and the status information in the variable #S1. The status information logsprotocol messages exchanged on the connection to the server.

*Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Read the first message stored on the POP3 server lServer for user;  lUserNameCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocketPOP3RecvMessage (iSocket,1,lMessage) Returns lStatus
