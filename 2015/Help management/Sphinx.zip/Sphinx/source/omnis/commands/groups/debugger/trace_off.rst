﻿Trace off
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Trace off**
Description
***********
This command turns off the trace mode at a point in a method. See *`Trace on <trace_on.html>`_
* for more information about trace mode and using thedebugger.
Example
*******

.. code-block:: omnis
	:linenos:	Open trace log;  the following lines are sent to the trace log ...Trace on (Clear trace log)For lCount from 1 to 5 step 1    OK message  {Sent to trace log}End ForTrace off;  ...and the following line is notOK message  {Not sent to trace log}
