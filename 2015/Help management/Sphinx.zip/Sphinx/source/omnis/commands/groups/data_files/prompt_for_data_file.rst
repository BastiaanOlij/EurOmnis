﻿Prompt for data file
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |YES |NO |NO |All |

Syntax
******
**Prompt for data file** ([*Do not close other data*][,*Read-only*][,*No conversion by runtime*][,*Convert without user prompts*][,*Full Unicode conversion*]) {[*internal-name*] or *odb*://[*address*:*port*][,*internal-name*]}

Options
*******|Do not close other data |If specified,the command does not close all open data files before opening the specified data file |
|Read-only |If specified,the data file is opened in read-only mode |
|No conversion by runtime |Omnis normally offers to convert data files created by an earlier version of Omnis. If this option is specified,the runtime version of Omnis will not offer to convert the file,and the command will fail |
|Convert without user prompts |If specified,and conversion is allowed, Omnis will immediately perform the conversion without giving the user any prompts that require a response; also, the user cannot cancel the conversion |
|Full Unicode conversion |Unicode Studio only.If specified,and convert without user prompts is specified,do full Unicode conversion instead of quick conversion (quick conversion is only ok when you know all character data in the file is 7 bit) |

Description
***********
This command prompts the user to enter the name of a data file. A dialog box isdisplayed that lets the user choose a data file. An error message e.g. &quot;Unable to finddata file&quot; is generated if the selected file cannot be opened, and the user is forcedto select another file name or Cancel. If the user selects Cancel, the flag is cleared andthe original data file remains selected.

The selected file is opened in shared mode unless the volume does not support recordlocking.

The existing open data files remain open if the **Do not close other data** optionis selected. In this case, the new data file becomes the &quot;current&quot; data file andthis becomes the default data file for file classes which have not been associated with aparticular data file using the *`Set default data file <set_default_datafile.html>`_
*command. If the **Do not close other data** option is not specified, all other opendata files are closed even if the command fails.

If an attempt is made to open a data file which is already open, that data file isclosed and reopened. The **Read-only Studio/Omnis 7** check box causes the data fileto be opened in read-only mode. This lets you open an Omnis 7 data file in read-only modein Omnis Studio without conversion taking place.

If you select the **No conversion by runtime** option, and the data file wascreated with a previous version of Omnis, then the runtime version of Omnis will notconvert the data file. The default is that an Omnis runtime will ask the user if they wantto convert the data file.

If the data file is to be accessed using the ODB (Omnis Data Bridge), then you indicate thisusing a special syntax:
<ul>  <li>**odb://[address:port]**</li></ul>
where *address:port* is the TCP/IP address and port numberof the ODB server, e.g.  127.0.0.1:5900.  Omnis opens a dialog that allows you to select a data filehandled by the ODB server. You can omit address:port, in which case Omnis uses the address and port stored in the`$odbserver <../../../notation/root/prefs.html>`_
 root preference.  Note that the value of`$odbserver <../../../notation/root/prefs.html>`_
 is stored in the file odb.txt in the studiofolder of the Omnis installation tree.
Example
*******

.. code-block:: omnis
	:linenos:	Test if file exists {Orders.df1}If flag true    Open data file {Orders.df1}Else    Prompt for data file    If flag false        Quit method     End IfEnd If;  Example 2 - Prompt for a data file on a specific ODB serverPrompt for data file {odb://127.0.0.1:5900};  Example 3 - Prompt for a data file using the ODB server identified by $prefs.$odbserverPrompt for data file {odb://}
