﻿Set import file name
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |YES |NO |All |

Syntax
******
**Set import file name** {*file-name*}
Description
***********
This command specifies the name of the import file. The flag is set if the import fileis successfully selected. You use the current import file in any subsequent `Import field from file <import_field_from_file.html>`_
 commands.

If you use **Set import file name** in a reversible block, the import fileis closed when the method containing the reversible block terminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  import from a csv file called myImport.txt in the root of your omnis treeCalculate lImportPath as con(sys(115),'myImport.txt')Set import file name {[lImportPath]}Prepare for import from file {Delimited (commas)}Import data lImportListEnd importClose import file
