﻿If canceled
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**If canceled** ([*No refresh*])

Options
*******|No refresh |If specified,the command does not refresh the screen; this may result in improved performance on some platforms, especially when the command is used in each iteration of a loop |

Description
***********
This command tests whether the user wishes to cancel execution of the current method, and branches if not.  The user requests a cancel by either clicking on a working message Cancel button, or by pressing Ctrl-Break under Windows, Ctrl-C under Linux, or Cmnd-period under MacOSX. If *`Enablecancel test at loops <enable_cancel_test_at_loops.html>`_
* is switched on, a loop or other processing may detect a cancel and quit allmethods before it is detected by an **If canceled** command.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate #F as 1Disable cancel test at loopsWorking message  (Cancel button) {Doing some work}Repeat    Redraw working message    If canceled        OK message  (Icon,Sound bell) {Method Terminated.}        Quit method     End IfUntil flag false
