﻿Quit Omnis
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Quit Omnis** ([*Force quit*])

Options
*******|Force quit |If specified,Omnis will force all instances to close,even if they have $canclose methods that would prevent them (and therefore Omnis) from closing |

Description
***********
This command quits Omnis closing all libraries and data files. It is equivalent to the **Exit/Quit**option in the **File** menu. However, if the **Force quit** option is notchecked **Quit Omnis** will set the flag false and do nothing if an instanceor library cannot be closed.

If the **Force quit** check box is checked Omnis will force any class instances toclose so that the quit can take place, even if they have custom $canclose logic whichwould normally prevent them from closing.

This command can also be executed in a Web Client method running on the client.  It only does anything in theOmnis Web Client running on Windows Mobile, where it quits the client application; the **Force quit** checkbox has no affect.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user to quit omnisYes/No message  {Do you want to quit Omnis?}If flag true    Quit Omnis (Force quit)     ;; closes all instances and tasks, then quits OmnisEnd If
