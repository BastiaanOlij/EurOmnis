﻿Close import file
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |NO |NO |NO |All |

Syntax
******
**Close import file**
Description
***********
This command closes the current import file. You should use it once the data has beenread in.
Example
*******

.. code-block:: omnis
	:linenos:	;  import from a csv file called myImport.txt in the root of your omnis treeCalculate lImportPath as con(sys(115),'myImport.txt')Set import file name {[lImportPath]}Prepare for import from file {Delimited (commas)}Import data lImportListEnd importClose import file
