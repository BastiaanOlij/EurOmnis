﻿Execute SQL script
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Execute SQL script**
Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.