﻿Import fields
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Import fields** (*Insert records*|*Update records*[,*Indirect*][,*Disable messages*]) {*list-of-field-names* (Name1,Name2,...)}

Types
*****|Insert records |The command inserts new records |
|Update records |The command searches for existing records in the file and updates the records that it finds; data for which there is no matching record is ignored |


Options
*******|Indirect |If specified,the command uses the contents of the first field as the list of fields |
|Disable messages |If specified,the command does not open messages requiring a user response,and instead it writes a limited amount of information to the trace log |

Description
************
***Import fields*** *imports the data for the list of fields fromthe current import file into the data file. It provides runtime access to thefunctionality of the import data dialog in the IDE. The command sets the main file for theimport to the file corresponding to the first field in the list.

The **Insert records** option causes the command to insert new records for thedata in the file being imported.

The **Update records** option causes the command to search for an existing recordin the data file, for each record in the file being imported, and then update that record.Import records for which there is no matching record in the data file are ignored.
Example
*******

.. code-block:: omnis
	:linenos:	;  import from a csv file called myImport.txt in the root of your omnis treeCalculate lImportPath as con(sys(115),'myImport.txt')Set import file name {[lImportPath]}Prepare for import from file {Delimited (commas)}Import fields (Insert records) {fCustomers.Surname,fCustomers.FirstName}End importClose import file
