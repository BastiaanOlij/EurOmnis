﻿Move file
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Move file** (*from*-*path*, *to*-*path*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command moves the file specified in *from-path* to the folder named in *to-path*.It returns an error code (values are listed at the end of this Appendix), or zero if noerror occurs. The *to-path* is the path to destination folder into whichthe file will be moved. The command may fail if the *to-path* directory contains a file with the same name as *from-path*filename.
*
Move file* cannot move a file across volumes (disks). Use *`Copyfile <copy_file.html>`_
* and *`Delete file <delete_file.html>`_
* instead. *Move file* cannot move directories.
Example
*******

.. code-block:: omnis
	:linenos:	;  Prompt the user for a file to move together with a path;  to move to and move the fileDo FileOps.$putfilename(lPathname,'Select a file for moving','') Returns lReturnFlagIf lReturnFlag    Do FileOps.$selectdirectory(lNewPath,'Path to move to') Returns lReturnFlag    If lReturnFlag        Move file (lPathname,lNewPath) Returns lErrCode    End IfEnd If
