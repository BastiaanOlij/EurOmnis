﻿TCPGetRemoteAddr
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPGetRemoteAddr** (*socket*) **Returns** *address*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**TCPGetRemoteAddr** returns the IP address of the remote computer towhich a given socket is connected.
*
Socket* is an Omnis Long Integer field containing a connected socket.
*
Address* is an Omnis Character field which receives the IP Address of the host towhich the socket is connected. The IP address is of the form 255.255.255.254

Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Listen for a incoming connections on port iPort and get the IP;  address iAddress of the remote computerCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPListen (iSocket) Returns lStatusIf lStatus=0    Repeat        TCPAccept (iSocket) Returns lConnectedSocket    Until lConnectedSocket&gt;=0    TCPGetRemoteAddr (lConnectedSocket) Returns iAddressEnd IfTCPClose (iSocket) Returns lStatus
