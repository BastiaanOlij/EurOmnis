﻿Delete line in list
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Delete line in list** {*line-number* (*calculation*)}
Description
***********
This command deletes the specified line of the current list by moving all the linesbelow the specified line up one line. If the line number is not specified or if itevaluates to 0, the current line *LIST.$line* is deleted. The line in a list selectedby the user can determine the value of LIST.$line and is the line deleted if no parametersare specified. LIST.$line is unchanged by the command unless it was the final line andthat line is deleted; in this case LIST.$line is set to the new final line number. Thecommand never releases any of the memory used by the list.

The flag is cleared if the list is empty or if the line is beyond the current end ofthe list; otherwise, the flag is set.
Example
*******

.. code-block:: omnis
	:linenos:	;  Delete all but the first 2 lines in the listSet current list lMyListDefine list {lName,lAge}Add line to list {('Fred',10)}Add line to list {('George',20)}Add line to list {('Harry',22)}Add line to list {('William',31)}Add line to list {('David',62)}While lMyList.$linecount&gt;2    Delete line in list {1}End While;  Alternatively you can use $remove to delete a line from a listDo lMyList.$remove(1)
