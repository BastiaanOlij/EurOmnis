﻿WebDevGetSecureError
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**WebDevGetSecureError** () **Returns** *errortext*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

If you are using, or attempting to use, a secure connection to a server, the OpenSSL library (that provides theability to establish secure connections) may return useful error text.  When this occurs, the Web command returns theerror code -1021.  You can use **WebDevGetSecureError** to return this error text.

Omnis maintains a separate copy of the secure error text, for each thread in the multi-threaded server.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword,&quot;&quot;,kTrue) Returns iSocketIf iSocket=-1021    WebDevGetSecureError  Returns lSecureErrorTextEnd If
