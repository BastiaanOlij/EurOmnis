﻿Case
####
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Case ***constant-value* or *expression*****
Description
***********
The **Case** statement is part of a *`Switch <switch.html>`_
*construct that chooses one of an alternative set of options. The options in a *`Switch <switch.html>`_
* construct are defined by the subsequent **Case**commands. The **Case** command takes either a constant, field name, singlecalculation, or a comma-separated series of calculations. You must enclose string literalsin quotes. Date values must match the date format in *#FDT*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Show the direction lPosition equals. eg. if lPosition equals 3 show 'South' in the ok messageSwitch lPosition    Case 1        Calculate lDirection as 'North'    Case 2        Calculate lDirection as 'East'    Case 3        Calculate lDirection as 'South'    Case 4        Calculate lDirection as 'West'End SwitchOK message  {Position [lCount] = [lDirection]};  Multiple conditions can be used in a comma-separated list to one Case statement.;  Default is used to specify commands that should run if the value is not one of;  those specified in the Case statementsSwitch lDirection    Case 'North','South'        OK message  {The direction is North or South}    Case 'East','West'        OK message  {The direction is East or West}    Default        OK message  {The direction is Unknown}     ;; ;  lDirection is none of the aboveEnd Switch
