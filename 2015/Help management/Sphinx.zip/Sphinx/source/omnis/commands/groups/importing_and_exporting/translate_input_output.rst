﻿Translate input/output
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Translate input/output** ([*Enabled*])

Options
*******|Enabled |On the Windows platforms,specify this option to enable conversion to and from the OEM character set,when printing,importing or exporting text |

Description
***********Not supported in Omnis Studio 5.0 and later.