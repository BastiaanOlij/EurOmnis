﻿While calculation
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**While ***calculation*****
Description
***********
This command starts a **While***&#150;`End While <end_while.html>`_
*loop that continues while a calculated condition remains true. When the condition is notsatisfied the method jumps out of the loop and the first command after the closing *`End While <end_while.html>`_
* is executed. A loop that begins with a **While**command must terminate with an *`End While <end_while.html>`_
* otherwise anerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lCount as 1While lCount&lt;=3     ;; While loop    Calculate lCount as lCount+1End WhileOK message  {Count=[lCount]}     ;; prints ‚ÄòCount=4‚Äô
