﻿Find
####
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Find** **on ***field-name***** ([*Exact match*][,*Use search*]) {*calculation*}

Options
*******|Exact match |If specified,the index value of the field in suitable records must equal the current value |
|Use search |If specified,the command uses the current search to select data |

Description
***********
This command builds a find table and locates the first record in the table, that is, itloads the main and connected files into the current record buffer. The flag is false andthe buffer is cleared if no record is found.

You use the* ***Find** command to locate records within a file. Ifyou don&#146;t use a search, the file is searched in the order specified by the indexedfield until the value given in the calculation line is matched. In this case, the currentfind table is the same as the chosen Index.

When the closest match is found, the main and connected files are read into the currentrecord buffer and the flag is set true. If the indexed field is from a connected file, thesearch is repeated automatically until the record having a connected entry in the mainfile is found.

A blank calculation indicates that the **Find** is to be performed usingthe current value of the selected index field. Thus, if you precede the command with a *`Clear main file <../../../commands/groups/files/clear_main_file.html>`_
, *it isthe same as a *`Find first <find_first.html>`_
.
*
Omnis can perform a **Find** with an **Exact match** requirement. Inthis case, the value in the &quot;field found&quot; record must correspond in every detail(for example, upper or lower case characters) to the current value of the indexed field inthe current record buffer. A flag true indicates a successful Find, otherwise a flag falseresults, and the main and its connected files are cleared.

You use the exact match option to locate child records connected to a current parentrecord.
**
Clearing the find table
**
The find table is cleared if: <ol>  <li>A *`Clear find table <clear_find_table.html>`_
* command is executed with    the same main file setting.</li>  <li>A new *Find* is carried out on the same file.</li>  <li>A *`Next <next.html>`_
*/*`Previous 
`_
* command    with a new (non-blank) index or a **Use Search** or **Exact match** option where    the original **Find** had none, is used.</li></ol>Example
*******

.. code-block:: omnis
	:linenos:	;  Find all invoices belonging to account lMyAccCodePrompt for input Account Code ? Returns lMyAccCode (Cancel button)If flag true    Set main file {fInvoices}    Set search as calculation {fInvoices.AccCode=lMyAccCode}    Find on fInvoices.InvNum (Exact match,Use search)    While flag true        OK message  {Found Invoice [fInvoices.InvNum] for account [fInvoices.AccCode]}        Next     End WhileEnd If
