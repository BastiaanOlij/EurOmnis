﻿Clear check data log
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |NO |NO |NO |All |

Syntax
******
**Clear check data log**
Description
***********
This command clears the check data log, which stores all the results of a check dataoperation. To clear the log, there is no need for the log to be open.
Example
*******

.. code-block:: omnis
	:linenos:	Check data (Check records) {fOrders}If flag true    Yes/No message  {View Log?}    If flag true        Open check data log        ;  after checking through the log...        Yes/No message  {Clear the log?}        If flag true            Clear check data log        End If    End IfElse    OK message Error (Icon) {The check data file command could not be carried out//Please make sure that only one user is logged on to the datafile}End If
