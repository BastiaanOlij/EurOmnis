﻿Uncheck menu line
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Uncheck menu line** *line* or *instance-name*/*line*
Description
***********
This command removes the check mark on the specified line of a menu instance. No actionis taken if there is no check mark or the menu instance is not installed. You specify the *menu-instance-name*and the *line-number* of the menu line you want to uncheck.

If you use **Uncheck menu line** in a reversible block, the specified menuline is checked again when the method terminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  Test whether a line in the menu instance is checked and;  either check or uncheck it accordingly.Install menu mViewTest for menu line checked mView/LargeIf flag true    Uncheck menu line mView/LargeElse    Check menu line mView/LargeEnd If;  Alternatively, you change the $checked property of a line;  in the menu instance using notationDo $imenus.mView.$objs.Large.$checked.$assign(kFalse)
