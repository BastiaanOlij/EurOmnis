﻿Do method
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Do method ***method-name* (*parameters*)** Returns ***return-value*****
Description
***********
This command runs the specified method in the current class, and accepts a value backfrom the called method. If you use the **Do method** command in a field orline method, Omnis searches for the specified method in the field or line methods for theclass, and then searches in the class methods. If the specified method is not found thereis an error.

The command accepts a value back from the recipient or receiving method if you specifya *return-value*, which can be a variable of any type. Note that where the returnfield is an item reference, the command sets the reference but does not assign to it: youmust do this with `Calculate <../../../commands/groups/calculations/calculate.html>`_
or *`Do <../../../commands/groups/calculations/do.html>`_
Itemref.$assign(value).
*
When another method is executed using this command, control is passed to the calledmethod. When the called method has executed, control passes back to the original executingmethod. Note that you should use `Do code method <do_code_method.html>`_
 ifyou want to run a method in a code class, that is, a method outside the current class.
**
Passing Parameters**

You can include a list of parameters with **Do method** which are passedto the called method. The parameters are taken in the order they appear in the parameterlist and placed in the parameter variables in the called method. You can pass a referenceto a field by using the special parameter variable type Field reference. This means thatthe called method can make changes to the field passed to it. 
**
Recursion
**
Omnis allows a method to call itself, but will eventually run out of stack if therecursion does not terminate, or becomes too deep.
Example
*******

.. code-block:: omnis
	:linenos:	;  Call the method myMethod in the current instance which;  returns a value into iMyVar using Quit method lReturnValueDo method myMethod Returns iMyVar;  Call myMethod and pass the field reference iMyFieldRef;  so that the value of iMyFieldRef can be changed by the;  method calledCalculate iMyFieldRef as 10Do method myMethod (iMyFieldRef);  You can use $cinst, $cfield, and $ctask to specify a method;  in the current instance, field, or task.Do method $cinst.$mymethodDo method $cfield.$myfieldmethodDo method $ctask.$mytaskmethod;  You can also use the do command to call a methodDo $cinst.$mymethod
