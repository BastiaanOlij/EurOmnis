﻿Classes
#######
`Command Index <../command_index.html>`_


`Commands
******** <classes#commands>`_
|`Close all designs <classes/close_all_designs.html>`_  |`Close design <classes/close_design.html>`_  |`Delete class <classes/delete_class.html>`_  |`Duplicate class <classes/duplicate_class.html>`_  |
|`Modify class <classes/modify_class.html>`_  |`Modify methods <classes/modify_methods.html>`_  |`New class <classes/new_class.html>`_  |`Print class <classes/print_class.html>`_  |
|`Rename class <classes/rename_class.html>`_  |`Revert class <classes/revert_class.html>`_  |`Save class <classes/save_class.html>`_  |`Set class description <classes/set_class_description.html>`_  |

