﻿Clear line in list
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Clear line in list** {*line-number* (*calculation*)}
Description
***********
This command clears the values stored in the specified line of the current list. Youcan specify the line number in a calculation, otherwise the current line (*LIST.$line*)is used. The flag is cleared if the list is empty or if the line is beyond the current endof the list.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear values from any lines in the list that have a;  balance equal to zeroSet current list lMyListDefine list {lName,lBalance}Add line to list {('Fred',100)}Add line to list {('George',0)}Add line to list {('Harry',50)}For each line in list from 1 to lMyList.$linecount step 1    If lst(lBalance)=0        Clear line in list    End IfEnd For;  Alternatively you can use $clear to clear the values;  of a particular lineDo lMyList.1.$clear()
