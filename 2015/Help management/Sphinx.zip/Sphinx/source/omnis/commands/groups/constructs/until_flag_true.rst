﻿Until flag true
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Until flag true**
Description
***********
This command terminates the *`Repeat <repeat.html>`_
&#150;Until*conditional loop if the flag is true; execution continues with the command following the *Until*command. If the flag is false, execution continues with the command following the `Repeat <repeat.html>`_
 command.
Example
*******

.. code-block:: omnis
	:linenos:	;  loop until 'Yes' is pressedRepeat    Yes/No message  {Press Yes to exit loop}Until flag true
