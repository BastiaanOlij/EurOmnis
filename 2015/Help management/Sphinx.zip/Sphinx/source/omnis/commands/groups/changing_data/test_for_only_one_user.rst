﻿Test for only one user
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for only one user** ([*All data files*])

Options
*******|All data files |If specified,all data files are tested,rather than just the current data file |

Description
***********
This command tests whether the current data file is being used by a single user, and ifso sets the flag.

If the **All data files** check box option is selected, all open data files aretested for a single user. The flag is cleared if any one data file has more than one user.

If the flag is set, further workstations are prevented from logging on to the testeddata file(s) until the method containing the test command is terminated. The workstationswill see a padlock cursor until the method terminates.

Omnis always sets the flag if the program is running in single user mode. UnderWindows, this means that the data is on a DOS volume without the SHARE command having beenrun.
Example
*******

.. code-block:: omnis
	:linenos:	Test for only one userIf flag false    OK message  {Sorry, option not allowed}    Quit method kFalseEnd IfDo method Invoices/InsertNew
