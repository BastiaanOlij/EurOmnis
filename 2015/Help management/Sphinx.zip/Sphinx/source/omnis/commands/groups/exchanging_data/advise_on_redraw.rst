﻿Advise on redraw
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Advise on redraw** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command determines when Omnis is permitted to sendrequested Advise messages to the client program. When Advise requests have been receivedfrom a client, the `Setserver mode <../../groups/exchanging_data/set_server_mode.html>`_
 command determines when Omnis is permitted to send field values thathave changed. In addition to the `Set server mode <../../groups/exchanging_data/set_server_mode.html>`_
options, the three commands *`Advise onFind/next/previous <advise_on_find_next_previous.html>`_
, `Advise on OK <advise_on_ok.html>`_
,* and **Adviseon redraw** let you toggle individual options on or off. The **Advise onredraw** command lets you control this particular option without affecting theother two.
Example
*******

.. code-block:: omnis
	:linenos:	Advise on redraw (Accept)     ;; enable advise on redrawAdvise on redraw     ;; disable advise on redraw
