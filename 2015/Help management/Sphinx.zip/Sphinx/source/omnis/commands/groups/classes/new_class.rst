﻿New class
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**New class** {*superclass-name* or *class-type*/*name*}
Description
***********
This command creates a new class with the specified type and class name. For example,you can use **New class** in association with *`Modifyclass <modify_class.html>`_
* to allow users to create new search and report classes. Attempting to createa class with the same name as one which already exists clears the flag and displays anerror message.
Example
*******

.. code-block:: omnis
	:linenos:	New class {Window/wMywindow}Modify class {wMyWindow}
