﻿Put file name
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Put file name** (*path* [,*dialog*-*title*] [,*prompt*] [,*default*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command opens the standard Save as&#133; dialog for the current Operating System,in order to obtain the path of a file from the user. You would typically use this commandto prompt the user for the path of a new file. If you want to prompt the user to enter thepath of an existing file, use the *`Get file name <get_file_name.html>`_
*command instead.

You can pass a title for the dialog, in *dialog-title*. You canspecify a default value for the entry field in *default*.
*
Put file name* returns the full pathname of the file the user entered in *path*,or empty if no file was entered (that is, the Cancel button was clicked). The named fileis not opened or created.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  prompt the user for a file name, default to myfile.txtPut file name (lPathname,'select a file','','myfile.txt') Returns lErrCodeIf len(lPathname)=0    ;  cancel button pressedElse    ;  file name enteredEnd If
