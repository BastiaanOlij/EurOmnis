﻿Send Core event
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |NO |NO |MacOSX |

Syntax
******
**Send Core event** *message* (*parameters*)

Messages
********|Quit Application | |
|Create Publisher | |
|Set Data | |
|Do Script | |
|Open Documents | |
|Print Documents | |

Description
***********
This command sends one of the &quot;Core&quot; events. The event is sent to the currentevent recipient unless an application name is provided as a parameter. Note that *Openapplication*, *Quit application, Open Document *and* Print Document* arecompulsory events and will be accepted by an Apple-event-aware recipient at all times. Toreturn a value use *`Send Core event with returnvalue <send_core_event_return.html>`_
*.

You can disable the compulsory events using the *Disable receiving of Apple events*command with the **Disable compulsory events** option checked.
Example
*******

.. code-block:: omnis
	:linenos:	;  Quit Application is a compulsory event and always responded to by an Apple event aware;  application. This quits the named application in the Application menu.  If no parameter is given;  the current recipient quits by default.Send Finder event {Open Files ('MyHD:TeachText')};  use TeachTextOK message  {Now quit TeachText};  this will now quit TeachText and reset Omnis by defaultSend Core event Quit Application ('MyHD:TeachText');  Open Documents loads the named documents into the target application.  If received by;  Omnis, the event uses the Open Library item in the File menu to open each library in turn.;  If the documents are ad-hoc reports, they are opened.Send Core event Open Documents ('MyHD:MyPath:Doc1');  Print Documents loads the named documents into the target application and prints each one.;  If the documents are ad-hoc reports, they are opened and printedSend Core event Print Documents ('MyHD:MyPath:Doc1','MyHD:MyPath:Doc2');  Create PublisherSend Core event Create Publisher ('Object','Edition Name');  Create Publisher sends a request to the current recipient to publish the Object (eg: a document,;  spreadsheet or other database), so that your Omnis library can use the data in the Edition NameSend Core event Create Publisher ('MySheet','MonthResults');  Set DataSend Core event Set Data ('TargetField','SourceField');  Set Data sends an event to the current recipient that takes the data in SourceField and puts it in;  TargetField.  (NB: If SourceField is quoted the actual string is passed into TargetField.);  This pushbutton method takes the data in the field iCharField and puts it into a spreadsheet cell.On evClick    Set current list iList    Send Core event Set Data ('R1:C1',iCharField)    If flag false        OK message Error {Error sending core event}    End If    Quit event handler        ;  Do Script    ;  Do Script sends a script to the current recipient which will be executed.  When sending methods    ;  to Omnis, the Do Script message is only accepted when Omnis is not already executing a method    ;  or performing an operation.  If an event is not accepted, errAEEventNotHandled is returned to    ;  the sender. When sent to another Apple application such as Hypercard, a script must use    ;  the script language and syntax of that application.        ;  The following pushbutton method assumes a script has been entered in the field iScript.    ;  If the script can be run by the current recipient (local Omnis by default), the results can be seen;    ;  otherwise the OK error message appears.    On evClick    Send Core event Do Script (iScript)    If flag false        OK message Error {Do script Failed}    End If    Quit event handler
