﻿Call DLL
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Call DLL** (*library*, *procedure* [,*parameters...*]) **Returns** *return-value*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command calls a procedure in a DLL, which you must have previously registered bycalling **`Register DLL <register_dll.html>`_
**. The *library* isthe name or pathname of the DLL containing the procedure specified by *procedure*; *library* and *procedure* must exactlymatch the values passed to **`Register DLL <register_dll.html>`_
**. The *parameters*are passed to the procedure when it is called, and must match the *type-definition* passed to **`Register DLL <register_dll.html>`_
**.  The return value of *Call DLL* is the return value of *procedure*, and has the type specified by the *type-definition*.
Example
*******

.. code-block:: omnis
	:linenos:	;  Flash the Omnis window to attract the user's attention;  Win32 API to get the main Omnis window: HWND GetActiveWindow(VOID)Register DLL ('USER32.DLL','GetActiveWindow','J') Call DLL ('USER32.DLL','GetActiveWindow') Returns lHWND;  Win32 API to Flash a window: BOOL FlashWindow(HWND, BOOL)Register DLL ('USER32.DLL','FlashWindow','JJJ') Call DLL ('USER32.DLL','FlashWindow',lHWND,1) Returns lResult;  Activate a system beep;  MacOSX framework to activate a system beep: CarbonSound.frameworkCalculate lPath as &quot;/System/Library/Frameworks/Carbon.framework/Versions/Current/Frameworks/CarbonSound.framework/Versions/Current/CarbonSound&quot;Register DLL (lPath,'SysBeep','JJ') Call DLL (lPath,'SysBeep',10) 
