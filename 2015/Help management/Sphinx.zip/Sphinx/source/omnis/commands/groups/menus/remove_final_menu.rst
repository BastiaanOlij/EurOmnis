﻿Remove final menu
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Remove final menu**
Description
***********
This command removes the final or right-most menu instance from the menu bar, *excluding*the standard Omnis menus such as **File**** **and **Edit**. If you use **Removefinal menu** in a reversible block, the final menu instance is reinstalled when themethod containing the block terminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  Remove the last menu installedBegin reversible block    Remove final menuEnd reversible blockOK message  {Menu is now removed};  now the final menu is reinstalled
