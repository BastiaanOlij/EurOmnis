﻿Find last
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Find last** **on ***field-name***** ([*Use search*][,*Use sort*])

Options
*******|Use search |If specified,the command uses the current search to select data |
|Use sort |If specified,the command uses the current sort field(s) to order the data |

Description
***********
This command automatically locates and displays the last record in a file using aspecified indexed field. You can use the *Find last* command to locate the lastrecord added to a file by using the record sequencing number as the index. The flag is setfalse if no record is found.

You use the **Use search** option in conjunction with the specified indexed fieldto select the *last* record which fulfills the search specification. If the search isa calculation, the optimizer will choose the best index if the index field is left blank.

Whenever you use a *`Find <find.html>`_
* command, a find table is createdwhich determines the order in which records are displayed using subsequent *`Next <next.html>`_
* and *`Previous 
`_
* commands. Oncea find table has been created, subsequent* Next* or *Previous *commands will usethe table provided the commands have an empty or the same Index, and the same (or empty) **Search**and **Exact match** conditions. A *`Clear find table <clear_find_table.html>`_
*,a new *Find* on the same file or *`Next <next.html>`_
/`Previous 
`_
* commands with a new (non-blank) index or a Search orExact match where the original *Find* had none, will clear the find table.

The **Use Sort** option works in conjunction with the current sort fields (see *Setsort field*) to create a table of entries from the data file which are sorted into anorder set by up to 9 sort fields. Refer to the *`Find <find.html>`_
* commandfor details of the find table and its use.
Example
*******

.. code-block:: omnis
	:linenos:	;  Find the last account record in the file, but restore;  the original record when this method finishesBegin reversible block    Set main file {fAccounts}    Find last on fAccounts.Code (Use search)End reversible block
