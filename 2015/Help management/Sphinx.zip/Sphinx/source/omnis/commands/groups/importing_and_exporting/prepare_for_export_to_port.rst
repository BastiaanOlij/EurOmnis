﻿Prepare for export to port
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Prepare for export to port** {*export-format*}

Export Formats
**************|Delimited (commas) | |
|Delimited (tabs) | |
|One field per line | |
|Omnis data transfer | |
|Delimited (user delimiter) | |

Description
***********
This command prepares to export records to a port in one of the specified data formats.The file must previously have been set using `Set port name <../../groups/report_destinations/set_port_name.html>`_
 or `Prompt for port name <../../groups/report_destinations/prompt_for_port_name.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  export to port Com1Set port name {COM1:}Prepare for export to port {Delimited (commas)}Export data lExportListEnd export
