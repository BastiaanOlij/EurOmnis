﻿End import
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |NO |NO |NO |All |

Syntax
******
**End import**
Description
***********
This command ends the import of data without closing the port, DDE channel, or filethrough which data is being imported.
Example
*******

.. code-block:: omnis
	:linenos:	Prompt for import filePrepare for import from file {Delimited (commas)}Import data lImportListEnd importClose import file
