﻿Queue quit
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue quit**
Description
***********
This command queues a quit event. It simulates the user selecting the **Exit/Quit**option in the **File** menu. In enter data mode, a *`Queue OK <queue_ok.html>`_
*or `Queue Cancel <queue_cancel.html>`_
 should precede a **Queuequit** to close the enter data correctly.
Example
*******

.. code-block:: omnis
	:linenos:	;  button method to terminate data entry and quitIf flag true    Queue OK    Queue quitElse    Queue cancel    Close top windowEnd If
