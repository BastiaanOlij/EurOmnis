﻿Close check data log
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |NO |NO |NO |All |

Syntax
******
**Close check data log**
Description
***********
This command closes the check data log if it is open. The command is not reversible andthe flag is not affected.
Example
*******

.. code-block:: omnis
	:linenos:	Check data (Check records) {fOrders}If flag true    Yes/No message  {View Log?}    If flag true        Open check data log (Do not wait for user)    End If    ;  leave log window openElse    OK message Error (Icon) {The check data file command could not be carried out//Please make sure that only one user is logged on to the datafile}End If;  now close logClose check data log
