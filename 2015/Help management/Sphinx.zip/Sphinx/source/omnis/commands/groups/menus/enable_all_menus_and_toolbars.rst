﻿Enable all menus and toolbars
#############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |YES |NO |All |

Syntax
******
**Enable all menus and toolbars**
Description
***********
This command enables all menus and toolbars. It reverses the action of *`Disable all menus and toolbars <disable_all_menus_toolbars.html>`_
*. This commandwill not enable a menu which has been disabled by disabling line zero. Such a menu canonly be enabled by enabling line zero.
Example
*******

.. code-block:: omnis
	:linenos:	;  Enable all menus and toolbars if the correct;  password is enterdDisable all menus and toolbarsPrompt for input Password : Returns lPasswordIf low(lPassword)='password'    Enable all menus and toolbarsEnd If;  Alternatively, you can enable all user installed menu;  and toolbar instances by setting the $enabled propertyDo $imenus.$sendall($ref.$enabled.$assign(kTrue))Do $itoolbars.$sendall($ref.$enabled.$assign(kTrue))
