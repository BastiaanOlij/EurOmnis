﻿Disable enter &amp; escape keys
###############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Enter data <../enter_data.html>`_  |NO |YES |NO |All |

Syntax
******
**Disable enter &amp; escape keys**
Description
***********
This command disables the Enter key on all platforms; on Windows and Linux, it alsodisables the Escape key, whereas on MacOSX it also disables the Escape key and Cmnd-period.In other words, it disables the keyboard equivalents of the OK and Cancel pushbuttons. Forexample, you can use it during enter data mode to prevent the user from prematurelyupdating records by hitting the Enter key, when they attempt to start a new line. Theoption will remain set until either it is reversed with an *Enable* command, a newlibrary is selected, or it is reversed as part of a reversible block.

Before using this command in a method that initiates an *`Enterdata <enter_data.html>`_
* command, ensure that the user has some way of ending data entry, that is, byinstalling an OK and a Cancel pushbutton, or by using a $control() method that detects theend of data entry.
Example
*******

.. code-block:: omnis
	:linenos:	;  $construct of window classBegin reversible block    Disable enter &amp; escape keysEnd reversible blockEnter data If flag true    OK message  {OK Button Pressed}End If
