﻿Message timeout
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Message timeout** {*interval* (seconds)}
Description
***********
This command specifies the time Omnis has to wait for DDE responses to messages sent toother applications. There is a default value of 30 seconds when Omnis is started.

The following general purpose method sets up a DDE channel by increasing the messagetimeout by 5 seconds until successful. You pass three parameters to the method, that is,the initial timeout, the channel number and the program 'name|document'.
Example
*******

.. code-block:: omnis
	:linenos:	;  open dde channel;  parameter pNum is short int;  parameter pChannel is short int;  parameter pProgDoc is characterSet DDE channel number {pChannel}Repeat    Message timeout {pNum}    Open DDE channel {[pProgDoc]}    If flag false        Yes/No message  {Give up 'Open DDE channel'?}        If flag true            Close DDE channel        End If    End If    Calculate pNum as pNum+5Until flag true
