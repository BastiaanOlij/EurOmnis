﻿Show 'About...' window
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |NO |NO |NO |All |

Syntax
******
**Show 'About...' window**
Description
***********
This command displays the standard &quot;About...&quot; window which is available as anoption in the **Help**** **menu under Windows and Linux, or the **Apple** menuunder MacOSX. You can change the standard &quot;About...&quot; screen with the *`Set 'About...' method <set_about_method.html>`_
 *command.
