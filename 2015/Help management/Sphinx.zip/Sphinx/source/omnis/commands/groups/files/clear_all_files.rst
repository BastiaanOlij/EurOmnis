﻿Clear all files
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear all files**
Description
***********
This command clears the current record buffer of all file variables for all openlibraries and all open data files, including any memory-only files. However, it does notclear the hash variables. Window instances are not automatically redrawn so you mustfollow it by *`Redraw <../../../commands/groups/fields/redraw.html>`_
 *if youwant the screen to reflect the current state of the buffer.

This command is reversible for read-only and read-write files; the command reverses by re-readingeach record into the current record buffer.  Note that using this command in a reversible blockwith a memory-only file will clear the current record buffer for that file when the command reverses.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear all file variables from the current record buffer and;  redraw the current window instanceClear all filesDo $cinst.$redraw()
