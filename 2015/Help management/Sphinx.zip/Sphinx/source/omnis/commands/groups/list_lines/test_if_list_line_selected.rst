﻿Test if list line selected
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Test if list line selected** {*line-number* (*calculation*)}
Description
***********
This command tests the specified line of the current list and sets the flag if it isselected. You can specify a particular line in the list by entering either a number or acalculation. If the number is not specified, the test is performed on the current line ofthe list, that is, the line number held in *LIST.$line*.
Example
*******

.. code-block:: omnis
	:linenos:	;  If line 2 is selected show a message dialogSet current list lMyListDefine list {lName,lBalance}Add line to list {('Fred',100)}Add line to list {('George',0)}Add line to list {('Harry',50)}Select list line(s) {2}Test if list line selected {2}If flag true    OK message  {List line 2 is selected}End If;  Alternatively, you can check the $selected propertyIf lMyList.2.$selected    OK message  {List line 2 is selected}End If
