﻿Else If flag true
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Else If flag true**
Description
***********
This command follows an *`If <if_calculation.html>`_
* statement andprovides a marker before a series of commands that have to be carried out if the flag istrue and if the value does not meet the condition specified in the *`If <if_calculation.html>`_
* statement.
Example
*******

.. code-block:: omnis
	:linenos:	;  use the Yes/No message to set or clear the flagYes/No message  {Set flag with Yes or No}If flag false    OK message  {flag is 0}Else If flag true    OK message  {flag is 1}End If
