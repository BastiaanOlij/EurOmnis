﻿Load from list
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Load from list** {*line-number* (*variable-names*) {default is current line}}
Description
***********
This command transfers field values from the current list to the corresponding fieldsin the current record buffer. However, if you include a list of fields, the values in thecurrent list are transferred to the specified fields (see example). Each column value,taken in the order it was defined, is copied to the corresponding field in the field list.

**Field names parameter list**

The command **Load from list** with '0 (CVAR1,,CVAR12)' specified willload the first column of the current line of the list into CVAR1, ignore the secondcolumn, and load the third column into LVAR12. If too few field names are specified, theother columns are not loaded. If too many field names are specified, the extra fields arecleared. Any conversions required between data types are carried out.

If the line number specified in the command line is empty, or if it evaluates to zero,the values are loaded from the current line. If the list is empty or if the line evaluatesto a value greater than the total number of lines in the list, the flag is cleared and thefields in the parameter list or in the list definition are cleared.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list lMyListDefine list {lName,lAge}Add line to list {('Fred',10)}Add line to list {('George',20)}Add line to list {('Harry',22)}Add line to list {('William',31)}Add line to list {('David',62)}Do lMyList.$line.$assign(4)     ;; set the current lineLoad from list     ;; load the values from the current line into lName and lAgeLoad from list {2}     ;; load the values from line 2 into lName and lAgeLoad from list {4 (lTmpName,lTmpAge)}     ;; load the values from line 2 into lTmpName and lTmpAge
