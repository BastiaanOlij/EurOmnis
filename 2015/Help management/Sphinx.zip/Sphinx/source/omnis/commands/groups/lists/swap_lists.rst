﻿Swap lists
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |NO |NO |All |

Syntax
******
**Swap lists** *list-or-row-name*
Description
***********
This command swaps the definition and contents of the specified list with that of thecurrent list and sets the flag. After this command, the current list contains the fieldsand data which were held in the specified list, and the specified list contains the fieldsand data which were in the current list.

This command cannot be used to copy lists. To do this use *`Calculate <../../groups/calculations/calculate.html>`_
 LIST2 as LIST1*.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iList1Define list {fCustomers}Build list from file Swap lists iList2;  Note: iList2 now contains the defintion and data from iList1 (the current list);  iList1 is now empty
