﻿UUDecode
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**UUDecode** (*stream*,*decoded-stream*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***UUDecode** turns Uuencoded information back into text or binaryinformation. It is the inverse of *`UUEncode <uuencode.html>`_
*. Uuencodedinformation is commonly sent over the Internet in a manner that preserves binaryinformation.
*
Stream* is an Omnis Character or Binary field containing the information to *UUDecode*.
*
DecodedStream *is an Omnis Character or Binary field that receives the resultingUudecoded representation of the *Stream* argument. Because Uuencoding is generallyused for binary information, a Binary field is the norm.
*
Status* is an Omnis Long Integer field which receives the value zero for success, oran error code &lt; 0 for failure. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  encode the contents of the character variable lString to get lEncodedString;  and decode lEnclodedString to get lString backCalculate lString as 'This is my character string to encode'UUEncode (lString,lEncodedString) Returns lErrCodeCalculate lString as ''UUDecode (lEncodedString,lString) Returns lErrCode
