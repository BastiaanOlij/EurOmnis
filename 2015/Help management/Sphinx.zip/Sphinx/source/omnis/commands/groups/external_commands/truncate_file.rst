﻿Truncate file
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Truncate file ** (*refnum* [,*end*-*position*] [,*end*-*position*-*is*-*character*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command truncates a file. You specify the file reference number returned by *`Open file <open_file.html>`_
 *in *refnum*. The file is truncated at thecurrent position of the file pointer or the specified *end-position* if given.  The *end-position* parameter represents a byte position, unless you pass *end-position-is-character* as a non-zerovalue, in which case it represents an operating system character position (a byte position when running on Linux, or a 16-bit character position when running on Win32 or MacOSX).

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if no error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  write the contents of the character variable 'lCharVar' to a text file;  named 'charfile.txt' in the root of the omnis tree and then truncate;  the contents to 8 bytesCalculate lPathname as con(sys(115),'charfile.txt')Create file (lPathname) Returns lErrCodeOpen file (lPathname,lRefNum) Calculate lCharVar as 'Truncate the contents of this file'Write file as character (lRefNum,lCharVar) Returns lErrCodeTruncate file  (lRefNum,8) Returns lErrCodeClose file (lRefNum) 
