﻿Yes/No message
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Message boxes <../message_boxes.html>`_  |YES |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Yes/No message** *title* ([*Icon*][,*Sound bell*][,*Cancel button*]) {*message*}

Options
*******|Icon |If specified,the message displays an operating system specific icon |
|Sound bell |If specified,the system bell sounds when the command displays the message |
|Cancel button |If specified,the message has a cancel button |

Description
***********
This command displays a message box containing the specified message and provides a **Yes**and a **No** pushbutton. You can include a Cancel button, and add a short *title*for the message box. For greater emphasis, you can select an **Icon** for the messagebox (the default &quot;info&quot; icon for the current operating system), and you canforce the system bell to sound by checking the **Sound bell** check box.Under Windows XP, you have to specify a system sound for a 'Question' in theControl Panel for the Sound Bell option to work.

When the message box is displayed method execution is halted temporarily; it remainsopen until the user clicks on one of the buttons before continuing. The **Yes**button is the default button and can therefore be selected by pressing the Return key.

The number of lines displayed in the message box depends on your operating system,fonts and screen size. In the message text you can force a break between lines (acarriage return) by using the notation &#145;//&#146;or the `kCr <../../../notation/root/constants/special_characters.html>`_
 constantenclosed in square brackets, e.g. 'First line[`kCr <../../../notation/root/constants/special_characters.html>`_
]Second line'.

You can insert a **Yes/No message** at any appropriate point in a method.If the user clicks the Yes button, the flag is set; otherwise, it is cleared. You can usethe *`msgcancelled() <../../../functions/groups/general/msgcancelled.html>`_
*function to detect if the user pressed the Cancel button.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open a Yes/No dialog and display the option selectedYes/No message My Editor (Icon,Cancel button) {Do you wish to save the changes you have made ?}If msgcancelled()    OK message My Editor {Cancel button pressed}Else    If flag true        OK message My Editor {OK button pressed}    Else        OK message My Editor {Cancel button pressed}    End IfEnd If
