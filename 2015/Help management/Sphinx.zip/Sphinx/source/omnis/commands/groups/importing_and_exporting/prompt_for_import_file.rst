﻿Prompt for import file
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |YES |NO |All |

Syntax
******
**Prompt for import file**
Description
***********
This command prompts the user to select the name of the import file. The flag is set ifthe import file is successfully selected, otherwise a Cancel clears the flag, closes thecurrent file and closes the dialog. You use the selected file in any subsequent *`Import data <import_data.html>`_
* commands.

If you use **Prompt for import file** in a reversible block, the importfile is closed when the method containing the reversible block terminates.
Example
*******

.. code-block:: omnis
	:linenos:	Prompt for import filePrepare for import from file {Delimited (commas)}Import data lImportListEnd importClose import file
