﻿Open data file
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |YES |NO |NO |All |

Syntax
******
**Open data file** ([*Do not close other data*][,*Read-only*][,*No conversion by runtime*][,*Convert without user prompts*][,*Full Unicode conversion*]) {*file-name*[,*internal-name*] or *odb*://[*address*:*port*:]*name*[,*internal-name*]}

Options
*******|Do not close other data |If specified,the command does not close all open data files before opening the specified data file |
|Read-only |If specified,the data file is opened in read-only mode |
|No conversion by runtime |Omnis normally offers to convert data files created by an earlier version of Omnis. If this option is specified,the runtime version of Omnis will not offer to convert the file,and the command will fail |
|Convert without user prompts |If specified,and conversion is allowed, Omnis will immediately perform the conversion without giving the user any prompts that require a response; also, the user cannot cancel the conversion |
|Full Unicode conversion |Unicode Studio only.If specified,and convert without user prompts is specified,do full Unicode conversion instead of quick conversion (quick conversion is only ok when you know all character data in the file is 7 bit) |

Description
***********
This command opens the specified data file and makes that file the &quot;current&quot;data file. It clears the flag if the data file cannot be found or opened. If the **Donot close other data** check box option is not specified, all existing data files areclosed even if the command fails. Opening a data file which is already open will close andreopen that data file. The **Read-only Studio/Omnis 7** check box causes the datafile to be opened in read-only mode. This lets you open an Omnis 7 data file in read-onlymode in Omnis Studio without conversion taking place.

If you select the **No conversion by runtime**** **option, and the data filewas created with a previous version of Omnis, then the runtime version of Omnis will notconvert the data file. The default is that an Omnis runtime will ask the user if they wantto convert the data file.

If an opened data file uses more than one segment, all segments are opened. The rulesfor finding the additional segments which form part of the data file are as follows: <ul>  <li>Under Windows and Linux, the paths given in the Omnis environment variable are searched;    if the file is not in any of these locations, then Omnis searches the directory containing    the first segment.</li>  <li>Under MacOSX, root directories of all mounted volumes are searched as well as the folders    containing the first segment and the most recently opened library.</li></ul>
You can override the default internal name by specifying your own in the parameter forthe command.

If the data file is to be accessed using the ODB (Omnis Data Bridge), then instead of using a pathname, you specify the location of the file using a special syntax:
<ul>  <li>**odb://[address:port:]name**</li></ul>
where *address:port* is the TCP/IP address and port numberof the ODB server, e.g.  127.0.0.1:5900, and *name* is the name of a data file accessed using theODB server.  You can omit address:port:, in which case Omnis uses the address and port stored in the`$odbserver <../../../notation/root/prefs.html>`_
 root preference.  Note that the value of`$odbserver <../../../notation/root/prefs.html>`_
 is stored in the file odb.txt in the studiofolder of the Omnis installation tree.
Example
*******

.. code-block:: omnis
	:linenos:	Open data file {Sales.df1,Sales}If flag true    Find first     If flag true        Open data file (Do not close other data) {Purch.df1,Purchases}        If flag true            Calculate fPurchases.Field1 as fSales.Field1            Prepare for insert with current values            Enter data             Update files if flag set        End If    End IfEnd If;  Example 2 - Transfer datafile 1 to datafile 2Open data file {pOrders.df1,pOrders1}If flag true    Set main file {fOrders}    Find first on fOrders.OrderNum    While flag true        Prepare for insert with current values        Open data file {pOrders2.df1,pOrders2}        Update files if flag set        Open data file {pOrders.df1,pOrders1}        Next on fOrders.OrderNum    End WhileEnd If;  Example 3 - Open a data file on a specific ODB serverOpen data file {odb://127.0.0.1:5900:test};  Example 4 - Open a data file using the ODB server identified by $prefs.$odbserverOpen data file {odb://test}
