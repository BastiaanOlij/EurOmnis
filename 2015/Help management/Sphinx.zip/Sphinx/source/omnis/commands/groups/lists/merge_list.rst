﻿Merge list
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |NO |NO |All |

Syntax
******
**Merge list** *list-or-row-name* ([*Clear list*][,*Use search*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to match the specified list,before executing |
|Use search |If specified,the command uses the current search to select data |

Description
***********
This command adds the specified list to the end of the list previously specified as thecurrent list. Once the list reaches its maximum size, the command finishes and clears theflag. Omnis does not check that the same fields are stored in the two lists (which theyshould be). If the same fields are not present, data is not transferred.

If you use the** ****Clear list** option, the current list is initially clearedand defined to hold the same fields as the specified list. This is the same as copying alist.

If you use the **Use search** option, only lines matching the search class aremerged or added to the current list. All lines match if there is no current search class.
Example
*******

.. code-block:: omnis
	:linenos:	;  To merge the list iList1 to the current list iList2Set current list iList2Set search name sMySearchMerge list iList1 (Clear list,Use search)If flag true    Sort listElse    OK message  {Merge failed at line [iList1.$linecount]}End If;  To append only selected linesSet current list iList2Set search as calculation {#LSEL}Merge list iList1 (Use search);  or do it like thisDo iList2.$merge(iList1)
