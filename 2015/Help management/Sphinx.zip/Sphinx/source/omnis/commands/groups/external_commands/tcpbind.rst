﻿TCPBind
#######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPBind** (*socket*,*service*|*port*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPBind** binds a socket created with *`TCPSocket <tcpsocket.html>`_
*to a particular local port.
*
Socket* is an Omnis Long Integer field, containing the number of the socket.
*
Service/Port* is either an Omnis integer field containing the number of the port towhich the socket should be bound, or an Omnis character field containing the name of aservice which will be resolved to a port number by a local lookup.
*
Status* is an Omnis Long Integer field which receives the value zero for success, oran error code &lt; 0 for failure. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Get the next available socket and bind it to port iPortCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatus
