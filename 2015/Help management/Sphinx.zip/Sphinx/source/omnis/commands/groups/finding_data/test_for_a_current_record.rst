﻿Test for a current record
#########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for a current record** {*file-name*}
Description
***********
This command tests for the presence of a current record from a specified file class.The flag is set if a current record for the file is found and cleared if not. The flag isalso cleared if the selected file is a memory-only or a closed file. The test is carriedout on the main file if no other file class is specified.
Example
*******

.. code-block:: omnis
	:linenos:	;  If a record for fAccounts does not exist in the current;  record buffer, get the firstSet main file {fAccounts}Test for a current record {fAccounts}If flag false    Find first End If
