﻿Find first
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Find first** **on ***field-name***** ([*Use search*][,*Use sort*])

Options
*******|Use search |If specified,the command uses the current search to select data |
|Use sort |If specified,the command uses the current sort field(s) to order the data |

Description
***********
This command automatically locates the first record in a file using the index for thespecified field. If no field is given, the record sequence number is used. The main andconnected files are read into the CRB if a valid first record is found. The flag is setfalse if no record is found.

You use the **Use search** option in conjunction with the specified indexed fieldto select the *first* record which fulfills the search specification. If the searchis a calculation, the optimizer will choose the best index if the index field is leftblank.

You use the **Use Sort** option in conjunction with the current sort fields (see *`Set sort field <../../../commands/groups/sort_fields/set_sort_field.html>`_
*) tocreate a table of entries from the data file which are sorted into an order set by up tonine sort fields.

The find table is cleared if: <ol>  <li>A *`Clear find table <clear_find_table.html>`_
* command is executed with    the same main file setting.</li>  <li>A new *`Find <find.html>`_
* is carried out on the same file.</li>  <li>A *`Next <next.html>`_
/`Previous 
`_
* command with a    new (non-blank) index or a **Use Search** or **Exact match** option where the    original *Find* had none, is used.</li></ol>
If you use the *Find first* command within a reversible block, it is reversed whenthe method finishes, that is, the main and connected records are restored. However, if thedata within the original record has been deleted or changed, it will not be possible tocompletely restore the buffer.
Example
*******

.. code-block:: omnis
	:linenos:	;  Find the first account with a negative balance, but restore;  the original record when this method finishesBegin reversible block    Set main file {fAccounts}    Set search as calculation {fAccounts.Balance&lt;0}    Find first on fAccounts.Code (Use search)End reversible block
