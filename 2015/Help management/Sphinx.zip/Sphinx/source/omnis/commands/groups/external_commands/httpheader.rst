﻿HTTPHeader
##########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**HTTPHeader** (*socket*,*status*,*headerlist*) **Returns** *length*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***HTTPHeader** is a server command that sends an HTTP standard headerto an HTTP client, for example, an Omnis application or a Web browser. HTTP headers arenormally hidden from Web clients, but convey very useful information regarding the statusand contents of the Web page. An Omnis method must send a header back to a connected Webbrowser in order to have its results properly displayed.
*
Socket* is an Omnis Long Integer field containing the number of a socket that hasalready been opened for a TCP/IP client, usually a Web browser or Omnis application thatrequires and can understand HTTP.
*
Status *is an Omnis Long Integer field containing an HTTP status code. The statuscode may change the way in which any following HTML or other information displays on theWeb browser. The following table contains the status codes which **HTTPHeader**recognises. Other status codes are accepted, but **HTTPHeader*** *thensends &quot;Unknown status&quot; as the text for the code.
|`Code <httpheader>`_  |**Meaning** |
|200 |The request was completed successfully |
|201 |The request was a POST method and was completed successfully. Data was sent to the server, and a new resource was created as a result of the request. |
|202 |A GET method returned only partial results. |
|204 |The request was completed successfully, but there is no new information. The browser will continue to display the document from which the request originated. |
|301 |The requested URL has moved permanently |
|302 |The requested URL has moved temporarily |
|304 |The GET request included a header with an If-Modified-Since field. However, the server found that the data requested had not been modified since the date in this field. The document was not resent (the Web browser will probably display it from its cache). |
|400 |The request syntax was wrong |
|401 |The request requires an Authorization field but the client did not specify one. Usually results in a username and password to be displayed |
|403 |Access is forbidden |
|404 |The request URL could not be found. |
|500 |The server has encountered an internal error and cannot continue with the request. |
|501 |The server does not support this method |
|502 |Bad gateway |
|503 |Service unavailable |
*
HeaderList* is an Omnis list with two character columns. The list contains theheaders to send. Note that **HTTPHeader** automatically sends some headers,so do not provide those (see below).

At a minimum, for Omnis to return normal Web-page HTML text to the client, you shouldsend a header containing the line:
|**Header name** |**Value** |
|Content-type |text/html |
*
***HTTPHeader** automatically includes the following lines in all HTTPresponse headers:
|**Attribute** |**Value** |
|Content-type |text/html (only if the *HeaderList* does not contain a Content-type header) |
|Date |The current GMT date and time in HTTP header format |
|Server |Omnis |
|MIME-version |1.0 |
*
Length *is an Omnis Long Integer field which receives the number of characters sent,or an error code less than zero. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  When a new connection is received call the method $newconnection;  and reply to the client to confirm the request was completedHTTPServer ('$newconnection',6001) Returns lStatus;  method $newconnectionDo lHeaderList.$define(lAttribute,lValue)HTTPHeader (iSocket,200,lHeaderList) Returns lCharCount
