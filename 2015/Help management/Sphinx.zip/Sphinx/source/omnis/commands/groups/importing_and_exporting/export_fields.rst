﻿Export fields
#############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Export fields** *index-name* ([*Indirect*][,*Use search*][,*Disable messages*]) {*list-of-field-names* (Name1,Name2,...)}

Options
*******|Indirect |If specified,the command uses the contents of the first field as the list of fields |
|Use search |If specified,the command uses the current search to select data |
|Disable messages |If specified,the command does not open messages requiring a user response,and instead it writes a limited amount of information to the trace log |

Description
************
***Export fields*** *exports the data for the list of fields tothe current export file. It provides runtime access to the functionality of the exportdata dialog in the IDE. The command sets the main file for the export to the filecorresponding to the first field in the list. The *index-name* is the optional nameof the indexed field which determines the order of the exported data.
Example
*******

.. code-block:: omnis
	:linenos:	;  export to a file called myExport.txt in the root of your omnis treeCalculate lExportPath as con(sys(115),'myExport.txt')Set print or export file name {[lExportPath]}Prepare for export to file {Delimited (commas)}Export fields fCustomers.CustomerID {fCustomers.Surname,fCustomers.FirstName}End exportClose print or export file
