﻿Queue bring to top
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue bring to top** *window-instance-name*
Description
***********
This command queues a &quot;bring to top&quot; event for the specified window instanceas if the user had clicked on the window instance with the mouse. The command brings thewindow instance to the fore and generates `evWindowClick <../../../notation/root/iwindows/window.html>`_
 and `evToTop <../../../notation/root/iwindows/window.html>`_
 events. If, at runtime, thespecified window instance does not exist, the command will do nothing.
Example
*******

.. code-block:: omnis
	:linenos:	Open window instance wMyWindow/wInst1/STKOpen window instance wMyWindow/wInst2/STKQueue bring to top wInst1     ;; brings the instance wInst1 to the top
