﻿Print check data log
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |NO |NO |NO |All |

Syntax
******
**Print check data log**
Description
***********
This command prints the current contents of the check data log to the current reportdestination. There is no need for the log to be open.
Example
*******

.. code-block:: omnis
	:linenos:	Check data (Check indexes)     ;; all filesIf flag true    Print check data logElse    OK message  {Check data only works if one user is logged on}End If
