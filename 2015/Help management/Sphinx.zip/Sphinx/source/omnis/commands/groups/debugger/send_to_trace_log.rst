﻿Send to trace log
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Debugger <../debugger.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Send to trace log** ([*Diagnostic message*]) {*text*}

Options
*******|Diagnostic message |If specified,the message will only be added to the trace log,if the trace log has been set to log diagnostic messages |

Description
***********
This command sends a specified line of text to the trace log. The text can containsquare bracket notation.

Note - for JavaScript client-executed methods this command sends the text to the JavaScript console (provided it is available).
Example
*******

.. code-block:: omnis
	:linenos:	;  send messages to the trace logOpen trace log (Clear trace log)Send to trace log {Current task is [$ctask().$name]}Send to trace log {Current class is [$cclass().$name]}For lCount from 1 to 10 step 1    Send to trace log {Value lCount is [lCount]}End ForSend to trace log {End of For Loop}
