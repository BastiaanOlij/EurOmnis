﻿Else
####
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Else**
Description
***********
This command is used after an *`If <if_calculation.html>`_
* command tomark the beginning of some commands that are carried out if the condition in the preceding*`If <if_calculation.html>`_
* command is false.
Example
*******

.. code-block:: omnis
	:linenos:	;  In the example below, the value of lGender is tested against the condition;  specified in the If statement.  If the condition fails, control branches to the;  first Else If statement in the method. If the condition again fails, control;  branches to the Else command.If lGender='M'    OK message  {Record is MALE}Else If lGender='F'    OK message  {Record is FEMALE}Else    OK message  (Sound bell) {GENDER Unknown for this record}End If;  The same result could also be obtained using a switch statementSwitch lGender    Case 'M'        OK message  {Record is MALE}    Case 'F'        OK message  {Record is FEMALE}    Default        OK message  (Sound bell) {GENDER Unknown for this record}End Switch
