﻿Build menu list
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |YES |NO |All |

Syntax
******
**Build menu list** ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |

Description
***********
This command builds a list containing the name of each menu class in the currentlibrary. The list is built in the current list for which the columns must have beendefined. The columns are
|**Column 1 (Character)** |**Column 2 (Character)** |
|Menu class name |Description for menu (if one has been entered) |

The **Clear list** option clears the current list and redefines it to include onlythe #S5 field. With this option, the command becomes reversible but you get column 1 only.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list of all menu classes in the current librarySet current list lMenuListDefine list {lMenuName,lMenuDesc}Build menu list;  Alternatively, you can use $makelistDo $menus.$makelist($ref.$name) Returns lMenuListDo lMenuList.$redefine(lMenuName)
