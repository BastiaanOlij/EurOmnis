﻿If calculation
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**If ***calculation*****
Description
***********
This command tests the result of the calculation and branches if zero. If the result ofthe calculation is non-zero, the result of the test will be true; a result of zero isinterpreted as false. As with all *If* commands, control passes to the next commandin the method if the result is true, otherwise to the next *`End If <end_if.html>`_
*,*`Else <else.html>`_
* or *`Else If <else_if_calculation.html>`_
 *inthe method.
Example
*******

.. code-block:: omnis
	:linenos:	If pSecurityLevel=1    Open window instance wAministratorElse    OK message  {This feature is only available to the Administrator}End If
