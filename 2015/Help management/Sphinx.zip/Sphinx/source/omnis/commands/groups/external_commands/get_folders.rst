﻿Get folders
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Get folders** (*list*-*name*, *first*-*column*, *path* [,*8.3*]) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command returns a list of folders under the specified *path-name.*

You specify the list with *list-name*. The list must have a column defined as *list-column-name*,where *list-column-name *is the name of a variable. This column will receive thenames of the folders under the specified *path-name
*
On Windows, you can also supply the *8.3* parameter. This defaults to `kFalse <../../../notation/root/constants/boolean_values.html>`_
. Ifyou pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
, then *Get folders* returns the 8.3 name equivalent to any long foldernames.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), or zero if noerror occurs.
Example
*******

.. code-block:: omnis
	:linenos:	;  obtain a list of the folders in the root of your machineDo lFolderList.$define(lFolderName)Switch platform()    Case 'U'        Get folders (lFolderList,lFolderName,'/')     Default        Get folders (lFolderList,lFolderName,'C:\') End Switch
