﻿Describe server table
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Describe server table** (*Columns*|*Indexes*) {*table-name*}

Types
*****|Columns |The command creates a select table with one row for each column of the server table |
|Indexes |The command creates a select table with one row for each index (of the specified type) of the server table |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.