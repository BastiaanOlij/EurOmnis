﻿POP3MessageCount
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3MessageCount** (*socket*[,*stsproc*]) **Returns** *messagecount*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3MessageCount** returns the count of messages available on a POP3server. The count includes messages marked for deletion (see *`POP3DeleteMessage 
`_
*).
*
Socket* is an Omnis Long Integer field containing a socket opened to a POP3 serverusing *POP3Connect*.
*
StsProc* is an optional parameter containing the name of an Omnis method that *POP3MessageCount*calls with status messages. *POP3MessageCount* calls the method with no parameters,and the status information in the variable #S1. The status information logs protocolmessages exchanged on the connection to the server.
*
MessageCount *is an Omnis Long Integer field which receives the number of messages.If an error occurs, the returned value is an error code with a value less than zero.Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Find out how many messages exist on the POP3 server lServer;  for user lUserNameCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocketPOP3MessageCount (iSocket) Returns lMessageCount
