﻿Queue click
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue click** ([*Shift*][,*Command/Ctrl*]) {*field-name* (*selection-range*)}

Options
*******|Shift |If specified,the queued event behaves as if the shift key has been pressed |
|Command/Ctrl |If specified,the queued event behaves as if the command/ctrl key has been pressed |

Description
***********
This command queues a &quot;mouse click&quot; event on a specified field, that is, itsimulates a user-generated mouse click/drag operation on a field. You must specify thename of the field as a parameter, including the click positions within the field (that is,Start Row, Finish Row for lists and Start Character, Finish Character for text fieldselection). The specified field will get the focus.

There are options for including up to three modifier keys (that is, Shift, Ctrl/Cmnd)along with the click.

The field name parameter must be the name of a window field, not the name of the methodassociated with the field or the data name (*$name*, not *$dataname*).
**Queue click for pushbuttons
===========================**
If the specified field is a pushbutton it is activated and an evClick event isgenerated as if the user had clicked on the button.
**Queue click for Radio buttons and checkboxes
============================================**
If the specified field is a check box or set of radio buttons, the check box field orgroup of radio buttons is checked/unchecked accordingly, and an evClick event isgenerated. Methods behind radio buttons and check boxes run as if the user had clicked onthe window fields.
**Queue click for Radio groups
============================**
If the specified field is a radio group, you identify the member of the group that is to receive the clickby setting the *selection-range* parameter to the value of *$dataname* that correspondsto the member.  When the command executes, Omnis checks the member and generates an evClick event. Event methods for the radio group run as if the user had clicked on the field.
**Queue click on Edit fields
==========================**
You can specify a range of characters. For example, the parameter *field-name (2,5)*,highlights the characters within cursor positions 2 to 5 (that is, characters 3 to 5).Note that cursor position 0 is to the left of character 1, and cursor position 1 is to theright of character 1 (or to the left of character 2).

If Shift is selected and 5 is passed as the selection point, all characters between thecurrent cursor position and cursor position 5 will be highlighted.

As the **Queue click** examples for Edit show, the two parameters act as a&quot;click on, drag to&quot; key operation.
**Queue click for lists
=====================**
If the specified field is a window list box or grid, the range is interpreted as arange of list lines. For example, the parameter *list-field-name (2,5)*, selects thelines 2 to 5 (if $multipleselect for the list field is set), and the current line will beset to 2. An evClick event is generated after the specified lines have been selected.
Example
*******

.. code-block:: omnis
	:linenos:	;  Queue click for edit fields;  highlight characters 3 to 7Queue click {myEntryField (7,2)};  highlight characters 6 to 9Queue click {myEntryField (5,7)};  assuming the current cursor is at position 15,;  characters 9 to 15 are highlightedQueue click (Shift) {myEntryField (8)};  assuming the current cursor is at position 15,;  characters 16 to 22 are highlightedQueue click (Shift) {myEntryField (22)};  assuming the current cursor is at position 15,;  characters 10 to 15 are highlightedQueue click (Shift) {myEntryField (7,9)};  assuming the current cursor is at position 15,;  characters 8 to 15 are highlightedQueue click (Shift) {myEntryField (9,7)};  Queue click for lists;  lines 7 to 3 are selected and the current line set to 7Queue click {myListField (7,3)};  lines 2 to 9 are selected and the current line set to 2Queue click {myListField (2,9)};  the current line to line 12 are selected; the current line does not changeQueue click (Shift) {myListField (12)};  line 13 is selected and any lines currently selected remain selected; the current line does not changeQueue click (Shift,Command/Ctrl) {myListField (13)};  lines 4 to 8 are selected and any lines currently selected remain selected; the current line does not changeQueue click (Shift,Command/Ctrl) {myListField (4,8)}
