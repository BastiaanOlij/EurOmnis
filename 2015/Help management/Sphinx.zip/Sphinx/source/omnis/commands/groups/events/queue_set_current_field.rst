﻿Queue set current field
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue set current field** {*field-name*}
Description
***********
This command queues a &quot;set current field&quot; event in the specified field, thatis, it simulates a user-generated click or tab to the specified field. In enter data mode,the contents of the field is selected. The command does not generate an `evClick <../../../notation/root/iwindows/window/objs/entry.html>`_
. However it willproduce proper `evBefore <../../../notation/root/iwindows/window/objs/entry.html>`_
and `evAfter <../../../notation/root/iwindows/window/objs/entry.html>`_
 eventsduring `Enter data <../../constructs/enter_data.html>`_
.

The field name parameter must be the name of a window field, not the name of the methodassociated with the field or the data name (*$fieldname*, not *$dataname*).
Example
*******

.. code-block:: omnis
	:linenos:	;  field method to jump to another field within the same window instanceOn evAfter    Queue set current field {myField}
