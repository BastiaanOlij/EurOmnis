﻿Accept commands
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Accept commands** ([*Accept*])

Options
*******|Accept |If specified,the mode identified by the command is enabled |

Description
***********
DDE command, Omnis as server. This command determines whether Omnis will acceptcommands from the client program. When **Accept commands** is in force, Omniswill respond to a DDE EXECUTE message by attempting to execute a command string sent bythe client program. All conversations are terminated when you close your Omnis library.
Example
*******

.. code-block:: omnis
	:linenos:	Accept advise requests (Accept)Accept commands (Accept)
