﻿Update data dictionary
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Update data dictionary** ([*Test only*]) {*list-of-files* (F1,F2,..,Fn) (leave empty to select all)}

Options
*******|Test only |If specified,the data file is not updated; the command purely tests to see if it would update the data file when executed without this option specified,and returns the flag set to true if an update would occur |

Description
***********
This command updates the data dictionary for the specified file or list of files. Thedata dictionary is a copy of the file class field definitions and is stored in the datafile. The command lets you write minor file class changes to the data dictionary. Theseminor changes do not require data reorganization, and include changes such as adding newfields, altering field names and altering field lengths. You can only update the data dictionaryif you are the only user logged on to the data file.
*
***Update data dictionary*** *updates the data dictionary for thespecified list of file classes. If you omit a file name or list of files, *all* thefiles with slots in the current data file are updated.

If a specified file name does not include a data file name as part of the notation, thedefault data file for that file is assumed. If the file is closed or memory-only, thecommand does not execute and returns with flag false.

If the **Test only** option is specified, no updating is actually carried out, andthe flag is set if at least one file in the data dictionary needs updating.

Certain changes made to a file class (that is, changes in indexes, field type changesand changes in file connections) require data reorganization. In this case, using **Updatedata dictionary** to keep the file class and the data file &quot;in step&quot; willbe inappropriate. *`Reorganize data <reorganize_data.html>`_
* lets you testwhether a data file needs reorganization as well as to reorganize it if necessary.
Example
*******

.. code-block:: omnis
	:linenos:	Update data dictionary (Test only)     ;; all filesIf flag true    Update data dictionary     ;; all filesEnd If
