﻿Change working directory
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Change working directory** (*path*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command changes the current directory in use under Windows or Linux. Wild cards arenot allowed with this command.

On Windows, **Change working directory** only switches directories on thesame drive, not between drives.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), orzero if no error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Change working directory (&quot;c:\omnis\html&quot;) Returns lErrCode     ;; windowsChange working directory (&quot;/omnis/html&quot;) Returns lErrCode     ;; linux
