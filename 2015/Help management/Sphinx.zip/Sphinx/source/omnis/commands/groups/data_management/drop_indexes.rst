﻿Drop indexes
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Drop indexes** {*file-name*}
Description
***********
This command deletes all the indexes for the specified file apart from the recordsequence number index. This enables intensive operations such as data import to proceedwithout the overhead of updating all the indexes. You can use *`Build indexes <build_indexes.html>`_
* to rebuild the indexes which were dropped.

If the specified file name does not include a data file name as part of the notation,the default data file for that file is assumed. If the file is closed or memory-only, thecommand does not execute and returns with the flag false.

If you are running on a shareable volume, Omnis automatically tests that only one useris logged onto the data file (the command fails with flag false if this is not true) andfurther users are prevented from logging onto the data until the command completes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute, andit is not possible to cancel execution even if a working message with cancel box is open.

The command is not reversible: it sets the flag if it completes successfully and clearsit otherwise, for example if there is more than one user logged onto the data file.
Example
*******

.. code-block:: omnis
	:linenos:	;  fast importDo not flush dataDrop indexes {fCustomers}     ;; drop the indexesDo method ImportData     ;; import the dataBuild indexes {fCustomers}     ;; rebuild the indexes
