﻿Jump to start of loop
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Jump to start of loop**
Description
***********
This command jumps to the *`Until <until_calculation.html>`_
* or *`While <while_calculation.html>`_
 *command at the beginning of the current loop,missing out all commands after the jump. When used in a *While&#150;`End While <end_while.html>`_
* loop, **Jump to start of loop** jumpsto the start of the loop so that Omnis can make the While test; the loop continues orterminates depending on the result of this test, whereas, *`Break to end of loop <break_to_end_of_loop.html>`_
* automatically terminates theloop regardless of the value of the condition. Placing a Jump outside a loop causes anerror.
Example
*******

.. code-block:: omnis
	:linenos:	;  Only calculate lBalance if an account number has been enteredCalculate lBalance as 0Repeat    Prompt for input Account Number Returns lAccountNumber (Cancel button)    If flag false     ;; cancel button        Break to end of loop    Else If len(lAccountNumber)=0     ;; no account number entered        OK message  {Please enter a account number}        Jump to start of loop    End If        Calculate lBalance as 100Until lBalance&gt;0
