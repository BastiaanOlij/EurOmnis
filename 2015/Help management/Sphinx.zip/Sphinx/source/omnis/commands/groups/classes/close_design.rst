﻿Close design
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Close design** {*class-name*}
Description
***********
This command closes the specified design class. Trying to close a class which is notopen simply clears the flag.
Example
*******

.. code-block:: omnis
	:linenos:	Close design
