﻿Show fields
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Fields <../fields.html>`_  |NO |YES |NO |All |

Syntax
******
**Show fields** {*list-of-field-names* (Name1,Name2,...)}
Description
***********
This command shows the specified window field or list of fields. You can hide fieldswith *`Hide fields <hide_fields.html>`_
* or using the notation. Inactivepushbuttons with the **Do not gray**** **attribute cannot be made visible withthis or any other command.

If you use** Show fields** in a reversible block, the specified fields arehidden when the method containing the reversible block terminates.
Example
*******

.. code-block:: omnis
	:linenos:	Yes/No message  {Do you want to show fields?}If flag true    Begin reversible block        Show fields {myField1,myField2}    End reversible blockEnd If;  do somethingQuit method ;  now this method ends and the fields are re-hidden as they are in a reversible block;  To show a single field on the current windowDo $cwind.$objs.myField1.$visible.$assign(kTrue);  to show all fields on the current windowDo $cwind.$objs.$sendall($ref.$visible.$assign(kTrue))
