﻿Set memory-only files
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |YES |YES |NO |All |

Syntax
******
**Set memory-only files** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command sets the file mode of the specified file(s), other than the main file, tomemory-only. You can use the fields from a memory-only file as global variables. To dothis: <ol>  <li>Create a file class with some fields of the required type (Character, Numeric, and so    on).</li>  <li>Designate the file class as a memory-only file using this command.</li>  <li>Use the fields in your methods as temporary storage for data.</li></ol>
When a memory-only file is changed to read/write, its fields are not cleared from thecurrent record buffer. Similarly, when a file is changed from read/write to memory-only,its records are not cleared. Memory-only fields are initialized as empty when the libraryis launched.

If used in a reversible block, *Set memory-only files* is reversed when the methodcontaining the block finishes. This command does not clear the Prepare for update mode.

In the method editor, a list of files is displayed. You can Ctrl/Cmnd-click on the filenames to select multiple names.
Example
*******

.. code-block:: omnis
	:linenos:	;  Use the fields in the file class fGlobals as temporary global variables;  which do not get written to a datafileSet memory-only files {fGlobals}Calculate fGlobals.gMyGlobalVar as 'My Global Var'
