﻿Set Omnis window title
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |NO |YES |NO |Windows,Linux |

Syntax
******
**Set Omnis window title** {*title*}
Description
***********
This command changes the title on the Omnis application window (available under Windowsand Linux only). The *title* parameter provides the new title which may contain squarebracket notation. Unless reversed as part of a reversible block, the new title will remainuntil Omnis is restarted.
Example
*******

.. code-block:: omnis
	:linenos:	;  Set the Omnis window title to 'My Application'Begin reversible block    Set Omnis window title {My Application}     ;; for Windows/Linux onlyEnd reversible block
