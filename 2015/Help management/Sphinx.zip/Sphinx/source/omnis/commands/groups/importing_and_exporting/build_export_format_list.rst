﻿Build export format list
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |YES |NO |All |

Syntax
******
**Build export format list** ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |

Description
***********
This command builds a list containing the name of each export format. The list is builtin the current list for which you must define a single column to contain the exportformat.

The **Clear list** option clears the current list and redefines it to include onlythe #S4 field. With this option, the command becomes reversible.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list lExportFormatList;  clear list option defines the list as a single column #S4Build export format list (Clear list)
