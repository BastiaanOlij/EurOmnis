﻿Operating system
################
`Command Index <../command_index.html>`_


`Commands
******** <operating_system#commands>`_
|`Context help <operating_system/context_help.html>`_  |`Launch program <operating_system/launch_program.html>`_  |`Start program maximized <operating_system/start_program_maximized.html>`_  |`Start program minimized <operating_system/start_program_minimized.html>`_  |
|`Start program normal <operating_system/start_program_normal.html>`_  |`Test for program open <operating_system/test_for_program_open.html>`_  |`Test if file exists <operating_system/test_if_file_exists.html>`_  |

