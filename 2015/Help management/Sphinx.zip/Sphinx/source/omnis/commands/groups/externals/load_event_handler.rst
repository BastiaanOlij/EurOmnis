﻿Load event handler
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Externals <../externals.html>`_  |YES |YES |NO |All |

Syntax
******
**Load event handler** *routine-name* or *library-name*/*routine-name* (*parameters*)
Description
***********
This command makes the specified external routine an event handler, enabling theroutine to show its own windows, put its own menus on the menu bar, act as its own eventfilter, and so on.

Event handlers are modules of code which, when loaded, form part of the Omnisevent-processing loop. Events are passed to the external before being handled by Omnis. Aseach call to the external takes place, it can identify whether to take appropriate action.If the event handler returns a flag false, Omnis knows that the event was meant for Omnisand the external has ignored it.

You can enter the routine name as the parameter. If the library/resource is not in theEXTERNAL folder, the name of the file containing the library/resource and the name of thelibrary/resource within that file are given as parameters. If no file name is given, thecurrent dynamic link library/resource is searched for the specified routine name.

When the method is called, any existing event handler is not unloaded but continues tobe called along with the new handler. The flag is cleared if the routine cannot be loaded.

If you use **Load event handler** in a reversible block, the event handleris unloaded when the method containing the reversible block terminates.

You can pass parameters to the external code by enclosing a comma-separated list offields and calculations. If you pass a field name, for example, *`Call external routine <call_external_routine.html>`_
 Maths1 (LVAR1,LVAR2), *theexternal can directly alter the field value. Enclosing the field in brackets, for example,*`Call external routine <call_external_routine.html>`_
 Maths1 ((LVAR1),(LVAR2)),*converts the field to a value and protects the field from alteration.

In the routine itself, the parameters are read using the usual GetFldVal or GetFldNvalwith the predefined references Ref_parm1, Ref_parm2, and so on, Ref_parmcnt gives thenumber of parameters passed. If the field name is passed as a parameter, you can useSetFldVal or SetFldNval with Ref_parm1, and so on, to change the field's value.
Example
*******

.. code-block:: omnis
	:linenos:	Load event handler myEventHandler
