﻿External file command error codes
*********************************|**Error Code** |**Error Text** |
|1 |<span lang="EN-US">Too few parameters passed on the command line</span> |
|12 |<span lang="EN-US">Out of memory error</span> |
|998 |<span lang="EN-US">Undefined error</span> |
|999 |<span lang="EN-US">No operation on this platform</span> |
|-30 |<span lang="EN-US">Unable to delete directory or file</span> |
|-36 |<span lang="EN-US">Disk IO error (or error during operation)</span> |
|-39 |<span lang="EN-US">End of file reached during Read file as character or Read file as binary</span> |
|-43 |<span lang="EN-US">File not found</span> |
|-48 |<span lang="EN-US">File or directory already exists</span> |
|-51 |<span lang="EN-US">Bad file reference number</span> |
|-59 |<span lang="EN-US">Problem during rename</span> |

<span lang="EN-US" style="mso-bookmark: _Toc298222652"> </span>

<span lang="EN-US">  <o:p> </o:p> </span>
