﻿Print class
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |NO |NO |NO |All |

Syntax
******
**Print class** {*class-name*}
Description
***********
This command prints the field list and methods (if any) for the specified class. Theexample prints the field list and/or methods for all the classes in the current library.
Example
*******

.. code-block:: omnis
	:linenos:	;  generate list of all classes in the current libraryCalculate iList as $clib.$classes.$makelist($ref.$name)Do iList.$redefine(iClassName);  loop through the list and print the resultsFor lNum from 1 to iList.$linecount step 1    Do iList.[lNum].$loadcols()    Print class {[iClassName]}End For
