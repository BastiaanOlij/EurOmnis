﻿Set read/write files
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |YES |YES |NO |All |

Syntax
******
**Set read/write files** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command sets the file mode of the specified file(s) to read/write. The read/writefile mode is the default type of Omnis file; you can read and write data to a read/writefile. The other three file modes are read-only, closed and memory-only. If a file ischanged to read/write mode when in Prepare for update, the data for the file class isreread from disk. In multi-user systems, read/write files are locked when a *Preparefor..*. command is executed.

The file mode will revert to its former state if you use the command in a reversibleblock.

In the method editor, a list of files is displayed. You can Ctrl/Cmnd-click on the filenames to select multiple names.
Example
*******

.. code-block:: omnis
	:linenos:	;  Set the file fSequences to read/write so that we can get the next invoice numberSet read/write files {fSequences}Set main file {fSequences}Prepare for insertFind first Calculate fSequences.InvoiceNumber as fSequences.InvoiceNumber+1Update filesSet read-only files {fSequences}
