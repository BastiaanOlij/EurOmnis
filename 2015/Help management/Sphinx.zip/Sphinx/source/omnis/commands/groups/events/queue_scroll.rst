﻿Queue scroll
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue scroll** (*Left*|*Right*|*Up*|*Down*[,*Page*]) {*field-name* (*units*)}

Types
*****|Left |Scroll the field to the left |
|Right |Scroll the field to the right |
|Up |Scroll the field up |
|Down |Scroll the field down |


Options
*******|Page |If specified,scrolling occurs in pages,rather than the units corresponding to the up and down arrows on the scroll bar |

Description
***********
This command queues a &quot;scroll&quot; event in the specified scrollable field, thatis, it simulates a mouse click or page key event on a scrollable field. With this commandyou can scroll a field up or down, left or right provided the appropriate scroll bar isavailable. You cannot use this command to scroll a window instance.

The field name parameter must be the name of a window field, not the name of the methodassociated with the field or the data name (*$fieldname*, not *$dataname*).

The **Units** parameter specifies the number of lines to scroll up or down in avertical scroll bar for a field; one unit represents one line. For a horizontal scrollbar, the unit is approximately one character.

If the **Page** option is selected, the event simulates clicking above or belowthe &quot;thumb&quot; and is the same as using the Page up or Page down key.
Example
*******

.. code-block:: omnis
	:linenos:	;  scroll a list field by 5 linesQueue scroll (Down) {myListField (5)}
