﻿Go to next selected line
########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Go to next selected line** ([*From start*][,*Backwards*])

Options
*******|From start |If specified,the command starts with the first line of the list,rather than the line immediately after the current line |
|Backwards |If specified,the command steps through the list in reverse order;when used with 'From start',the command starts at the end of the list,otherwise if 'From start' is not specified,it starts with the line before the current line |

Description
***********
This command scans a list for selected lines and goes to the first one it finds. Itsets the current line (*LIST.$line*) for the current list (*#CLIST*) equal tothe next selected line in that list.

The **Go to next selected line** command steps through the list startingat the current line (if no options are selected) until a selected line is found. When aselected line is located, LIST.$line is set equal to that line number. If a selected lineis not found, the flag is cleared and LIST.$line is unchanged.

The **Backwards** option causes the list to be searched in descending order; the **Fromstart**** **option causes the list to be searched from the start. If both options **Backwards**and **From start** are selected, the list is searched from the end.
Example
*******

.. code-block:: omnis
	:linenos:	;  Transfer the value from line 3 to the 2 selected linesSet current list lMyListDefine list {lCol1}For lCount from 1 to 10 step 1    Add line to list {(lCount)}End ForCalculate lMyList.$line as 3Load from listSelect list line(s) {1}Select list line(s) {5}Go to next selected line (From start)Replace line in listGo to next selected lineReplace line in list
