﻿Clear timer method
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear timer method**
Description
***********
This command clears or cancels the current timer method. Usually a timer method remainsin operation until the library is closed or an error occurs. In a reversible block, thecurrent timer method is restored when the method terminates.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear the timer method after it is called so that is;  only called onceSet timer method 5 sec Timer;  method TimerOK message  {Timer method triggered once only}Clear timer method
