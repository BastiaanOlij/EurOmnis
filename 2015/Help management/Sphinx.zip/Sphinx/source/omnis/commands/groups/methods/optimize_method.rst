﻿Optimize method
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Methods <../methods.html>`_  |NO |YES |NO |All |

Syntax
******
**Optimize method**
Description
***********
This command stores an optimized form of the method so when the method is executed fora second time it runs much faster. You should position this command so that it is thefirst executable statement of the method, except when you put it in a reversible block.Methods which are executed frequently, such as control methods and loops, are bestoptimized. The command is reversible and does not change the flag.

**Optimize method** works immediately, therefore when it is executed forthe first time it converts all of the subsequent lines of the method being executed intoits optimized form and continues execution. When the method terminates, the optimized formof that method is kept in RAM; the optimized form is executed if the method is calledagain. If **Optimize method** is in a reversible block the optimized form ofthe method is disposed of when the method terminates; so it will be rebuilt each time themethod executes. The optimized method is also discarded whenever the design window is openfor the method or the method is modified using the notation.

**WARNING** Optimizing too many methods will increase the memory used which mayeventually result in a slowdown or worse.
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list of invoices for the first overdrawn accountOptimize methodSet main file {fAccounts}Set current list iInvoicesDefine list {fInvoices}Set search name sOverDrawnFind first on fAccounts.Code (Use search)While flag true    Single file find on fInvoices.AccCode (Exact match) {fAccounts.Code}    Add line to list    Next End While
