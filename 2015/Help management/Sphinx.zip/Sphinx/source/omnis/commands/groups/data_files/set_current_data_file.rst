﻿Set current data file
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |NO |YES |NO |All |

Syntax
******
**Set current data file** {*internal-name*}
Description
***********
This command sets the specified data file the &quot;current&quot; data file. If yourmethods refer to file class names without specifying the data file, it is essential tomake the appropriate data file current before setting a main file.
Example
*******

.. code-block:: omnis
	:linenos:	Open data file {Archive.df1/DataFileA}Open data file (Do not close other data) {myData.df1/DataFileB}Set current data file {DataFileA}Set main file {fCustomers};  fCustomers.Field1 now refers to DataFileA.fCustomers.Field1
