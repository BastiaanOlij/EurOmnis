﻿TCPGetMyPort
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPGetMyPort** (*socket*) **Returns** *port*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPGetMyPort** is a command to return the number of the local TCP/IPport to which a given socket is bound.
*
Socket *is an Omnis Long Integer field containing a connected socket, or a socketbound to a port.
*
Port *is an Omnis Long Integer field which receives the port number, or an errorcode &lt; 0. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Bind iPort to iSocket and use TCPGetMyPort to return the;  port to which iSocket is bound in lMyPort.Calculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPGetMyPort (iSocket) Returns lMyPortTCPClose (iSocket) Returns lStatus
