﻿FTPList
#######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPList** (*socket*,*list*[,*pathname*,*mode*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPList** lists files on the FTP server.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
List* is an Omnis List field containing a single column of type Character. This listreceives the file listing information, one line per file, returned by the remote FTPserver. The list is dependent on the type of the remote server and may be in long or shortformat, depending on the *Mode* parameter.
**
Note: **Very often, FTP servers return long-format listings in a Linux file listingformat. At a minimum, this file information contains the filename, but usually includesother information. The Omnis method must parse this information to find the filename andother information. For example
|ListItem | | | | | |
|total 123 | | | | | |
|drwxr-xr-x |4 |userid |mygroup |Jan 1 1999 |. |
|drwxr-xr-x |6 |root |root |Jan 1 1999 |.. |
|-rw------- |1 |userid |mygroup |Jan 16 1998 |myfile |
|-rw-r&#151;r&#151; |2 |userid |mygroup |Jan 16 1998 |myotherfile |

Where the columns in the character string correspond to protection, file size, usernameand group of the file owner, the date last modified and the name of the file. The files&quot;.&quot; and &quot;..&quot; represent the current and parent directories,respectively, which may neither be retrieved nor changed.

The file information may not be neatly spaced into columns as in this example. Columnsare separated with one or more spacing characters (space, tab, and so on).
*
Pathname* is an optional Omnis Character field that contains a pathname or wildcardspecification for the files to include in the listing. If omitted, the default is to listall of the files in the current directory on the FTP server.
*
Mode* is an optional numeric value which indicates whether the server should returna short or long format listing. If omitted, it defaults to zero.
|**Code** |**Meaning** |
|0 |Filename-only listing |
|1 |Long-format listing |
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_

Example
*******

.. code-block:: omnis
	:linenos:	Do iMyList.$define(iListColumn);  return a long format listing of the current directory into the list variable iMyListFTPList (iFTPSocket,iMyList,,1) Returns lErrCodeIf lErrCode    FTPGetLastStatus (iServerReplyText) Returns lErrCode    OK message FTP Error {[con(&quot;Error obtaining list of files from the FTP server&quot;,kCr,&quot;Details follow: &quot;,kCr,iServerReplyText)]}End If
