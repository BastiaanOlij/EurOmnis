﻿Queue OK
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue OK**
Description
***********
This command queues an &quot;OK&quot; event. It simulates the user clicking on the OKbutton or pressing the Enter key.
Example
*******

.. code-block:: omnis
	:linenos:	;  trap a Tab event and issue an OK event from itOn evTab    Queue OK
