﻿Test for menu installed
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for menu installed** {*menu-instance-name*}
Description
***********
This command tests whether the specified menu instance is installed on the menu bar.The flag is set if the menu instance is on the menu bar and cleared if it is not,regardless of whether the menu instance is enabled or grayed out. The command does notapply to hierarchical and popup menus.
Example
*******

.. code-block:: omnis
	:linenos:	;  Install the menu mMyMenu if it is not already;  installedTest for menu installed {mMyMenu}If flag false    Install menu mMyMenuEnd If
