﻿FTPSetConfig
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPSetConfig** (*proc*[,*activeonly* {Default zero for no;1 for yes}]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPSetConfig** provides the FTP commands with configurationinformation.
*
Proc* is an Omnis Character field containing the name of an Omnis method used toreport the progress of FTP operations which transfer data (*`FTPGet <ftpget.html>`_
*,*`FTPGetBinary <ftpgetbinary.html>`_
*, *`FTPList <ftplist.html>`_
*,*`FTPPut <ftpput.html>`_
* and *`FTPPutBinary <ftpputbinary.html>`_
*);for example MYLIBRARY.MYCODE/MYPROC. You can clear the current setting for the FTPprogress proc, by passing an empty value.
*
ActiveOnly* is an optional parameter. A value of 1 causes all FTP over non-secure connections to be active,rather than the default, which is use passive FTP if the server supports it (if the connection is secure thenonly passive FTP can be used). Normally, youwould not select ActiveOnly FTP; this is provided as a possible work-around for serverswith which passive FTP is causing problems. You can find a fuller explanation below ofpassive and active FTP.
*
Status* receives the result of executing this command. Possible error codes arelisted in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

FTP data transfer commands call the progress proc (if specified) while data transfer isin progress. This allows you to indicate progress to the user. The commands call theprogress proc with three parameters: <ul>  <li>Socket: the FTP socket on which the operation is occurring</li>  <li>TransferredSoFar: the number of characters transferred so far, or for `FTPList <ftplist.html>`_
, the number of lines received so far.</li>  <li>TotalToTransfer: the total number of characters that need to be transferred; note that    this is only available when executing `FTPPut <ftpput.html>`_
 or `FTPPutBinary <ftpputbinary.html>`_
.</li></ul>
The FTP data transfer commands always first attempt to use passive mode to transferdata. In passive mode, the client initiates the data connection to the server. This is therecommended mode of operation (see RFC1579, &quot;Firewall Friendly FTP). Most FTP serverssupport passive mode, although there are some which do not. In this case, if the attemptto use passive mode fails, the FTP commands use active mode to transfer data. In thiscase, the server initiates the data connection to a port on the client.
Example
*******

.. code-block:: omnis
	:linenos:	;  setup the config methodFTPSetConfig ('cCode/FTPProgress') ;  Then in code class cCode/FTPProgress;  3 parameter variables (all defined as long integer)OK message  {Socket [pSocket] - TransferredSoFar [pTransferredSoFar] - TotalToTransfer [pTotalToTransfer]}
