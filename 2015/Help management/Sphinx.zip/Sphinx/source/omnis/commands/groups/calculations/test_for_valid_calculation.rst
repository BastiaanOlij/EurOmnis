﻿Test for valid calculation
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for valid calculation** {*calculation*}
Description
***********
This command lets you test a **calculation** before it is evaluated. It isessential to test strings to be evaluated by the *`eval() <../../../functions/groups/general/eval.html>`_
,* *`evalf() <../../../functions/groups/general/evalf.html>`_
* and *`fld() <../../../functions/groups/field/fld.html>`_
* functions before doing theevaluation. The flag is set True if the **calculation** is valid.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lCalculation as 'lBalance &lt; 0'Test for valid calculation {evalf(lCalculation)}If flag true    Do lAccountsList.$search(evalf(lCalculation))End If
