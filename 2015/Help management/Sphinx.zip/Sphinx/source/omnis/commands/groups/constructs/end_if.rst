﻿End If
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**End If**
Description
***********
This command terminates an *`If <if_calculation.html>`_
* statement onceOmnis has executed the commands inside the *`If <if_calculation.html>`_
*statement; it also marks the end of the commands to be executed as part of the *If...ElseIf *block. Once the commands associated with the *If...Else If* block have beenexecuted, control passes to the next command after **End If***. *Forevery *`If <if_calculation.html>`_
* command, you should have a corresponding **EndIf*** *command.
Example
*******

.. code-block:: omnis
	:linenos:	For lCount from 1 to 100 step 1    If lCount&gt;=25&amp;lCount&lt;=50        If lCount=25            OK message  {Quater of the way through now}        Else If lCount=50            OK message  {Halfway through now}        End If    End IfEnd ForOK message  {Done}
