﻿Single file find
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Single file find** **on ***field-name***** ([*Exact match*]) {*calculation*}

Options
*******|Exact match |If specified,the index value of the field in suitable records must equal the current value |

Description
***********
This command locates a record in a single file only. It is similar to the standard *`Find <find.html>`_
* command but is not dependent on the main file; that is, thefield used in **Single file find** does not have to belong to the main fileand it does not read in the connected records. You can specify a calculation for **Singlefile find** which determines the value used in the Find. The **Exact match**option with a blank calculation indicates that the command is to be executed using thecurrent value of the field, that is, the file is searched for a record whose index valuematches the current value of the specified field.

In multi-user systems, a **Single file find** while in Prepare for... modecauses additional semaphores to be set. If the record is already locked, the user mustwait for access to the record.
Example
*******

.. code-block:: omnis
	:linenos:	;  Find account lMyAccCodePrompt for input Account Code ? Returns lMyAccCode (Cancel button)Wait for semaphoresSingle file find on fAccounts.Code (Exact match) {fAccounts.Code=lMyAccCode}If flag false    OK message  {Can't find record}End If
