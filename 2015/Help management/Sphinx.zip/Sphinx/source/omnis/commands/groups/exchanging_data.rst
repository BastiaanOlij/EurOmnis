﻿Exchanging data
###############
`Command Index <../command_index.html>`_


`Commands
******** <exchanging_data#commands>`_
|`Accept advise requests <exchanging_data/accept_advise_requests.html>`_  |`Accept commands <exchanging_data/accept_commands.html>`_  |`Accept field requests <exchanging_data/accept_field_requests.html>`_  |`Accept field values <exchanging_data/accept_field_values.html>`_  |
|`Advise on find/next/previous <exchanging_data/advise_on_find_next_previous.html>`_  |`Advise on OK <exchanging_data/advise_on_ok.html>`_  |`Advise on redraw <exchanging_data/advise_on_redraw.html>`_  |`Cancel advises <exchanging_data/cancel_advises.html>`_  |
|`Clear DDE channel item names <exchanging_data/clear_dde_channel_item_names.html>`_  |`Close DDE channel <exchanging_data/close_dde_channel.html>`_  |`Message timeout <exchanging_data/message_timeout.html>`_  |`Open DDE channel <exchanging_data/open_dde_channel.html>`_  |
|`Request advises <exchanging_data/request_advises.html>`_  |`Request field <exchanging_data/request_field.html>`_  |`Send advises now <exchanging_data/send_advises_now.html>`_  |`Send command <exchanging_data/send_command.html>`_  |
|`Send field <exchanging_data/send_field.html>`_  |`Set advise options <exchanging_data/set_advise_options.html>`_  |`Set DDE channel item name <exchanging_data/set_dde_channel_item_name.html>`_  |`Set DDE channel number <exchanging_data/set_dde_channel_number.html>`_  |
|`Set server mode <exchanging_data/set_server_mode.html>`_  |

