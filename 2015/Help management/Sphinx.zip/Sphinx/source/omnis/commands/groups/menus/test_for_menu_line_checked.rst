﻿Test for menu line checked
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for menu line checked** *line* or *instance-name*/*line*
Description
***********
This command tests whether the specified line of a menu instance is checked. Youspecify the *menu-instance-name* and the *line-number* of the menu line you wantto test. The flag is set if the specified line of the menu instance is checked, andcleared if the line is not checked. The flag is always cleared if the menu instance is notinstalled on the menu bar.

You can check menu lines using *`Check menu line <check_menu_line.html>`_
*.*`Uncheck menu line <uncheck_menu_line.html>`_
* removes the check.
Example
*******

.. code-block:: omnis
	:linenos:	;  Uncheck the menu line 'Large' if it is;  currently checkedInstall menu mViewCheck menu line mView/LargeTest for menu line checked mView/LargeIf flag true    Uncheck menu line mView/LargeEnd If;  Alternatively, you can see if a menu line is checked;  using notationIf $imenus.mView.$objs.Large.$checked    Do $imenus.mView.$objs.Large.$checked.$assign(kFalse)End If
