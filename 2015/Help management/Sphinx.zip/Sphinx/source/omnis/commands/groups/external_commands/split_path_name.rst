﻿Split path name
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Split path name** (*path*, *drive*-*name*, *directory*-*name*, *file*-*name*, *file*-*extension*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command splits a full path name into its component parts: the drive name,directory and file name, and file extension. It returns an error code (values are listedat the end of this Appendix), or zero if no error occurs. The following examples show how **Splitpath name** operates.
**
Windows
**|**Path** |**Drive** |**Directory** |**Filename** |**Extension** |
|C:\TESTDIR\TESTSDIR\TESTFILE |C: |\TESTDIR\TESTSDIR\ |TESTFILE | |
|C:\TESTDIR\TESTFILE.EXT |C: |\TESTDIR\ |TESTFILE |.EXT |
|C:\TESTFILE |C: |\ |TESTFILE | |
**
Linux
**|**Path** |**Drive** |**Directory** |**Filename** |**Extension** |
|/TESTDIR/TESTSDIR/TESTFILE | |/TESTDIR/TESTSDIR/ |TESTFILE | |
|/TESTDIR/TESTFILE.EXT | |/TESTDIR |TESTFILE |.EXT |
|/TESTFILE | |/ |TESTFILE | |
Example
*******

.. code-block:: omnis
	:linenos:	;  split the path name lPathnameCalculate lPathname as 'c:\desktop\myfolder\mylibrary.lbs'Split path name (lPathname,lDrive,lDirectory,#???,lExtension) ;  lDrive= 'c:';  lDirectory = '\desktop\myfolder\';  lFileName = 'mylibrary';  lExtension ='.lbs'
