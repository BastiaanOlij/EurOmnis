﻿Test for a unique index value
#############################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Finding data <../finding_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Test for a unique index value** **on ***field-name*****
Description
***********
This command tests the specified indexed field for a unique value. The flag is set ifthe current field value is a unique index value, and cleared if the value duplicates anexisting index value. In a multi-user situation, no account is made of field values inrecords held by other work stations which are not yet updated to disk.

You use **Test for a unique index value** before storing a new value in afile. In the following example, the proposed new part number is tested against theexisting file.
Example
*******

.. code-block:: omnis
	:linenos:	;  Insert account AC05 if it does not already existSet main file {fAccounts}Prepare for insertCalculate fAccounts.Code as 'AC05'Test for a unique index value on fAccounts.CodeIf flag true    Update filesEnd If
