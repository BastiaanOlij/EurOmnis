﻿Clear selected files
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Files <../files.html>`_  |NO |YES |NO |All |

Syntax
******
**Clear selected files** {*list-of-files* (F1,F2,..,Fn)}
Description
***********
This command clears the current record buffer of records from the specified files. Thecommand is particularly useful in a multi-user system where it may be necessary to removeonly certain files so that they are not locked.

In the method editor, a list of files is displayed. You can Ctrl/Cmnd-click on the filenames to select multiple names. If no file name or file list is specified, the commanddoes nothing.

This command is reversible for read-only and read-write files; the command reverses by re-readingeach record into the current record buffer.  Note that using this command in a reversible blockwith a memory-only file will clear the current record buffer for that file when the command reverses.
Example
*******

.. code-block:: omnis
	:linenos:	;  Clear the current record buffer of records from fAccounts;  and fInvoices and redraw the current window instanceClear selected files {fAccounts,fInvoices}Do $cinst.$redraw()
