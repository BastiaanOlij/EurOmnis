﻿Start program maximized
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Operating system <../operating_system.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Start program maximized** {*program-name*}
Description
***********
This command starts up an application at its maximum screen size. The program name mustbe the pathname of the executable file. You can also specify the full pathname of a file,and other parameters, separated by a space from the program name. You can use this commandon Windows and Linux, although on Linux the command does not maximize the application.

The flag is set if the program is found.
Example
*******

.. code-block:: omnis
	:linenos:	;  If the program lPath exists start it maximizedCalculate lPath as 'c:\program files\windows nt\accessories\wordpad.exe'Test if file exists {[lPath]}If flag true    Start program maximized {[lPath]}End If
