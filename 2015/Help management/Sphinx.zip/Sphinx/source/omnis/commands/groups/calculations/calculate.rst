﻿Calculate
#########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |NO |YES |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Calculate ***field-name*** as ***calculation*****
Description
***********
This command assigns a new value to a data field or variable. The form of the commandis &quot;Calculate X as Y&quot;, where X is a valid data field or variable name and Y iseither a valid data field or variable name, value, calculation, or notation. When **Calculate**is executed the state of the flag is unchanged, unless #F is recalculated by this command.

You can use* ***Calculate** in a reversible block. The data fieldreturns to its initial value when the method containing the block of reversible commandsfinishes.
**
**Warning the **Calculate** command does not redraw a calculated fieldso if your field is on a window you must use the** ***`Redraw <../../../commands/groups/fields/redraw.html>`_
 *command or the $redraw()method after the **Calculate*** *command to reflect the change.

**Operator Precedence**

Mathematical expressions are evaluated using the operator precedence so that in theabsence of brackets, * and / operations are evaluated before + and -. The full orderingfrom highest to lowest precedence is:

unary minus

* and /

+ and -

&gt;, &lt;, &gt;=, &lt;=, &lt;&gt;, =

&amp; and |

For example, if you execute the command &quot;Calculate lVar1 as 10-2*3&quot; thecalculation part is evaluated as 10-(2*3)
Example
*******

.. code-block:: omnis
	:linenos:	;  set the local variable lVar1 equal to the contents of lVar2Calculate lVar1 as lVar2;  set the local variable lPrice to 10.99 and lQty to 2Calculate lPrice as 10.99Calculate lQty as 2;  calculate the local variable lTotal as lPrice multiplied by lQtyCalculate lTotal as lPrice*lQty;  you can also operate on variables using notation, for example;  calculate the local list variable lClassList as a list of all classes in the current libraryCalculate lClassList as $clib.$classes.$makelist($ref.$name);  however some operations are better performed using the Do command, for example;  bring the window instance wMywindow to the frontDo $iwindows.wMywindow.$bringtofront()
