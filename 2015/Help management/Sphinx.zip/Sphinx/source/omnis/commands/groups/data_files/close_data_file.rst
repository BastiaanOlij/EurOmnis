﻿Close data file
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data files <../data_files.html>`_  |YES |NO |NO |All |

Syntax
******
**Close data file** {*internal-name* (leave empty to close all)}
Description
***********
This command closes the open data file with the specified internal name, or closes allthe open data files if no name is specified. It sets the flag if at least one data file isclosed. It clears the flag and does nothing (that is, does not generate a runtime error)if the specified internal name does not correspond to an open data file.

Note that data files have a notation property $allowclose, which when set to `kFalse <../../../notation/root/constants/boolean_values.html>`_
,prevents **Close data file**, the data file notation, and the Data FileBrowser from closing the file.
Example
*******

.. code-block:: omnis
	:linenos:	;  check the $allowclose property of myDataFileIf $root.$datas.myDataFile.$allowclose    Close data file {myDataFile}End If
