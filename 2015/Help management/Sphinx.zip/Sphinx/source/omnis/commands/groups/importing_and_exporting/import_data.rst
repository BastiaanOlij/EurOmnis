﻿Import data
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Import data** *list-or-row-name*
Description
***********
This command reads the next data item into the the specified list or row variable. Youuse the **Import data** command to import data from a file or port. Once youselect an import file or port, and issue a *`Preparefor import 
`_
 *command,* ***Import data** adds the data to thespecified list or row variable.

If a record is successfully read from the file or port, Omnis sets the flag. An erroroccurs if the import file or port is closed or if the specified list or row variable doesnot exist. The flag is set after reading a record successfully.

After the import is complete, you should follow **Import data** with an `End import <end_import.html>`_
 and the appropriate `Close import file <close_import_file.html>`_
 or *`Close port <../../groups/report_destinations/close_port.html>`_
*.

There is a one-to-one mapping between the columns or fields in the import file and thecolumns in the list or row variable. Therefore, if there are fewer columns or fields inthe import file than in the list or row, the excess import columns or fields are ignored.Likewise, if there are more columns in the list or row than in the import file, the excesscolumns are left blank.
Example
*******

.. code-block:: omnis
	:linenos:	;  import from a csv file called myImport.txt in the root of your omnis treeCalculate lImportPath as con(sys(115),'myImport.txt')Set import file name {[lImportPath]}Prepare for import from file {Delimited (commas)}Import data lImportListEnd importClose import file
