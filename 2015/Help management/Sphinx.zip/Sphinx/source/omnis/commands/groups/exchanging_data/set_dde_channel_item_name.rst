﻿Set DDE channel item name
#########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |YES |NO |NO |Windows |

Syntax
******
**Set DDE channel item name** {*server-data-item-name*}
Description
***********
DDE command, Omnis as client. This command specifies the server data item name to whichyou can send the exported report. When transmitting a **`Send to DDE channel <../../groups/report_destinations/send_to_dde_channel.html>`_
**report, Omnis takes the channel item name and uses it as the server item name which is tobe sent.

The flag is cleared if the item name is too long, thus causing a memory allocationerror to take place.

The item names set in the command accumulate over each use of the command until a **`Clear DDE channel item names <clear_dde_channel_item_names.html>`_
** is issued.

Within a client library, for example, a report class is created which sends the fieldsClF1, ClF2...ClF5 to the current channel. At the server end of the conversation, thefields are to be read into five fields server1, server2...server5. Before you can printthe report, the method must contain the following commands:
Example
*******

.. code-block:: omnis
	:linenos:	Set report name rMyReportSend to DDE channelSet DDE channel number {1}Open DDE channel {Omnis|myLibrary}Send command {[[TakeControl]}If flag true    Set DDE channel item name {server1}    Set DDE channel item name {server2}    Set DDE channel item name {server3}    Set DDE channel item name {server4}    Set DDE channel item name {server5}    Print reportEnd If
