﻿Cancel event recipient
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |NO |NO |MacOSX |

Syntax
******
**Cancel event recipient** {*recipient-tag*}
Description
***********
This command cancels the specified Apple event recipient.
Example
*******

.. code-block:: omnis
	:linenos:	Set event recipient {Microsoft Excel};  do somethingYes/No message Question {Do you want to keep Excel?}If flag false    Cancel event recipient {Microsoft Excel}Else    ;  continue processing...End If
