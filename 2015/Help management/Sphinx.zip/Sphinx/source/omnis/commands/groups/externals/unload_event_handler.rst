﻿Unload event handler
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Externals <../externals.html>`_  |NO |NO |NO |All |

Syntax
******
**Unload event handler** *routine-name* or *library-name*/*routine-name* (*parameters*)
Description
***********
This command unloads the specified event handler or, if no handler is specified, allevent handlers. If none exists, no action is taken. An event handler is always unloadedwhen the library is closed or when the program quits. See *`Load event handler <load_event_handler.html>`_
* for more information on eventhandlers.
Example
*******

.. code-block:: omnis
	:linenos:	;  unload the event handler, myEventHandlerUnload event handler myEventHandler
