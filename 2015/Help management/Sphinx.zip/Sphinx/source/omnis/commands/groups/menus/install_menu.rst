﻿Install menu
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |YES |YES |NO |All |

Syntax
******
**Install menu** *class-name*[/*instance-name*] [(*parameters*)]
Description
***********
This command installs an instance of the specified menu class on the main menu bar andassigns an instance name. The default instance name is the name of the menu class. Theflag is set if the menu is installed.

You can choose the menu class from a list containing your own menus in the currentlibrary, and the standard menus ***File**, ***Edit**, and so on. When the menuinstance is installed its $construct() method is called receiving any parameters passed.

If you use the **Install menu** command in a reversible block, the menuinstance is removed from the menu bar when the method terminates. However, the order ofthe menus on the menu bar may not necessarily be the same as before.
Example
*******

.. code-block:: omnis
	:linenos:	;  Install the menu mView and pass the parameter;  lView to it's $construct mehtodCalculate lView as 'Large'Install menu mView (lView);  mView $constuct methodDo $cinst.$objs.[pView].$checked.$assign(kTrue)     ;; Check the menu line pView;  Alternatively, you can install a menu using $openDo $clib.$menus.mView.$open()
