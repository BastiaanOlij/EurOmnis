﻿Create file
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |Windows,Linux |

Syntax
******
**Create file** (*path*) **Returns** *err-code*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This command creates the file specified in *path*. Every directory or folder in *path*must already exist. **Create file** does not create directories or folders.

It returns an error code (See `Error Codes <fileops_error_codes.html>`_
), orzero if no error occurs.
Example
*******

.. code-block:: omnis
	:linenos:	Calculate lPathname as con(sys(115),'MyNewFile.txt');  create the new file in the root of your omnis treeCreate file (lPathname) Returns lErrCode
