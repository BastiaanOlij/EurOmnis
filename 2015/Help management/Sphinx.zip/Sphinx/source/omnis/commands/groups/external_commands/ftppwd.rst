﻿FTPPwd
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPPwd** (*socket*) **Returns** *server-directory*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPPwd** gets the pathname of the current directory on the FTPserver.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
ServerDirectory *is an Omnis Character field that receives the pathname of thecurrent directory. If this is a number less than zero, an error occurred. Possible errorcodes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
**
Note: **The value returned depends upon the operating system of the remote server.Many FTP servers return a Linux-style pathname, but do not assume that this is the case.
Example
*******

.. code-block:: omnis
	:linenos:	;  return the current working directory on the FTP serverFTPPwd (iFTPSocket) Returns lDirectoryIf lDirectory&lt;0     ;; an error has occurred    FTPGetLastStatus (iServerReplyText) Returns lErrCode    OK message FTP Error {[con(&quot;Error obtaining current FTP directory&quot;,kCr,&quot;Details follow: &quot;,kCr,iServerReplyText)]}End If
