﻿Message boxes
#############
`Command Index <../command_index.html>`_


`Commands
******** <message_boxes#commands>`_
|`Close working message <message_boxes/close_working_message.html>`_  |`No/Yes message <message_boxes/no_yes_message.html>`_  |`OK message <message_boxes/ok_message.html>`_  |`Prompt for input <message_boxes/prompt_for_input.html>`_  |
|`Redraw working message <message_boxes/redraw_working_message.html>`_  |`Sound bell <message_boxes/sound_bell.html>`_  |`Working message <message_boxes/working_message.html>`_  |`Yes/No message <message_boxes/yes_no_message.html>`_  |

