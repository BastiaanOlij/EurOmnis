﻿Queue keyboard event
####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Events <../events.html>`_  |NO |NO |NO |All |

Syntax
******
**Queue keyboard event** {*key-sequence* or *calculation*}
Description
***********
This command queues a &quot;keyboard&quot; event or series of events. It simulateskeyboard entry by the user from within your methods. You can enter the **key sequence**in several ways: <ol>  **  <li>Recording a key sequence**
    You can use the **Start Recording** and **Stop Recording** buttons to specify the    keys to be generated. During the recording, all key events are echoed to the Key sequence    parameter field, and are not acted on by Omnis in any other way (for example, pressing    Ctrl/Cmnd-Q will NOT suddenly quit Omnis). Click events, however, behave normally so you    can click on **Stop recording** button.</li>  **  <li>Entering into the text field**
    You can enter the text representation manually to generate the keys. Syntax checking is    done at design time. When recording is off, you can edit the Key sequence parameter    manually. This lets you delete key combinations or enter key sequences by hand. Since    spaces are used to automatically separate key presses, the special key name SPACE will    have to be manually entered to generate a &quot;space key&quot; event.</li>  **  <li>Specifying a calculation**
    You can enter a calculation like concatenating text fields, which will contain the text    representation of the keys to be generated. Syntax checking is done at runtime. Incorrect    key sequence syntax will result in a runtime error. When you use a calculation, the    general calculation syntax applies, which is checked at design time.</li></ol>**Key names
=========**
Special keys or key combinations are represented using the names of the keys. When agiven key combination is run on another platform, a conversion is carried out internallyso that, for example, alt-c under Windows becomes opt-c under MacOSX. The list belowsummarizes the conversion:
**Windows and Linux
=================
Modifier Key names**: shift-, alt-, ctrl-
**
Special Key names**: Space, Up, Down, Left, Right, PgUp, PgDn, PgLeft, PgRight, Home,End, Tab, Return, Enter, Bkspc, Clear, Cancel, Minus, Move, Del, Ins, Exit
**MacOSX
======
Modifier Key names**: shift-, opt-, com-
**
Special Key names**: Space, Up, Down, Left, Right, PgUp, PgDn, PgLeft, PgRight, Home,End, Tab, Return, Enter, Bkspc, Clear, Cancel, Minus, Move, Del.
**Set current field
=================**
If queued key events are intended for an edit field or a list, it is advisable to queuea &quot;set current field&quot; event before generating the key events. On the other hand,general key events, for example, menu accelerators or shortcut keys, do not require aspecific current field.
**Key event restrictions under Windowsand Linux
=============================================**
Under Windows, you can use alt-&lt;key&gt; sequences to select menu options from themenu bar. Since the menu bar is handled by the operating environment, and **Queuekeyboard event*** *generates internal Omnis events, queuing alt-&lt;key&gt;events will NOT drive the menu bar. Thus, for example, queuing alt-f will not drop the **File**menu.

As a consequence of the above restriction, `evKey <../../../notation/root/iwindows/window/objs/entry.html>`_
 events are notgenerated for queued alt-&lt;letter&gt; sequences either.

A second situation where `evKey <../../../notation/root/iwindows/window/objs/entry.html>`_
 events are notgenerated is when you queue alt-control-&lt;letter&gt; events. These key combinations arenormally used to produce accented characters, and this facility exists only in some butnot all keyboards. Since Windows does not generate character messages, these events do notgenerate `evKey <../../../notation/root/iwindows/window/objs/entry.html>`_
.
**
WARNING** When queuing events on pushbuttons there is a danger of recursion underWindows and Linux, but also under MacOSX if buttons have been given Windows behavior, thatis, they get the focus. Normally, when the focus is on a pushbutton, you can activate itby pressing the space bar. If that pushbutton receives an `evClick <../../../notation/root/iwindows/window/objs/push_button.html>`_
 event andhas a queued space key event WITHOUT a set current field, the space key event will be sentback to the pushbutton, thereby generating another `evClick <../../../notation/root/iwindows/window/objs/push_button.html>`_
, whichagain activates the space key event. Infinite recursion occurs, resulting in a crash.
**Key event restriction under MacOSX
==================================**
Under MacOSX, you use opt-&lt;letter&gt; to generate extended characters. When queuedkey events include such opt-&lt;letter&gt; sequences, `evKey <../../../notation/root/iwindows/window/objs/entry.html>`_
 is not generated.
Example
*******

.. code-block:: omnis
	:linenos:	;  button methodOn evClick    Open window instance wMyWindow    Queue keyboard event {y o u r n a m e}        ;  paste buttonOn evClick    Queue keyboard event {ctrl-V}
