﻿TCPGetMyAddr
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPGetMyAddr** ([*socket* {Default 0}, *ipv6* {Default `kFalse <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *address*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.

**TCPGetMyAddr** is a domain name service command to resolve the IPaddress of the local computer running Omnis.

You can optionally pass a *Socket, *which corresponds to an open connection. Inthis case, the command returns the local IP address bound to the local endpoint of theconnection. There are two cases where this is useful. <ol>  <li>It is not a mandatory requirement that a WinSock API implementation can return the local    IP address, without a socket for an open connection. In this case it is likely that **TCPGetMyAddr**    will return 0.0.0.0.</li>  <li>If the local machine has more than one IP address, passing a socket eliminates    ambiguity, and returns the local IP address used for the open connection.</li></ol>*
Address* is an Omnis Character field which receives the IP Address of the localhost. The IP address is of the form 255.255.255.254

Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Return the IP address of this machineTCPGetMyAddr  Returns lIPAddressQuit method lIPAddress
