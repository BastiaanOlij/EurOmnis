﻿Open library
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Libraries <../libraries.html>`_  |YES |NO |NO |All |

Syntax
******
**Open library** ([*Do not close others*][,*Enable conversion by runtime*][,*Do not open startup task*][,*Convert without user prompts*]) {*library-file-name*,*internal-name*,*password* (*parameters*)}

Options
*******|Do not close others |If specified,the command does not close all open libraries before opening the specified library |
|Enable conversion by runtime |The development version of Omnis offers to convert libraries created by an earlier version of Omnis. If this option is specified,the runtime version of Omnis will also offer to convert such libraries |
|Do not open startup task |If specified,the command does not construct an instance of the startup task when it opens the library |
|Convert without user prompts |If specified,and conversion is allowed, Omnis will immediately perform the conversion without giving the user any prompts that require a response; also, the user cannot cancel the conversion |

Description
***********
This command opens the specified library file and closes other libraries, if specified.You specify the library name (including path name if required), internal name, password,and startup method parameters of the library to be opened. If the disk file with thespecified path name cannot be opened or is not a valid library, the flag is cleared and nolibraries are closed.

If the internal name of an opened library is specified, a check is made to ensure theinternal name is unique among the open libraries, and a runtime error occurs if this isnot the case. If no internal name is specified, the default internal name is the disk nameof the file with the path name and suffix removed. For example, the internal name for'hd:myfiles:testlib.lbs' is 'testlib'.

**Do not close others**

The **Do not close others** option lets you keep open all other libraries.Otherwise, all other open libraries are closed (see the *`Closelibrary <close_library.html>`_
* command for the consequences of closing a library). If an attempt is madeto open a library which is already open, that library is closed and reopened.

**Startup task**

If the **Do not open startup task** option is specified, the startup taskconstruct for the opened library is not called. Otherwise, the startup task $construct()method is called and the parameters for it are passed. The startup task instance name willbe either the library name or the library internal name if it has one: it is *not*called Startup_Task.
**
Enable conversion by runtime
**
If you select the ****Enable conversion by runtime** **option, and the librarywas created with a previous version of Omnis, then the runtime version of Omnis canconvert the library if the user allows. The default is that an Omnis runtime will not askthe user if they want to convert the library.
**
Passwords**

If a password is specified, an attempt is made to open the library with that password.If it is not a valid password or no password is specified, the library is opened in theusual way, that is, if the library does not need a master password, it is opened at themaster level; otherwise the usual prompt for password dialog is opened (the library isclosed and a flag false returned if this dialog is closed without a password beingentered).
Example
*******

.. code-block:: omnis
	:linenos:	;  Open the library mylib.lbs from the root of your;  omnis studio treeCalculate lLibPath as con(sys(115),'mylib.lbs')Open library (Do not close others) {[lLibPath],MYLIB}If flag true    OK message  {Library Opened!}End If
