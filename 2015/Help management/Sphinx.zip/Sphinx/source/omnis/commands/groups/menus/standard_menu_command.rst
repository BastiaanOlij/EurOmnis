﻿Standard menu command
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Menus <../menus.html>`_  |NO |NO |NO |All |

Syntax
******
**Standard menu command** *command*
Description
***********
This command performs the standard functionality of an option from one of the standardmenus such as the **File** menu. This command can prove useful when defining a newmenu class to replace a standard menu using `Replacestandard file menu <Replace_standard_file_menu.html>`_
 or *`Replace standardedit menu <Replace_standard_edit_menu.html>`_
.*
Example
*******

.. code-block:: omnis
	:linenos:	;  Execute the 'Open Library' option from;  the standard edit menuStandard menu command *File/11020 {Open Library...}
