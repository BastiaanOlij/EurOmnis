﻿Build list columns list
#######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |YES |NO |All |

Syntax
******
**Build list columns list** *list-or-row-name* ([*Clear list*])

Options
*******|Clear list |If specified,the command empties the current list,and defines it to have a single hash variable column,before executing |

Description
***********
This command builds a list containing the column names and data types of the current orspecified list. This information is placed in the current list. If the current listcontains one column, it contains the column names only. The current list column headingsare ignored, but to obtain all the available information, you define the list with twocolumns as follows:
|**Col 1 (Character)** |**Col 2 (Character)** |
|List Column name |List Column data type |

The **Clear list **option clears and defines the current list to contain one column,#S5, so the column data types are not returned. With this option, the command becomesreversible.

The flag is cleared if the value of *LIST.$linemax* prevents a complete list frombeing built. The following method and the list of data it loads into the list illustratethe typical values produced:
Example
*******

.. code-block:: omnis
	:linenos:	Do iMyList.$define(iPODate,iPONumber,iPOBatched,iSUContact,iITUnitPrice)Set current list iColsListDefine list {iColName,iColType}Build list columns list iMyList;  This provides the following values for iColsList;  iPODate - Short date  2000..2099;  iPONumber - Short integer   (0 to 255);  iPOBatched - Boolean;  iSUContact - Character   30;  iITUnitPrice - Number   2 dp;  Or you do the following:Calculate iColsList as iMyList.$cols.$makelist($ref.$name,$ref.$coltype)
