﻿SEA report fatal error
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Error handlers <../error_handlers.html>`_  |NO |NO |NO |All |

Syntax
******
**SEA report fatal error**
Description
***********
This command causes the default action for a fatal error to occur; SEA stands for SetError Action. If the debugger is available, it is invoked, otherwise, execution halts withan error message. This command, like the other SEA commands, should only be used fromwithin an error handler. The SEA commands determine the behavior following fatal orwarning errors.
Example
*******

.. code-block:: omnis
	:linenos:	;  This causes a warning error to generate the same action as a fatal errorIf #ERRCODE=kerrUnqindex    SEA report fatal error    ;  your code...End If
