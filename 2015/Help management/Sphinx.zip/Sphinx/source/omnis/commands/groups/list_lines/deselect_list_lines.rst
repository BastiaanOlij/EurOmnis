﻿Deselect list line(s)
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`List lines <../list_lines.html>`_  |YES |NO |NO |All |

Syntax
******
**Deselect list line(s)** ([*All lines*]) {*line-number* (*calculation*)}

Options
*******|All lines |If specified,the command affects all the lines in the list |

Description
***********
This command deselects the specified list line. The specified line of the current listis deselected and is shown without highlight on a window list field when redrawn. You canspecify the line number as a calculation. The **All lines** option deselects alllines of the current list. When a list is saved in the data file, the line selection stateis stored. 
Example
*******

.. code-block:: omnis
	:linenos:	;  Build a list and deselect line 5Set current list lMyListDefine list {lCol1}For lCount from 1 to 10 step 1    Add line to list {(lCount)}End ForSelect list line(s) (All lines)Deselect list line(s) {(lMyList.$linecount/2)};  Alternatively, you can deselect a line by assigning its $selected property.Do lMyList.5.$selected.$assign(kFalse)     ;; select line 5
