﻿Do
##
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Calculations <../calculations.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Do ***calculation*** Returns ***return-value*****
Description
***********
This command executes the specified *calculation,* which is typically somenotation that operates on a particular object or part of your library. It returns a valueif you specify a *return-value*, which can be a variable of any type.

Note that where the return field is an item reference, the command sets the referencebut does not assign to it: you must do this with *`Calculate <calculate.html>`_
*or *Do Itemref.$assign(value).
*Example
*******

.. code-block:: omnis
	:linenos:	;  open a new window instance of the window class wMyWindow maximizedDo $clib.$windows.wMyWindow.$open('*',kWindowMaximize);  redraw the current window instanceDo $cwind.$redraw();  redraw EntryField1 on the top windowDo $topwind.$objs.EntryField1.$redraw();  return a list in the local variable lClassList of all classes in the current libraryDo $clib.$classes.$makelist($ref.$name) Returns lClassList;  close all open window instancesDo $iwindows.$sendall($ref.$close());  set the $textcolor property of the current object to red;  the optional return field can be used to check whether the operation succeededDo $cobj.textcolor.$assign(kRed) Returns lFlag
