﻿Cancel advises
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |NO |NO |Windows |

Syntax
******
**Cancel advises** *field-name* ([*All channels*])

Options
*******|All channels |If specified,the command applies to all DDE channels,rather than just the current channel |

Description
***********
DDE command, Omnis as client. This command cancels one or more `Request advises <request_advises.html>`_
 from the current channel. If youomit the field name, all Request advises to the current channel are canceled. If youspecify a field name, all Request advises to the current channel which refer to that fieldname are canceled.

The command is addressed to the current channel only, and if the current channel is notopen, an error occurs. No error occurs, however, if there are no `Request advises <request_advises.html>`_
 commands to cancel.

If you use the **All channels** option, all channels are canceled. There is noneed to use a **Cancel advises** command before a *`Close DDE channel <close_dde_channel.html>`_
* command.

When Omnis issues a `Request advises <request_advises.html>`_
 to a DDEserver, Omnis is in effect saying &quot;Tell me if this value changes and send me anupdate&quot;. The `Enter data <../../groups/enter_data/enter_data.html>`_
command must be running to allow the incoming data to get through.
Example
*******

.. code-block:: omnis
	:linenos:	Yes/No message  {Do you want updates?}If flag false    Cancel advises  (All channels)    Quit method Else    Request advises iCompany {Company}    Request advises iAddress {Address}End IfPrepare for insertEnter data Update files if flag set
