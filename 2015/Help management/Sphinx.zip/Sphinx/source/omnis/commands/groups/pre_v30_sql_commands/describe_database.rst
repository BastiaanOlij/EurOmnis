﻿Describe database
#################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Pre V30 SQL Commands <../pre_v30_sql_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**Describe database** (*Tables*|*Views*)

Types
*****|Tables |The command creates a select table of tables available to the current session |
|Views |The command creates a select table of views available to the current session |

Description
***********Not supported in Omnis Studio 5.0 and later.  Use an `object DAM <../../../notation/root/sessions.html>`_
 instead.