﻿Search list
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Lists <../lists.html>`_  |YES |NO |NO |All |

Syntax
******
**Search list** ([*From start*][,*Only test selected lines*][,*Select matches (OR)*][,*Deselect non-matches (AND)*][,*Do not load line*])

Options
*******|From start |If specified,the command starts with the first line of the list,rather than the line immediately after the current line |
|Only test selected lines |If specified,the command only operates on selected lines |
|Select matches (OR) |If specified,the command processes all specified lines,and selects lines which match the search; any lines selected before the command executes remain selected |
|Deselect non-matches (AND) |If specified,the command processes all specified lines,and deselects lines which do not match the search |
|Do not load line |If specified,the line found by the search is not loaded into the current record buffer;this is only relevant when 'Select matches (OR)' and 'Deselect non-matches (AND)' are both not specified |

Description
***********
This command searches the current list for field values that match the current searchclass or search calculation and loads them into the Current Record Buffer. The searchstarts at the beginning of the list if **From start** is checked, otherwise at theline after* *the current line.

If Omnis finds a line that matches the search class, that line number becomes thecurrent line $line and the flag is set. If Omnis cannot find a matching line,the $line iscleared and the flag is cleared. If there is no current search class, all lines are saidto match and Omnis sets the flag.

When checked, the **Do Not Load Line** option ensures the line found by the searchis not loaded into the current record buffer.

The **Only test selected lines** option restricts the list scan to selected linesonly. If the **Select matches (OR)** option is checked, the command scans all thelines from the line after the current line to the end and selects all those that match thesearch; if you also use the **From start** option, the whole of the list is scanned,that is, the search starts at line 1. Lines that are already selected before the commandis executed remain selected. This is equivalent to ORing the existing selected lines withthe lines that match the search. The current line is not affected.

If the **Deselect non-matches (AND)** option is used, the command scans all thelines from the line after the current line to the end and deselects all those which do notmatch the search; if you also use the **From start** option, the whole of the list isscanned, that is, the search starts at line 1. Lines which are already selected before thecommand is executed are deselected if they do not match the search, that is, the onlylines left selected are those which were already selected and which match the search. Thisis equivalent to ANDing the existing selected lines with the lines which match the search.The current line is not affected.

Using the Select and the Deselect options together alters the selection state so thatmatching lines are selected, non-matching lines are deselected. The current line is notaffected.
Example
*******

.. code-block:: omnis
	:linenos:	Set current list iList1Define list {iColNum}Calculate iColNum as 1Repeat    Add line to list    Calculate iColNum as iColNum+1Until iColNum=6Set search as calculation {iColNum=3|iColNum=4}Search list (From start)     ;; current line is now 3Search list (Select matches (OR))     ;; selects line 4;  or do it like thisDo iList1.$search(iColNum=3|iColNum=4,kTrue,kFalse,kTrue,kFalse)Do iList1.$first(kTrue)
