﻿POP3ListMessages
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3ListMessages** (*socket*,*messagenumber*{0 to list all},*list*[,*stsproc*]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3ListMessages** lists the messages on a POP3 server. Note thatthe list excludes any messages marked for deletion (see *`POP3DeleteMessage 
`_
*).You can either list an individual message, or all messages not marked for deletion.
*
Socket* is an Omnis Long Integer field containing a socket opened to a POP3 serverusing *`POP3Connect 
`_
*.
*
MessageNumber* is an Omnis Long Integer field which identifies the message to belisted. Message numbers are assigned by the POP3 server, after you call *POP3Connect, *startingwith 1 for the first message, 2 for the second, and so on.

To list all messages, pass 0 as the *MessageNumber* argument. Otherwise, *MessageNumber*must identify a single message which is not marked for deletion.
*
List* is an Omnis list field defined to have 2 long integer columns. **POP3ListMessages**clears the list, and then adds a line to the list for each message. Column 1 receives themessage number, and column 2 receives the message size in bytes.
*
StsProc* is an optional parameter containing the name of an Omnis method that **POP3ListMessages**calls with status messages. **POP3ListMessages** calls the method with noparameters, and the status information in the variable #S1. The status information logsprotocol messages exchanged on the connection to the server.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  List details of all messages for user lUserName not marked for;  deletion on the POP3 server lServer in lMailListCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocketDo lMailList.$define(lMsgNum,lMsgSize)POP3ListMessages (iSocket,0,lMailList) Returns lStatus
