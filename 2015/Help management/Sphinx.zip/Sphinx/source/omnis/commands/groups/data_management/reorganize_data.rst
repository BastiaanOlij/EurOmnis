﻿Reorganize data
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Data management <../data_management.html>`_  |YES |NO |NO |All |

Syntax
******
**Reorganize data** ([*Test only*][,*Optimize*][,*Convert pictures*][,*Use true color when converting*]) {*list-of-files* (F1,F2,..,Fn) (leave empty to select all)}

Options
*******|Test only |If specified,the data file is not updated; the command purely tests to see if it would update the data file when executed without this option specified,and returns the flag set to true if an update would occur |
|Optimize |If specified,the command also attempts to optimize free space to make data storage more efficient |
|Convert pictures |If specified,the command also converts (where necessary) pictures to shared (cross-platform) picture format |
|Use true color when converting |Only relevant when 'Convert pictures' is specified.If specified,pictures are converted to the recommended shared true color format,rather than the out of date shared 256 color format. |

Description
***********
This command reorganizes the data for the specified file or list of files.Reorganization is the process by which the data structures held in the Omnis data file arebrought into line with the file class definitions.
*
***Reorganize data** reorganizes the data for the specified list offiles, and is equivalent to the option on the **Slot** menu in the Data File Browser.

If you omit a file name or list of files, *all* the files with slots in thecurrent data file are reorganized.

If a specified file name does not include a data file name as part of the notation, thedefault data file for that file is assumed. If the file is closed or memory-only, thecommand does not execute and returns with the flag false.

If you are not running in single user mode, Omnis automatically tests that only oneuser is logged onto the data file (the command fails with the flag false if this is nottrue), and further users are prevented from logging onto the data until the commandcompletes.

If a working message with a count is open while the command is executing, the countwill be incremented at regular intervals. The command may take a long time to execute, andit is not possible to cancel execution even if a working message with cancel box is open.

The command sets the flag if it completes successfully and clears the flag otherwise.The command is not reversible.

If the **Test only** checkbox option is specified, no reorganization is actuallycarried out. The flag is set if at least one file needs reorganization.

The **Optimize** checkbox option specifies whether reorganize with optimize is tobe carried out. This distributes the free space to make the data storage more efficient.

The **Convert pictures** checkbox option causes all pictures in the data to beconverted to a shared picture format.
Example
*******

.. code-block:: omnis
	:linenos:	Reorganize data (Test only)     ;; all filesIf flag true    Yes/No message  {Reorganize now?}    If flag true        Reorganize data    End IfElse    OK message  {No reorganization required}End If
