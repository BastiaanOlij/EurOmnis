﻿Import field from file
######################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Importing and Exporting <../importing_and_exporting.html>`_  |YES |NO |NO |All |

Syntax
******
**Import field from file** **into ***field-name***** ([*Single character*][,*Leave in buffer*])

Options
*******|Single character |If specified,the command reads a single character at a time |
|Leave in buffer |If specified,the command leaves the data it returns in the buffer,meaning that the next call to the command will return the same value |

Description
***********
This command reads a line of characters from the current import file to the specifiedfield. It lets you read fields from a file without using a window and `Import data <import_data.html>`_
. Usually the command reads a whole line at atime but there are options which modify this.

The **Single character** option tells Omnis to read a single character at a time.If the field is a Character or a National field, it is set to have a length of one,containing the single character imported from the file. If the field is a Number field,the field value is set to the ASCII code of the single character imported from the file.

The **Leave in buffer** option tells Omnis to read the string or single characterbut not remove it from the buffer. Therefore, the next **Import field from file**will read exactly the same value.

An error will occur if the import file has not been opened; Omnis clears the flag onreaching the end of the file. Do not mix `Import data <import_data.html>`_
and **Import field from file*** *because they use the input buffer indifferent ways.
Example
*******

.. code-block:: omnis
	:linenos:	;  import from a csv file called myImport.txt in the root of your omnis treeCalculate lImportPath as con(sys(115),'myImport.txt')Set import file name {[lImportPath]}Prepare for import from file {Delimited (commas)}Repeat    Import field from file into lImportFieldUntil lImportField='start data'Do method ImportDataClose import file
