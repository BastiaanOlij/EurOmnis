﻿Prepare for insert
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |YES |NO |All |

Syntax
******
**Prepare for insert**
Description
***********
This command prepares Omnis for inserting new data into the main file. It clears themain file and prepares to insert a new record into the main file. All Read/write non-mainfile records in the current record buffer are reread if a record has been changed. You canedit data in all the read/write files in the buffer, other than the main file.

The *`Enter data <../../../commands/groups/enter_data/enter_data.html>`_
*command is required only if the user is to enter data via a window. Data is not written tothe disk until *`Update files <update_files.html>`_
* is executed.

Prepare for edit/insert mode is cleared only by a *`Cancel prepare for update <cancel_prepare_for_update.html>`_
, `Update files <update_files.html>`_
* or a *`Quit all methods <../../../commands/groups/methods/quit_all_methods.html>`_
*command. You can build lists, print reports and change the main file in the middle of aninsert without canceling the Prepare for... mode.

If the main file is changed while in Prepare for insert mode, the main file at the timeof the* ***Prepare for insert** is used when *`Update files <update_files.html>`_
* is encountered.

In multi-user mode, the *Prepare for...* commands reread the current records fromthe data file if another user has edited a record.
Example
*******

.. code-block:: omnis
	:linenos:	;  The following example is equivalent to the 'insert record' on the commands menu which can be;  installed using 'Install menu *Commands'Prepare for insertEnter data If flag true    Update filesElse    Clear main &amp; connected    Redraw {wMyWindow}End If
