﻿Set server mode
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Exchanging data <../exchanging_data.html>`_  |NO |YES |NO |Windows |

Syntax
******
**Set server mode** ([*Field requests*][,*Field values*][,*Advise requests*][,*Commands*])

Options
*******|Field requests |If specified,Omnis will accept DDE field request commands (see command Accept field requests) |
|Field values |If specified,Omnis will accept DDE field value commands (see command Accept field values) |
|Advise requests |If specified,Omnis will accept DDE advise request commands (see command Accept advise requests) |
|Commands |If specified,Omnis will accept DDE commands (see command Accept commands) |

Description
***********
This command sets Omnis to act as a DDE server and specifies which DDE commands it willaccept. With one or more of the* *check box options selected Omnis will respond tothe corresponding commands and demands from a client. If none is selected, server mode isdeselected.

All four server mode check box options have equivalent DDE commands which are describedseparately: *`Accept field requests <accept_field_requests.html>`_
, `Accept field values <accept_field_values.html>`_
, `Accept advise requests <accept_advise_requests.html>`_
* and *`Accept commands <accept_commands.html>`_
*.

Irrespective of the mode selected, Omnis will only accept field values and commandswhen in enter data mode, and accept commands when no methods are running.

Omnis will only respond to a request to act as a server if the Initiate message fromthe client contains at least the name of the program, that is, Omnis. If the clientspecifies a topic, it has to be equal to the Omnis library name without the .lbrextension. Omnis responds with the current library name if the client does not specify thetopic.

If no options are set, Omnis is disabled as a server except for the System Topic. IfOmnis is already a server when the options under **Set server mode** aredisabled, one of two things will happen: <ol>  <li>If the options have been disabled during a reversible block, the client sending the    Initiate message will get busy acknowledgments until the reversible command method    finishes. You cannot initiate any new conversations during this time.</li>  <li>Omnis will end the communication by sending the client a Terminate message.</li></ol>
All four server mode options have equivalent commands which are described separately: *`Accept field requests <accept_field_requests.html>`_
, `Accept field values <accept_field_values.html>`_
, `Accept advise requests <accept_advise_requests.html>`_
* and `Accept commands <accept_commands.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	Set server mode (Field requests)
