﻿Delete
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Changing data <../changing_data.html>`_  |YES |NO |NO |All |

Syntax
******
**Delete**
Description
***********
This command deletes the current record in the main file without prompting the user toconfirm the command, so you should use it with caution. The flag is set if the record isdeleted, or cleared if there is no main file record. The flag is also cleared if the *`Do not waitfor semaphores <../../../commands/groups/changing_data/do_not_wait_for_semaphores.html>`_
* option is on and the record is locked.
Example
*******

.. code-block:: omnis
	:linenos:	;  The following example deletes records selected by a search class.Set main file {fAccounts}Set search name sOverDrawnFind first on fAccounts.Code (Use search)Repeat    Delete    Next Until flag false;  This example checks the semaphore and tells the user if the record is locked:Do not wait for semaphoresDeleteIf flag false    OK message  (Sound bell) {Record in use and can't be deleted}End If
