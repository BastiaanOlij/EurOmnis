﻿List lines
##########
`Command Index <../command_index.html>`_


`Commands
******** <list_lines#commands>`_
|`Add line to list <list_lines/add_line_to_list.html>`_  |`AND selected and saved <list_lines/and_selected_and_saved.html>`_  |`Clear line in list <list_lines/clear_line_in_list.html>`_  |`Delete line in list <list_lines/delete_line_in_list.html>`_  |
|`Delete selected lines <list_lines/delete_selected_lines.html>`_  |`Deselect list line(s) <list_lines/deselect_list_line(s).html>`_  |`Go to next selected line <list_lines/go_to_next_selected_line.html>`_  |`Insert line in list <list_lines/insert_line_in_list.html>`_  |
|`Invert selection for line(s) <list_lines/invert_selection_for_line(s).html>`_  |`Load from list <list_lines/load_from_list.html>`_  |`OR selected and saved <list_lines/or_selected_and_saved.html>`_  |`Replace line in list <list_lines/replace_line_in_list.html>`_  |
|`Restore selection for line(s) <list_lines/restore_selection_for_line(s).html>`_  |`Save selection for line(s) <list_lines/save_selection_for_line(s).html>`_  |`Select list line(s) <list_lines/select_list_line(s).html>`_  |`Set final line number <list_lines/set_final_line_number.html>`_  |
|`Swap selected and saved <list_lines/swap_selected_and_saved.html>`_  |`Test if list line selected <list_lines/test_if_list_line_selected.html>`_  |`XOR selected and saved <list_lines/xor_selected_and_saved.html>`_  |

