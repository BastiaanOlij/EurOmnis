﻿FTPPut
######
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPPut** (*socket*,*localfile*,*remotefile*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPPut** uploads a local file to the FTP server. The file istransferred according to the currently specified transfer type of ASCII or binary asspecified by the *`FTPType <ftptype.html>`_
* command. It is important thatyou set the transfer type correctly for each file you upload, since an incorrect transfertype will result in a bad uploaded copy of the file.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
LocalFile* is an Omnis Character field containing the pathname of the file toupload.
*
RemoteFile* is an Omnis Character field containing the pathname of the destinationfile on the FTP server.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  upload an ascii file to a FTP server;  set file transfer mode to asciiFTPType (iFTPSocket,0) Returns lErrCodeIf not(lErrCode)    Calculate lLocalFileName as con(sys(115),'uploadFolder',sys(9),'myTextFileToUpload.txt')    Calculate lRemoteFile as 'myUploadedFile.txt'    ;  upload the file to the current working directory on the FTP server, the file name will be myUploadedFile.txt    FTPPut (iFTPSocket,lLocalFileName,lRemoteFile) Returns lErrCode    If lErrCode        FTPGetLastStatus (iServerReplyText) Returns lErrCode        OK message FTP Error {[con(&quot;Error uploading file&quot;,upp(lLocalFileName),&quot; to &quot;,upp(lRemoteFile),kCr,&quot;Details follow: &quot;,kCr,iServerReplyText)]}    End IfEnd If
