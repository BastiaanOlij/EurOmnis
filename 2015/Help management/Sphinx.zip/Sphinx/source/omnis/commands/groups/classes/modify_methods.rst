﻿Modify methods
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Modify methods** {*class-name*}
Description
***********
This command opens the method editor for the specified class. Method executioncontinues and does not wait for the design window to be closed. Opening a method in designmode first causes a *`Quitall methods <../../../commands/groups/methods/quit_all_methods.html>`_
* if one of the methods for that class is running. The flag is clearedif the specified class does not exist, or if it is a file, search, or report class.
Example
*******

.. code-block:: omnis
	:linenos:	New class {Window/wMyWindow};  open at the $construct() method for the window wMyWindowModify methods {wMyWindow}
