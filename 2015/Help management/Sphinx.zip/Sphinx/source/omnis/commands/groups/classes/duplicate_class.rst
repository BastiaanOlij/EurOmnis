﻿Duplicate class
###############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Duplicate class** {*class-name*/*new-name*}
Description
***********
This command creates a new library class by duplicating an existing one. The name forthe new class is specified in addition to the class you want to duplicate. Errors, such asattempting to use a name that is already in use, simply clear the flag and display anerror message.

Typical uses of this command are to allow users to make changes to reports andsearches.
Example
*******

.. code-block:: omnis
	:linenos:	Duplicate class {sArea/sUser}If flag true    Modify class {sUser}    Set search name sUser    Print report (Use search)End If
