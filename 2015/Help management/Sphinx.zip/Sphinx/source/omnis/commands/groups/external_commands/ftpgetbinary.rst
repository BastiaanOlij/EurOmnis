﻿FTPGetBinary
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPGetBinary** (*socket*,*remotefile*,*binfield*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPGetBinary** downloads a file from an FTP server into an Omnisbinary variable. The file is transferred using binary transfer mode.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
RemoteFile* is an Omnis Character field containing the pathname of the remote fileto download.
*
BinField* is an Omnis Binary or Character field that will receive the contents ofthe remote file.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  set file transfer mode to binaryFTPType (iFTPSocket,1) Returns lErrCodeIf not(lErrCode)    ;  assumes you are already in the correct folder on the ftp server so only the file name is needed    Calculate lRemoteFile as 'omnis.exe'    ;  download the file    FTPGetBinary (iFTPSocket,lRemoteFile,lBinField) Returns lErrCode    If lErrCode        OK message FTP Error {[con(&quot;Error transferring file &quot;,upp(lRemoteFile),&quot;Error code : &quot;,lErrCode)]}    Else        ;  select where to save the file to on the local machine        Do FileOps.$selectdirectory(lNewPath,'Enter path to save file to',sys(115)) Returns lStatus        If lStatus            ;  create the file            Do lFileOps.$createfile(con(lNewPath,sys(9),lRemoteFile))            ;  write the binary contents downloaded from the FTP server to the new local file            Do lFileOps.$writefile(lBinField)        End If    End IfEnd If
