﻿Revert class
############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Classes <../classes.html>`_  |YES |NO |NO |All |

Syntax
******
**Revert class** {*class-name*}
Description
***********
This command reads the specified class from the library file on disk into RAM, so thatany changes made to that class using the notation are lost. The flag is set if the classis successfully re-read. A runtime error occurs if the specified class cannot be found.
Example
*******

.. code-block:: omnis
	:linenos:	;  make change to a window classDo $windows.wMyWindow.$objs.Field1.$visible.$assign(kFalse)Open window instance wMyWindow;  do somethingRevert class {wMyWindow}     ;; reset the Field1 on the saved window (NOT the current instance) to be visible
