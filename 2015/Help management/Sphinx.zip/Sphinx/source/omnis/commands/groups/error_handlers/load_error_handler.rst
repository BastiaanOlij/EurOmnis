﻿Load error handler
##################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Error handlers <../error_handlers.html>`_  |NO |YES |NO |All |

Syntax
******
**Load error handler** ([*All libraries*]) [*name*/]*name* (*first-error-number*, *last-error-number*)

Options
*******|All libraries |If specified,the error handler applies to errors encountered in all libraries,rather than just the calling library |

Description
***********
This command loads a specified method which handles errors which may occur within alibrary. You can specify a range of error codes to be handled by the handler by giving thefirst and last error number. If no range is specified, the handler is called for allerrors. Errors are either *Fatal* or *Warning*.

Error codes such as `kerrUnqindex <../../../notation/root/constants/error_codes.html>`_
,`kerrBadnotation <../../../notation/root/constants/error_codes.html>`_
, `kerrSQL <../../../notation/root/constants/error_codes.html>`_
, can also beused as parameters. The **Catalog** window lists all the constants available inOmnis.
**Fatal errors
============**
A *fatal* error is one that normally stops method execution and drops into thedebugger if available. The error code `#ERRCODE <../../../notation/root/hashvars/errors.html>`_
is displayed on the status line in the debugger and is *greater than* 100,000.
**Warning errors
==============**
A *warning* error is one that does not normally quit the method nor report anerror description. The error code `#ERRCODE <../../../notation/root/hashvars/errors.html>`_
is displayed on the status line in the debugger, if invoked, and is *less than*100,000.

The check box option **All libraries** is provided. If this is not checked, thehandler is called only for errors encountered in the library which loaded the errorhandler. This command leaves the flag unaffected and is reversible; that is, the handleris unloaded when the command is reversed. An error handler remains loaded until it isunloaded or the library containing the handler method is closed. Error handlers loadedwithin an error handler always unload when that error handler terminates.

An alternative to using the parameters passed to the error handler, is to use thevariables `#ERRCODE <../../../notation/root/hashvars/errors.html>`_
 and *`#ERRTEXT <../../../notation/root/hashvars/errors.html>`_
. *However, you must copythe values of `#ERRCODE <../../../notation/root/hashvars/errors.html>`_
and `#ERRTEXT <../../../notation/root/hashvars/errors.html>`_
 upon entryto the error handler, since commands you execute in the error handler might change theirvalues.

An error handler can use one of the `Set erroraction <sea_continue_execution.html>`_
 commands (SEA) to set what it requires the next action to be. If the errorhandler quits without making a `Set error action <sea_continue_execution.html>`_
and there is another handler capable of accepting the error, the second handler is called.Otherwise, the default action for the error is carried out, depending on whether it is afatal error or warning.

If an error occurs within an error handler, that error is handled in the usual wayexcept that the original error handler will not be used (even if it could handle thaterror). It is possible to load error handlers within an error handler; these are meant todeal with errors within the handler and are unloaded automatically when the error handlercompletes execution. 
Example
*******

.. code-block:: omnis
	:linenos:	;  pCode is defined as a Long Integer;  pText is defined as a character type;  A typical error handlerIf pCode=kerrBadnotation    ;  handle error - pText contains a string describing the errorEnd If;  The following example handles the error returned by the data manager when an attempt to;  duplicate a unique index occurs on update:Load error handler cMyErrorHandler/ErrorsPrepare for editEnter data Update files if flag set;  In the method Errors of code class cMyErrorHandlerIf pCode=kerrUnqindex    OK message Error (Icon) {You have entered a duplicate field value/'X' has been appended to your entry}    Calculate iValue as con(iValue,'X')    Enter data     If flag true        SEA repeat command    Else        SEA continue execution    End IfEnd If
