﻿Create library
##############
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Libraries <../libraries.html>`_  |YES |NO |NO |All |

Syntax
******
**Create library** ([*Do not close others*]) {*library-file-name*,*internal-name*}

Options
*******|Do not close others |If specified,the command does not close all open libraries before opening the specified library |

Description
***********
This command creates and opens a new library file. You specify the file name (andpathname if you wish) and internal name of the library. The internal name is an alias thatyou supply and use in your methods to refer to that library file.

If no internal name is specified, the default internal name is the disk name of thefile with the path name and suffix removed. For example, under Windows the internal namefor 'c:\myfiles\mylib.lbs' is MYLIB. Similarly, under MacOSX the internal name for'hd:myfiles:mylib.lbs' is 'mylib'.

A ****Do not close others**** option can also be specified so that you can openmultiple libraries. If the disk file with the specified path name cannot be created (andopened), the flag is cleared and no libraries are closed. Otherwise, if the option is notspecified, all other open libraries are closed (see *`Closelibrary <close_library.html>`_
* for the consequences of closing a library).
**
WARNING** If the path name is the same as an existing library, the existing libraryis overwritten. If the existing library is open, it is closed and deleted and a new, emptylibrary is opened.
Example
*******

.. code-block:: omnis
	:linenos:	;  Creat a library named mylib.lbs in the root of your;  omnis studio treeCalculate lLibPath as con(sys(115),'mylib.lbs')Create library (Do not close others) {[lLibPath]}If flag true    OK message  {Libraray created!}End If
