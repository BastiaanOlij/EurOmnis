﻿Set 'About...' method
#####################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Omnis environment <../omnis_environment.html>`_  |NO |YES |NO |All |

Syntax
******
**Set 'About...' method** [*name*/]*name*
Description
***********
This command changes the &quot;About...&quot; option by calling the specified methodwhich you should set to open a different About window. Omnis executes the specified methodwhen this option is selected in exactly the same way as if it had been selected from amenu, for example, standard windows are closed. If you use **Set 'About...' method**in a reversible block, the command is reversed when the method terminates.

There are no restrictions on what you can do in the **Set 'About...' method**,that is, the method that is called. Extra care is needed to ensure that the method doesnot alter any variables, lists or the status of the flag.
Example
*******

.. code-block:: omnis
	:linenos:	;  Open the window wMyAbout instead of the standard;  Omnis about boxSet 'About...' method cMyCodeClass/AboutBox;  method AboutLibrary in code class cMyCodeClassOpen window instance wMyAbout
