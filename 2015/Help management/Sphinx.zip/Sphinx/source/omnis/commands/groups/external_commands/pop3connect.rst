﻿POP3Connect
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**POP3Connect** (*server*,*username*,*password*[,*stsproc*,*secure* {Default zero insecure;1 secure;2 use STARTTLS},*verify* {Default `kTrue <../../../notation/root/constants/boolean_values.html>`_
}]) **Returns** *socket*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***POP3Connect** establishes a connection to a POP3 server. If **POP3Connect**succeeds, it returns the socket opened to the POP3 server. You can use this socket withthe other POP3 commands which require a socket argument. If an error occurs, **POP3Connect**returns an error code, which is less than zero. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.

Note that it is essential that you call *`POP3Disconnect 
`_
*when you have finished using the connection to the POP3 server.
*
Server* is an Omnis Character field containing the IP address or hostname of a POP3server that will serve e-mail to the client running Omnis. For example: pop3.mydomain.comor 255.255.255.254. If the server is not using the default POP3 port (110, or 995 for a secure connection), you can optionally append the port number on which the server is listening, using the syntax server:port, for example pop3.mydomain.com:1234.
*
Username* is an Omnis Character field containing the account that receives the mailon the designated server (usually an account user name, for example, Webmaster).
*
Password* is an Omnis character field containing the password for the accountspecified in the *UserName* parameter, for example, Secret.
*
StsProc* is an optional parameter containing the name of an Omnis method that **POP3Connect**calls with status messages. **POP3Connect** calls the method with noparameters, and the status information in the variable #S1. The status information logsprotocol messages exchanged on the connection to the server.

*Secure* is an optional Boolean parameter which indicates if a secure connection is required to the server.Pass `kTrue <../../../notation/root/constants/boolean_values.html>`_
 for a secure connection. To use a secure connection, OpenSSL must be installed on the system. On MacOSX and manyLinux distributions, OpenSSL is usually already installed.  For Windows, see http://www.openssl.org/related/binaries.html. 

**POP3Connect** also supports an alternative secure option, If you pass secure with the value 2, the connection is initially not secure, but after the initial exchange with the server, **POP3Connect** issues the STLS POP3 command to make the connection secure if the server supports it (see RFC 2595 for details). Authentication occurs after a successful STLS command.

*Verify* is an optional Boolean parameter which is only significant when *Secure* is not `kFalse <../../../notation/root/constants/boolean_values.html>`_
.  When *Verify* is `kTrue <../../../notation/root/constants/boolean_values.html>`_
,the command instructs OpenSSL to verify the server's identity using its certificate; if the verification fails, then the connectionwill not be established.  You can pass *Verify* as `kFalse <../../../notation/root/constants/boolean_values.html>`_
, to turn off this verification; in this case, the connection will stillbe encrypted, but there is a chance the server is an impostor.  In order to perform the verification, OpenSSL uses the Certificate Authority Certificates in the cacerts sub-folder of the secure folder in the Omnis folder.  If you use your own Certificate Authorityto self-sign certificates, you can place its certificate in the cacerts folder, and OpenSSL will use it after you restart Omnis.
*
Socket* is an Omnis Long integer field which receives the socket for the newconnection. If an error occurs, **POP3Connect** returns an error code with avalue less than zero. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Establish a connection to the POP3 server lServer for user;  lUsername using the password lPasswordCalculate lServer as 'my.pop3.server'Calculate lUserName as 'myusername'Calculate lPassword as 'mypassword'POP3Connect (lServer,lUserName,lPassword) Returns iSocket
