﻿FTPMkdir
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPMkdir** (*socket*,*dirname*) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPMkdir** creates a new directory on the FTP server.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
*
DirName* is an Omnis Character field containing the pathname of the new directory tocreate on the server.
**
Note: **The name of the new directory must follow the convention and file-namingrules of the remote system. Not all users will have permissions to create new directorieson arbitrary directories on the remote system. Default file-access permissions apply tothe new directory.
*
Status* is an Omnis Long Integer field which receives the result of executing thecommand. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  create a new directory called myNewDirectory in the directory TestCalculate lDirName as '/Test/myNewDirectory'FTPMkdir (iFTPSocket,lDirName) Returns lErrCodeIf lErrCode    FTPGetLastStatus (iServerReplyText) Returns lErrCode    OK message FTP Error {[con(&quot;Error creating directory&quot;,lDirName,kCr,&quot;Details follow: &quot;,kCr,iServerReplyText)]}End If
