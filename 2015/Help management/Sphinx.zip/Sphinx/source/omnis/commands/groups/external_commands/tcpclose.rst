﻿TCPClose
########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**TCPClose** (*socket*[,*option* {Default zero for complete;1 for partial;2 for abort}]) **Returns** *status*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***TCPClose** closes, and depending on the *Option*, releases a *Socket*.When the socket is connected, this will result in the closure of the connection to theremote application. All new sockets returned by all Web commands, must eventually bereleased using **TCPClose**, to avoid resource leakage.

The most brutal form of **TCPClose** is an abortive close. In this case,no consideration is given to the state of the connection, or exchanges with the remoteapplication, and the socket is closed and released immediately. This form of **TCPClose**is recommended for use in error handling situations.

The mildest form of **TCPClose** is a partial close. In this case, thesocket is not released, and you will need to call **TCPClose** again torelease the socket. A partial close initiates a disconnect of the TCP/IP connection, bysending a TCP/IP packet with the finish flag set. This means that you can no longer senddata to the remote application, but you can continue to receive data. The remoteapplication will be informed of the partial close, when it receives zero bytes; in thecase of the *`TCPReceive <tcpreceive.html>`_
* command, it will return areceived character count of zero. At this point, the remote application can continue tosend data, and when it has finished, it issues a complete close itself.

The remaining form of **TCPClose** is a complete close. In this form, **TCPClose**initiates a close of the connection if necessary, receives data on the connection until nomore is available (to flush the connection), and releases the socket. This is recommendedpractice for TCP/IP connections.

What does this mean in practice? Consider two applications A1 and A2, communicatingusing TCP/IP. A1 can either do a partial close or a complete close. In both cases, A2 willreceive zero bytes, indicating that disconnection has been initiated. A2 can continue tosend, and when it has finished, it issues a complete close. A1 can receive the data sentby A2 provided that it only issued a partial close. Eventually A1 will receive zero bytes,at which point it issues a final complete close. At this point, the connection has beengracefully closed, and the sockets used by both A1 and A2 have been released.
*
Socket* is an Omnis Long Integer field containing a number representing a previouslyopened socket.
*
Option *is an optional Omnis Integer field, which has the value zero for a completeclose, 1 for a partial close, and 2 for an abortive close. If omitted, it defaults to acomplete close.
*
Status* is an Omnis Long Integer field which receives the value zero for success, oran error code &lt; 0 for failure. Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  Close the socket bound to iPortCalculate iPort as 6000TCPSocket  Returns iSocketTCPBind (iSocket,iPort) Returns lStatusTCPClose (iSocket) 
