﻿Until flag false
################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`JavaScript,iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Until flag false**
Description
***********
&gt; 

This command terminates the *`Repeat <repeat.html>`_
&#150;***Until**conditional loop if the flag is false; execution continues with the command following the *Until*.If the flag is true, execution continues with the command following the `Repeat <repeat.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	;  loop until 'No' is pressedRepeat    No/Yes message  {Press No to exit loop}Until flag false
