﻿Until break
###########
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Constructs <../constructs.html>`_  |NO |NO |`iOS <../../command_index.html#client commands>`_  |All |

Syntax
******
**Until break**
Description
***********
This command terminates a repeat loop if the user requests a cancel by either clicking on a working message Cancel button, or by pressing Ctrl-Break under Windows, Ctrl-C under Linux, or Cmnd-period under MacOSX.  Note that the user cannot request a cancel (and thereforecause *Until break* to terminate the repeat loop) if *`Disable cancel test at loops <disable_cancel_test_at_loops.html>`_
* has been executed. Note that you can also terminate a repeat loop using *`Break to end of loop <break_to_end_of_loop.html>`_
* within the loop, or by using one of the alternative Until... commands.
Example
*******

.. code-block:: omnis
	:linenos:	;  only way out of this loop is to enter a value greated than 10Disable cancel test at loopsRepeat    Prompt for input Enter a value greater than 10 to exit loop Returns lValue    If lValue&gt;10        Break to end of loop    End IfUntil break
