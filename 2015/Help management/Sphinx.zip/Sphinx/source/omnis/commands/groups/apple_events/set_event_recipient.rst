﻿Set event recipient
###################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`Apple events <../apple_events.html>`_  |YES |YES |NO |MacOSX |

Syntax
******
**Set event recipient** {*name-of-running-program* (leave empty to send to Omnis)}
Description
***********
This command specifies the name of the application to which subsequent Apple events areto be sent. The name of the application must exactly match the name in the System 7Application menu, for example &quot;Microsoft Excel&quot;. This name becomes the&quot;recipient tag&quot; by which you can select it from all the current eventrecipients.

You can access another machine by specifying its name and zone together with theapplication name. The *zone_name* is where the applicationsreside (when you specify the zone you must also specify the Mac or PowerMac name). If youomit *zone_name*, the current zone is the default. The *mac_name* is the Mac orPowerMac on which the event recipient resides. If you omit *mac_name* (and *zone_name*)your machine (the host) receives the events by default. When you launch Omnis, therecipient defaults to Omnis, that is, events are sent to itself. In the same way, if youuse this command without a parameter, the recipient reverts to Omnis.

The *application_name* must exactly match the name of the application. If a matchis found, the flag is set. The application name is stored in this form as an eventrecipient, as seen in a list created with *`Buildlist of event recipients <build_list_event_recipients.html>`_
.
*
The example shows the difference between `Use eventrecipient <use_event_recipient.html>`_
, which is used with a tag previously assigned by the user with *`Prompt for event recipient 
`_
*, and **Setevent recipient**, which takes a local application name as a parameter, and turnsit into a recipient tag.
Example
*******

.. code-block:: omnis
	:linenos:	;  prompt user and select applicationPrompt for event recipient {MyAppl};  do something with MyAppl;  This is the name of the current application, as shown on the Apple Application menuSet event recipient {Microsoft Excel};  do something in 'Excel';  go back to the tagged recipient, previously prompted forUse event recipient {MyAppl};  do something else;  Finally go back to Omnis by resetting recipient with no promptUse event recipient
