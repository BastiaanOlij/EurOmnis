﻿FTPReceiveCommandReplyLine
##########################
|**Command group** |**Flag affected** |**Reversible** |**Execute on client** |**Platform(s)** |
|`External commands <../external_commands.html>`_  |YES |NO |NO |All |

Syntax
******
**FTPReceiveCommandReplyLine** (*socket*) **Returns** *reply*
Description
***********
Note: The flag is set according to whether Omnis was able to make a call to this external command.

This Web command is multi-threaded,allowing another thread to execute in the multi-threaded server while it runs. Note that the same socket cannot safely be used concurrently by more than one thread.
*
***FTPReceiveCommandReplyLine** returns the next line of the replyfollowing an *`FTPSendCommand <ftpsendcommand.html>`_
*. You have to determineif the reply is multi-line, and if so issue further receive commands to get the remainderof the reply. **FTPReceiveCommandReplyLine** will timeout after 60 seconds ifit does not receive a reply.
*
Socket* is an Omnis Long Integer field containing a socket opened to an FTP serverusing *`FTPConnect <ftpconnect.html>`_
*.
**
Reply** is an Omnis Character variable containing the reply from the server.Possible error codes are listed in the `Web Command Error Codes Appendix <web_error_codes.html>`_
.
Example
*******

.. code-block:: omnis
	:linenos:	FTPSendCommand (iFTPSocket,'pwd') ;  return the current directoryFTPReceiveCommandReplyLine (iFTPSocket) Returns lDirName
