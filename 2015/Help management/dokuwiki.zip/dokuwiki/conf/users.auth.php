# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


euromnis:$1$ptWw4iQn$T/jNUmxO6cWZlObb0pqmp/:EurOmnis:mux213@gmail.com:admin,user
